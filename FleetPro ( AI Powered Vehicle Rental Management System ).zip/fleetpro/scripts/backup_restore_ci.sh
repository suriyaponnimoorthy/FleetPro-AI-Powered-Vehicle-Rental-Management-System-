#!/usr/bin/env bash
set -euo pipefail
compose=(docker compose --env-file .env.production -f deployment/docker-compose.yml)
# Disposable database only. Production restore uses the separately documented runbook.
"${compose[@]}" exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > /tmp/fleetpro-ci.dump
"${compose[@]}" exec -T db sh -c 'createdb -U "$POSTGRES_USER" fleetpro_restore_drill'
"${compose[@]}" exec -T db sh -c 'pg_restore -U "$POSTGRES_USER" --exit-on-error -d fleetpro_restore_drill' < /tmp/fleetpro-ci.dump
"${compose[@]}" exec -T db sh -c 'psql -U "$POSTGRES_USER" -d fleetpro_restore_drill -v ON_ERROR_STOP=1 -c "SELECT COUNT(*) FROM django_migrations"'
"${compose[@]}" exec -T db sh -c 'dropdb -U "$POSTGRES_USER" fleetpro_restore_drill'

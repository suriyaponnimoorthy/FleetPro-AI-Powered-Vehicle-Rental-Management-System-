"""
scripts/seed_data.py
Run: python manage.py shell < scripts/seed_data.py
Seeds: branches, categories, vehicles, users, drivers, customers, bookings.
"""

import os
import django
import random
from decimal import Decimal
from datetime import date, timedelta

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from django.utils import timezone
from django.db import transaction
from faker import Faker

from apps.authentication.models import User
from apps.vehicles.models import Branch, VehicleCategory, Vehicle, VehicleInsurance
from apps.customers.models import CustomerProfile
from apps.drivers.models import Driver
from apps.bookings.models import Booking
from apps.payments.models import Payment

fake = Faker("en_IN")
random.seed(42)


@transaction.atomic
def seed_all():
    print("🌱 Seeding FleetPro database...")

    # ── 1. Super Admin ───────────────────────────────────────
    admin, _ = User.objects.get_or_create(
        email="admin@fleetpro.in",
        defaults={
            "first_name": "Super",
            "last_name": "Admin",
            "role": User.Role.SUPER_ADMIN,
            "is_staff": True,
            "is_superuser": True,
            "is_email_verified": True,
        }
    )
    admin.set_password("Admin@123456")
    admin.save()
    print("  ✓ Super Admin created: admin@fleetpro.in / Admin@123456")

    # Staff user
    staff, _ = User.objects.get_or_create(
        email="staff@fleetpro.in",
        defaults={
            "first_name": "Ravi",
            "last_name": "Sharma",
            "role": User.Role.STAFF,
            "is_staff": True,
            "is_email_verified": True,
        }
    )
    staff.set_password("Staff@123456")
    staff.save()

    # ── 2. Branches ──────────────────────────────────────────
    branches_data = [
        {"name": "Chennai Central",    "code": "CHN01", "city": "Chennai",   "state": "Tamil Nadu",  "pincode": "600002", "phone": "04412345678"},
        {"name": "Mumbai Andheri",     "code": "MUM01", "city": "Mumbai",    "state": "Maharashtra", "pincode": "400053", "phone": "02298765432"},
        {"name": "Bengaluru MG Road",  "code": "BLR01", "city": "Bengaluru", "state": "Karnataka",   "pincode": "560001", "phone": "08023456789"},
        {"name": "Delhi Connaught",    "code": "DEL01", "city": "Delhi",     "state": "Delhi",       "pincode": "110001", "phone": "01145678901"},
        {"name": "Hyderabad Banjara",  "code": "HYD01", "city": "Hyderabad", "state": "Telangana",   "pincode": "500034", "phone": "04067891234"},
    ]
    branches = []
    for bd in branches_data:
        b, _ = Branch.objects.get_or_create(
            code=bd["code"],
            defaults={**bd, "address": f"{fake.street_address()}, {bd['city']}"}
        )
        branches.append(b)
    print(f"  ✓ {len(branches)} branches created")

    # ── 3. Vehicle Categories ────────────────────────────────
    categories_data = [
        {"name": "Hatchback",    "type": "car",      "base_price_per_day": 1100,  "base_price_per_hour": 150,  "security_deposit": 3000,  "sort_order": 1},
        {"name": "Sedan",        "type": "car",      "base_price_per_day": 1400,  "base_price_per_hour": 180,  "security_deposit": 4000,  "sort_order": 2},
        {"name": "SUV",          "type": "car",      "base_price_per_day": 2200,  "base_price_per_hour": 280,  "security_deposit": 6000,  "sort_order": 3},
        {"name": "Luxury Car",   "type": "luxury",   "base_price_per_day": 8000,  "base_price_per_hour": 1000, "security_deposit": 20000, "sort_order": 4},
        {"name": "Sports Bike",  "type": "bike",     "base_price_per_day": 1200,  "base_price_per_hour": 160,  "security_deposit": 3000,  "sort_order": 5},
        {"name": "Scooter",      "type": "bike",     "base_price_per_day": 600,   "base_price_per_hour": 80,   "security_deposit": 1500,  "sort_order": 6},
        {"name": "Electric SUV", "type": "electric", "base_price_per_day": 2500,  "base_price_per_hour": 320,  "security_deposit": 7000,  "sort_order": 7},
        {"name": "Electric Bike","type": "electric", "base_price_per_day": 800,   "base_price_per_hour": 110,  "security_deposit": 2000,  "sort_order": 8},
    ]
    categories = []
    for cd in categories_data:
        c, _ = VehicleCategory.objects.get_or_create(name=cd["name"], defaults=cd)
        categories.append(c)
    print(f"  ✓ {len(categories)} vehicle categories created")

    # ── 4. Vehicles ──────────────────────────────────────────
    vehicles_data = [
        # Hatchbacks
        {"make": "Maruti Suzuki", "model": "Swift",      "variant": "ZXI+",    "year": 2022, "color": "White",   "fuel_type": "petrol",  "cat": "Hatchback"},
        {"make": "Hyundai",       "model": "i20",        "variant": "Asta",    "year": 2023, "color": "Silver",  "fuel_type": "petrol",  "cat": "Hatchback"},
        {"make": "Tata",          "model": "Altroz",     "variant": "XZ+",     "year": 2022, "color": "Blue",    "fuel_type": "petrol",  "cat": "Hatchback"},
        # Sedans
        {"make": "Honda",         "model": "City",       "variant": "ZX CVT",  "year": 2023, "color": "Red",     "fuel_type": "petrol",  "cat": "Sedan"},
        {"make": "Maruti Suzuki", "model": "Ciaz",       "variant": "Alpha",   "year": 2022, "color": "Pearl",   "fuel_type": "petrol",  "cat": "Sedan"},
        {"make": "Hyundai",       "model": "Verna",      "variant": "SX+",     "year": 2023, "color": "Black",   "fuel_type": "petrol",  "cat": "Sedan"},
        # SUVs
        {"make": "Toyota",        "model": "Innova Crysta", "variant": "ZX",   "year": 2022, "color": "Beige",   "fuel_type": "diesel",  "cat": "SUV"},
        {"make": "Hyundai",       "model": "Creta",      "variant": "SX(O)",   "year": 2023, "color": "White",   "fuel_type": "diesel",  "cat": "SUV"},
        {"make": "Kia",           "model": "Seltos",     "variant": "HTX+",    "year": 2023, "color": "Grey",    "fuel_type": "petrol",  "cat": "SUV"},
        {"make": "Mahindra",      "model": "Scorpio-N",  "variant": "Z8",      "year": 2022, "color": "Black",   "fuel_type": "diesel",  "cat": "SUV"},
        # Luxury
        {"make": "BMW",           "model": "5 Series",   "variant": "530i M",  "year": 2023, "color": "Black",   "fuel_type": "petrol",  "cat": "Luxury Car"},
        {"make": "Mercedes-Benz", "model": "E-Class",    "variant": "E220d",   "year": 2022, "color": "White",   "fuel_type": "diesel",  "cat": "Luxury Car"},
        {"make": "Audi",          "model": "A6",         "variant": "45 TFSI", "year": 2023, "color": "Grey",    "fuel_type": "petrol",  "cat": "Luxury Car"},
        # Bikes
        {"make": "Royal Enfield", "model": "Classic 350","variant": "Signals", "year": 2022, "color": "Chrome",  "fuel_type": "petrol",  "cat": "Sports Bike"},
        {"make": "Bajaj",         "model": "Pulsar NS200","variant": "ABS",    "year": 2023, "color": "Black",   "fuel_type": "petrol",  "cat": "Sports Bike"},
        {"make": "Honda",         "model": "Activa 6G",  "variant": "DLX",     "year": 2023, "color": "White",   "fuel_type": "petrol",  "cat": "Scooter"},
        {"make": "TVS",           "model": "Jupiter",    "variant": "ZX",      "year": 2022, "color": "Blue",    "fuel_type": "petrol",  "cat": "Scooter"},
        # Electric
        {"make": "Tata",          "model": "Nexon EV Max","variant": "XZ+ LUX","year": 2023, "color": "Pristine","fuel_type": "electric", "cat": "Electric SUV"},
        {"make": "MG",            "model": "ZS EV",      "variant": "Exclusive","year": 2023, "color": "White",  "fuel_type": "electric", "cat": "Electric SUV"},
        {"make": "Ather",         "model": "450X",       "variant": "Pro",     "year": 2023, "color": "Grey",    "fuel_type": "electric", "cat": "Electric Bike"},
    ]

    cat_map = {c.name: c for c in categories}
    states_rto = {"Tamil Nadu": "TN", "Maharashtra": "MH", "Karnataka": "KA", "Delhi": "DL", "Telangana": "TS"}
    vehicles = []
    for i, vd in enumerate(vehicles_data):
        branch = branches[i % len(branches)]
        rto = states_rto.get(branch.state, "KA")
        reg_num = f"{rto}-{random.randint(1,99):02d}-{chr(65+random.randint(0,25))}{chr(65+random.randint(0,25))}-{random.randint(1000,9999)}"

        v, _ = Vehicle.objects.get_or_create(
            make=vd["make"], model=vd["model"], variant=vd.get("variant",""),
            defaults={
                "registration_number": reg_num,
                "year": vd["year"],
                "color": vd["color"],
                "category": cat_map[vd["cat"]],
                "branch": branch,
                "fuel_type": vd["fuel_type"],
                "seating_capacity": 2 if vd["cat"] in ["Sports Bike","Scooter","Electric Bike"] else 5,
                "odometer_reading": random.randint(5000, 80000),
                "total_trips": random.randint(10, 200),
                "average_rating": round(random.uniform(3.5, 5.0), 2),
                "status": random.choices(
                    ["available", "rented", "maintenance"],
                    weights=[60, 30, 10]
                )[0],
            }
        )
        vehicles.append(v)
    print(f"  ✓ {len(vehicles)} vehicles seeded")

    # ── 5. Drivers ───────────────────────────────────────────
    driver_names = [
        ("Ramesh", "Kumar"), ("Vikram", "Sharma"), ("Ravi", "Pillai"),
        ("Anil", "Tiwari"), ("Sunil", "Nair"), ("Prem", "Das"),
        ("Gopal", "Reddy"), ("Sanjay", "Patil"), ("Murugan", "S"),
        ("Dinesh", "Rao"),
    ]
    drivers = []
    for i, (fn, ln) in enumerate(driver_names):
        email = f"driver.{fn.lower()}.{ln.lower()}@fleetpro.in"
        u, _ = User.objects.get_or_create(
            email=email,
            defaults={
                "first_name": fn, "last_name": ln,
                "role": User.Role.DRIVER,
                "is_email_verified": True,
                "branch": branches[i % len(branches)],
            }
        )
        u.set_password("Driver@12345")
        u.save()

        d, _ = Driver.objects.get_or_create(
            user=u,
            defaults={
                "employee_id": f"EMP{100+i:04d}",
                "branch": branches[i % len(branches)],
                "dl_number": f"TN{random.randint(10,99)}{random.randint(10000,99999)}",
                "dl_expiry_date": date.today() + timedelta(days=random.randint(365, 1825)),
                "experience_years": random.randint(3, 20),
                "availability_status": random.choice(["available", "on_duty", "available"]),
                "daily_rate": Decimal(str(random.choice([500, 600, 700, 800]))),
                "monthly_salary": Decimal(str(random.randint(18000, 32000))),
                "total_trips": random.randint(20, 400),
                "average_rating": round(random.uniform(3.5, 5.0), 2),
            }
        )
        drivers.append(d)
    print(f"  ✓ {len(drivers)} drivers seeded")

    # ── 6. Customers ─────────────────────────────────────────
    customer_names = [
        ("Arjun", "Reddy"), ("Priya", "Mehta"), ("Neha", "Joshi"),
        ("Karan", "Verma"), ("Meena", "Gupta"), ("Rahul", "Singh"),
        ("Sneha", "Iyer"), ("Aditya", "Kumar"), ("Pooja", "Shah"),
        ("Vijay", "Nair"), ("Ananya", "Das"), ("Rohan", "Patel"),
        ("Divya", "Sharma"), ("Suresh", "Pillai"), ("Kavya", "Reddy"),
    ]
    customers = []
    for i, (fn, ln) in enumerate(customer_names):
        email = f"{fn.lower()}.{ln.lower()}{i}@example.com"
        u, _ = User.objects.get_or_create(
            email=email,
            defaults={
                "first_name": fn, "last_name": ln,
                "role": User.Role.CUSTOMER,
                "is_email_verified": True,
                "phone": f"+919{random.randint(100000000, 999999999)}",
            }
        )
        u.set_password("Customer@12345")
        u.save()

        kyc = random.choices(["verified", "pending", "submitted"], weights=[70, 20, 10])[0]
        cp, _ = CustomerProfile.objects.get_or_create(
            user=u,
            defaults={
                "city": random.choice(["Chennai", "Mumbai", "Delhi", "Bangalore", "Hyderabad"]),
                "state": random.choice(["Tamil Nadu", "Maharashtra", "Delhi", "Karnataka", "Telangana"]),
                "dl_number": f"TN{random.randint(10,99)}{random.randint(10000,99999)}",
                "dl_expiry_date": date.today() + timedelta(days=random.randint(365, 1825)),
                "kyc_status": kyc,
                "total_bookings": random.randint(0, 30),
                "total_spend": Decimal(str(random.randint(0, 200000))),
                "loyalty_points": random.randint(0, 5000),
            }
        )
        customers.append(cp)
    print(f"  ✓ {len(customers)} customers seeded")

    # ── 7. Sample Bookings ───────────────────────────────────
    statuses = [
        Booking.Status.COMPLETED, Booking.Status.COMPLETED,
        Booking.Status.ACTIVE, Booking.Status.CONFIRMED,
        Booking.Status.PENDING, Booking.Status.CANCELLED,
    ]
    booking_count = 0
    for i in range(30):
        customer = random.choice(customers)
        vehicle = random.choice(vehicles)
        driver = random.choice(drivers) if random.random() > 0.5 else None
        status = random.choice(statuses)

        days_ago = random.randint(0, 90)
        duration = random.randint(1, 7)
        pickup_dt = timezone.now() - timedelta(days=days_ago)
        return_dt = pickup_dt + timedelta(days=duration)

        booking_num = f"BK-{2024+(i//20)}-{1000+i:04d}"
        if Booking.objects.filter(booking_number=booking_num).exists():
            continue

        daily_rate = vehicle.get_daily_rate()
        base_amount = daily_rate * duration
        gst = base_amount * Decimal("0.18")
        deposit = vehicle.get_security_deposit()
        total = base_amount + gst + deposit

        b = Booking.objects.create(
            booking_number=booking_num,
            customer=customer,
            vehicle=vehicle,
            driver=driver if random.random() > 0.4 else None,
            created_by=admin,
            pickup_datetime=pickup_dt,
            return_datetime=return_dt,
            actual_return_datetime=return_dt if status == Booking.Status.COMPLETED else None,
            pickup_location=f"Branch, {vehicle.branch.city}",
            drop_location=f"Branch, {vehicle.branch.city}",
            pickup_branch=vehicle.branch,
            drop_branch=vehicle.branch,
            status=status,
            payment_status=Payment.PaymentStatus.PAID if status == Booking.Status.COMPLETED else Payment.PaymentStatus.PENDING,
            base_amount=base_amount,
            gst_amount=gst,
            security_deposit=deposit,
            total_amount=total,
            amount_paid=total if status == Booking.Status.COMPLETED else Decimal("0"),
            with_driver=driver is not None,
            confirmed_at=pickup_dt - timedelta(days=1) if status != Booking.Status.PENDING else None,
            activated_at=pickup_dt if status in [Booking.Status.ACTIVE, Booking.Status.COMPLETED] else None,
            completed_at=return_dt if status == Booking.Status.COMPLETED else None,
        )
        booking_count += 1

        # Create payment for completed bookings
        if status == Booking.Status.COMPLETED:
            Payment.objects.create(
                booking=b,
                customer=customer,
                payment_type=Payment.PaymentType.BOOKING_PAYMENT,
                method=random.choice(["upi", "card", "cash", "net_banking"]),
                status=Payment.Status.SUCCESS,
                amount=total,
                taxable_amount=base_amount,
                cgst=gst / 2,
                sgst=gst / 2,
                paid_at=pickup_dt,
            )

    print(f"  ✓ {booking_count} bookings seeded")
    print("\n✅ Seed data complete!")
    print("─" * 50)
    print("Login credentials:")
    print("  Super Admin : admin@fleetpro.in    / Admin@123456")
    print("  Staff       : staff@fleetpro.in    / Staff@123456")
    print("  Driver (ex) : driver.ramesh.kumar@fleetpro.in / Driver@12345")
    print("  Customer(ex): arjun.reddy0@example.com / Customer@12345")
    print("─" * 50)


if __name__ == "__main__":
    seed_all()

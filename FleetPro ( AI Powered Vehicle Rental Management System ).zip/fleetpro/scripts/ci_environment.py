"""Creates test-only configuration for disposable CI. Not production credentials."""
from pathlib import Path
import secrets
Path('.env.production').write_text('\n'.join([
 'DEBUG=False','SECRET_KEY='+secrets.token_urlsafe(48), 'DB_NAME=fleetpro','DB_USER=fleetpro','DB_PASSWORD='+secrets.token_urlsafe(32),'DB_ADMIN_PASSWORD='+secrets.token_urlsafe(32),
 'REDIS_PASSWORD='+secrets.token_urlsafe(32),'ALLOWED_HOSTS=localhost,127.0.0.1,backend','APP_DOMAIN=localhost','TLS_EMAIL=ci@example.invalid','CSRF_TRUSTED_ORIGINS=https://localhost',
 'PRIVATE_UPLOAD_SCAN_REQUIRED=True','EMAIL_HOST=smtp.example.invalid','EMAIL_HOST_USER=','EMAIL_HOST_PASSWORD=',
 'DEFAULT_FROM_EMAIL=noreply@example.invalid','RAZORPAY_KEY_ID=','RAZORPAY_KEY_SECRET=','RAZORPAY_WEBHOOK_SECRET=','FLEETPRO_AI_API_KEY='
])+'\n')
Path('.env.production').chmod(0o600)

#!/usr/bin/env bash
set -euo pipefail
# Run from the project root with an existing .env.production; never echoes secrets.
compose=(docker compose --env-file .env.production -f deployment/docker-compose.yml)
"${compose[@]}" config -q
"${compose[@]}" exec -T backend python manage.py check --deploy --fail-level WARNING
"${compose[@]}" exec -T backend python manage.py migrate --check
"${compose[@]}" exec -T backend python manage.py check_integrations --live

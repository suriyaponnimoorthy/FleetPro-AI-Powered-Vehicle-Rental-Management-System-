#!/usr/bin/env python3
"""Run with Django environment on the backend. Produces authenticated age-encrypted backups.
No restore into the application database is performed by this script.
"""
import os,sys,json,tarfile,tempfile,subprocess,hashlib,datetime
from pathlib import Path
os.environ.setdefault('DJANGO_SETTINGS_MODULE','config.settings')
import django;django.setup()
from django.conf import settings

def main():
    recipient=os.environ.get('BACKUP_AGE_RECIPIENT','')
    if not recipient:raise SystemExit('Set BACKUP_AGE_RECIPIENT (public encryption recipient, never the private identity).')
    db=settings.DATABASES['default']
    if db['ENGINE']!='django.db.backends.postgresql':raise SystemExit('Backups require PostgreSQL.')
    root=Path(os.environ.get('BACKUP_DIR',str(settings.BASE_DIR/'backups')));root.mkdir(mode=0o700,parents=True,exist_ok=True)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=root/f'fleetpro-{stamp}.tar.age'
    with tempfile.TemporaryDirectory(prefix='fleetpro-backup-') as temp:
        temp=Path(temp);dump=temp/'database.dump'
        env={**os.environ,'PGPASSWORD':db.get('PASSWORD','')}
        with dump.open('wb') as stream:
            subprocess.run(['pg_dump','-h',db['HOST'],'-p',str(db.get('PORT') or 5432),'-U',db['USER'],'-d',db['NAME'],'-Fc','--no-owner','--no-acl'],env=env,stdout=stream,check=True)
        archive=temp/'bundle.tar'
        with tarfile.open(archive,'w') as tar:
            tar.add(dump,arcname='database.dump')
            for label,path in [('public-media',settings.MEDIA_ROOT),('private-media',settings.PRIVATE_MEDIA_ROOT)]:
                if Path(path).exists():tar.add(path,arcname=label)
            manifest=temp/'manifest.json';manifest.write_text(json.dumps({'schema':1,'created_at':stamp,'database':db['NAME'],'private_s3_requires_separate_versioned_backup':bool(settings.PRIVATE_S3_BUCKET)}));tar.add(manifest,arcname='manifest.json')
        subprocess.run(['age','-r',recipient,'-o',str(out),str(archive)],check=True)
    out.chmod(0o600)
    digest=hashlib.sha256()
    with out.open('rb') as file:
        for chunk in iter(lambda:file.read(1024*1024),b''):digest.update(chunk)
    status={'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file':out.name,'sha256':digest.hexdigest()}
    bucket=os.environ.get('BACKUP_S3_BUCKET')
    if bucket:
        import boto3
        key='fleetpro/'+out.name;boto3.client('s3').upload_file(str(out),bucket,key,ExtraArgs={'ServerSideEncryption':'AES256'})
        status['offsite_uploaded']=True
    else:status['offsite_uploaded']=False
    Path(settings.BACKUP_STATUS_FILE).parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    temp_status=Path(settings.BACKUP_STATUS_FILE+'.tmp');temp_status.write_text(json.dumps(status));temp_status.chmod(0o600);temp_status.replace(settings.BACKUP_STATUS_FILE)
    print(json.dumps(status))
if __name__=='__main__':main()

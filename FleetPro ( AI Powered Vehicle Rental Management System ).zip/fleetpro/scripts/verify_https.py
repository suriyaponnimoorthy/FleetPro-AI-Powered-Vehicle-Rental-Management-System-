"""Read-only deployed HTTPS checks. Optional --ca points at a private staging CA."""
import argparse,json,ssl,urllib.request,urllib.error
p=argparse.ArgumentParser();p.add_argument('base_url');p.add_argument('--ca');a=p.parse_args()
if not a.base_url.startswith('https://'):raise SystemExit('Use an https:// URL.')
context=ssl.create_default_context(cafile=a.ca)
results={}
for path,wanted in [('/health/ready/',200),('/media/customers/licenses/not-public.pdf',404),('/',200)]:
    try:
        with urllib.request.urlopen(a.base_url.rstrip('/')+path,context=context,timeout=15) as r:code=r.status
    except urllib.error.HTTPError as e:code=e.code
    results[path]={'http_status':code,'passed':code==wanted}
print(json.dumps(results,indent=2))
if not all(x['passed'] for x in results.values()):raise SystemExit(1)

"""Local evaluation only. PostgreSQL remains the production database."""
import os
os.environ.setdefault('SECRET_KEY', 'local-only-fleetpro-key-do-not-deploy')
os.environ.setdefault('DEBUG', 'True')
from .settings import *  # noqa
DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': BASE_DIR / 'local.sqlite3'}}
CACHES = {'default': {'BACKEND': 'django.core.cache.backends.locmem.LocMemCache'}}
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True
CELERY_TASK_STORE_EAGER_RESULT = False
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'testserver']

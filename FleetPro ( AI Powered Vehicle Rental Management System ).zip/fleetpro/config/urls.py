"""
config/urls.py — FleetPro Master URL Configuration
"""
from apps.core.monitoring import metrics
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
    SpectacularRedocView,
)
from rest_framework.routers import DefaultRouter

# ── ViewSets ─────────────────────────────────────────────────
from apps.authentication.browser import csrf_token
from apps.authentication.views import UserViewSet
from apps.vehicles.views import (
    VehicleViewSet, VehicleCategoryViewSet,
    BranchViewSet, MaintenanceViewSet, InsuranceViewSet,
)
from apps.bookings.views import BookingViewSet
from apps.drivers.views import DriverViewSet, DriverAttendanceViewSet
from apps.customers.views import CustomerViewSet
from apps.payments.views import PaymentViewSet, InvoiceViewSet, DamageReportViewSet, PenaltyViewSet
from apps.notifications.views import NotificationViewSet

router = DefaultRouter()
router.register(r"users",              UserViewSet,            basename="user")
router.register(r"vehicles",           VehicleViewSet,         basename="vehicle")
router.register(r"vehicle-categories", VehicleCategoryViewSet, basename="vehicle-category")
router.register(r"branches",           BranchViewSet,          basename="branch")
router.register(r"maintenance",        MaintenanceViewSet,     basename="maintenance")
router.register(r"insurance",          InsuranceViewSet,       basename="insurance")
router.register(r"bookings",           BookingViewSet,         basename="booking")
router.register(r"drivers",            DriverViewSet,          basename="driver")
router.register(r"driver-attendance",  DriverAttendanceViewSet,basename="driver-attendance")
router.register(r"customers",          CustomerViewSet,        basename="customer")
router.register(r"payments",           PaymentViewSet,         basename="payment")
router.register(r"invoices",           InvoiceViewSet,         basename="invoice")
router.register(r"damage-reports",     DamageReportViewSet,    basename="damage-report")
router.register(r"penalties",          PenaltyViewSet,         basename="penalty")
router.register(r"notifications",      NotificationViewSet,    basename="notification")

# ── Analytics (non-router views) ─────────────────────────────
from apps.analytics.views import (
    DashboardSummaryView, MonthlyRevenueView,
    VehicleUtilizationView, TopCustomersView,
    BookingTrendView, DriverPerformanceView, RevenueByBranchView,
)

analytics_patterns = [
    path("dashboard/",            DashboardSummaryView.as_view()),
    path("revenue/monthly/",      MonthlyRevenueView.as_view()),
    path("revenue/by-branch/",    RevenueByBranchView.as_view()),
    path("vehicles/utilization/", VehicleUtilizationView.as_view()),
    path("customers/top/",        TopCustomersView.as_view()),
    path("bookings/trends/",      BookingTrendView.as_view()),
    path("drivers/performance/",  DriverPerformanceView.as_view()),
]

# ── Auth (non-router JWT views) ───────────────────────────────
from apps.authentication.views import (
    CustomTokenObtainView, CustomTokenRefreshView, CustomTokenVerifyView,
    LogoutView, RegisterView, ForgotPasswordView, ResetPasswordView,
    SendOTPView, VerifyOTPView, ChangePasswordView, ProfileView, ActivityLogView,
)

auth_patterns = [
    path("csrf/", csrf_token),
    path("login/",           CustomTokenObtainView.as_view()),
    path("token/refresh/",   CustomTokenRefreshView.as_view()),
    path("token/verify/",    CustomTokenVerifyView.as_view()),
    path("logout/",          LogoutView.as_view()),
    path("register/",        RegisterView.as_view()),
    path("forgot-password/", ForgotPasswordView.as_view()),
    path("reset-password/",  ResetPasswordView.as_view()),
    path("change-password/", ChangePasswordView.as_view()),
    path("send-otp/",        SendOTPView.as_view()),
    path("verify-otp/",      VerifyOTPView.as_view()),
    path("profile/",         ProfileView.as_view()),
    path("activity-logs/",   ActivityLogView.as_view()),
]

# ── Master patterns ───────────────────────────────────────────
urlpatterns = [
    path("internal/metrics", metrics),
    path("admin/",              admin.site.urls),
    path("health/",             include("apps.core.health_urls")),
    path("api/v1/private-documents/", include("apps.core.private_urls")),
    path("api/v1/checkout/", include("apps.commerce.urls")),
    path("api/v1/intelligence/", include("apps.intelligence.urls")),
    path("api/v1/auth/",        include(auth_patterns)),
    path("api/v1/analytics/",   include(analytics_patterns)),
    path("api/v1/",             include(router.urls)),
    path("api/schema/",         SpectacularAPIView.as_view(),                        name="schema"),
    path("api/docs/",           SpectacularSwaggerView.as_view(url_name="schema"),   name="swagger-ui"),
    path("api/redoc/",          SpectacularRedocView.as_view(url_name="schema"),     name="redoc"),
]

if settings.DEBUG:
    urlpatterns += static("/media/vehicles/images/", document_root=settings.MEDIA_ROOT / "vehicles/images")
    urlpatterns += static("/media/profiles/", document_root=settings.MEDIA_ROOT / "profiles")
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

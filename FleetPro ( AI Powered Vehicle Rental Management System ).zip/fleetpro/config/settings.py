"""
FleetPro Vehicle Rental Management System
Production Settings — Django 5.2 LTS
"""

import os
from pathlib import Path
from datetime import timedelta
from urllib.parse import quote, urlsplit, urlunsplit
import environ

BASE_DIR = Path(__file__).resolve().parent.parent
env = environ.Env(DEBUG=(bool, False))
environ.Env.read_env(BASE_DIR / ".env")

SECRET_KEY = env("SECRET_KEY")
DEBUG = env("DEBUG")
ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["localhost", "127.0.0.1"])

# ─── APPLICATIONS ───────────────────────────────────────────────
DJANGO_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "corsheaders",
    "django_filters",
    "drf_spectacular",
    "celery",
    "django_celery_beat",
    "django_celery_results",
    "storages",
    "phonenumber_field",
    "django_otp",
    "django_otp.plugins.otp_totp",
]

LOCAL_APPS = [
    "apps.core",
    "apps.commerce",
    "apps.authentication",
    "apps.vehicles",
    "apps.bookings",
    "apps.drivers",
    "apps.customers",
    "apps.payments",
    "apps.damage",
    "apps.analytics",
    "apps.notifications",
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

# ─── MIDDLEWARE ──────────────────────────────────────────────────
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.authentication.middleware.ActivityLoggingMiddleware",
    "apps.authentication.middleware.RateLimitMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

# ─── DATABASE ────────────────────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("DB_NAME", default="fleetpro_db"),
        "USER": env("DB_USER", default="fleetpro_user"),
        "PASSWORD": env("DB_PASSWORD", default=""),
        "HOST": env("DB_HOST", default="localhost"),
        "PORT": env("DB_PORT", default="5432"),
        "OPTIONS": {
            "connect_timeout": 10,
            "options": "-c statement_timeout=30000",
        },
        "CONN_MAX_AGE": 60,
        "TEST": {"NAME": "test_fleetpro_db"},
    }
}

# ─── AUTH & JWT ──────────────────────────────────────────────────
AUTH_USER_MODEL = "authentication.User"

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.IsAuthenticated",),
    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ],
    "DEFAULT_PAGINATION_CLASS": "config.pagination.StandardResultsPagination",
    "PAGE_SIZE": 20,
    "NUM_PROXIES": env.int("TRUSTED_PROXY_COUNT", default=0),
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
        "rest_framework.throttling.ScopedRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "100/day",
        "user": "1000/day",
        "login": "10/hour",
        "otp": "5/hour",
        "otp_verify": "30/hour",
    },
    "EXCEPTION_HANDLER": "config.exceptions.custom_exception_handler",
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=15),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "UPDATE_LAST_LOGIN": True,
    "CHECK_REVOKE_TOKEN": True,
    "ALGORITHM": "HS256",
    "SIGNING_KEY": env("JWT_SECRET_KEY", default=SECRET_KEY),
    "AUTH_HEADER_TYPES": ("Bearer",),
    "USER_ID_FIELD": "id",
    "USER_ID_CLAIM": "user_id",
    "TOKEN_OBTAIN_SERIALIZER": "apps.authentication.serializers.CustomTokenObtainSerializer",
}

# ─── CELERY / REDIS ──────────────────────────────────────────────
REDIS_URL = env("REDIS_URL", default="redis://localhost:6379/0")
redis_password = env("REDIS_PASSWORD", default="")
if redis_password:
    parsed_redis = urlsplit(REDIS_URL)
    REDIS_URL = urlunsplit(parsed_redis._replace(netloc=f":{quote(redis_password, safe='')}@{parsed_redis.netloc}"))
CELERY_BROKER_URL = REDIS_URL
CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TASK_SERIALIZER = "json"
CELERY_TIMEZONE = "Asia/Kolkata"
CELERY_BEAT_SCHEDULER = "django_celery_beat.schedulers:DatabaseScheduler"
CELERY_TASK_ROUTES = {
    "apps.notifications.tasks.*": {"queue": "notifications"},
    "apps.payments.tasks.*": {"queue": "payments"},
    "apps.bookings.tasks.*": {"queue": "bookings"},
}

# ─── CACHING ─────────────────────────────────────────────────────
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": REDIS_URL,
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "SOCKET_CONNECT_TIMEOUT": 5,
            "SOCKET_TIMEOUT": 5,
            "CONNECTION_POOL_KWARGS": {"max_connections": 50},
        },
        "KEY_PREFIX": "fleetpro",
        "TIMEOUT": 300,
    }
}

# ─── FILE STORAGE (AWS S3 / Cloudinary) ─────────────────────────
USE_S3 = env.bool("USE_S3", default=False)
if USE_S3:
    AWS_ACCESS_KEY_ID = env("AWS_ACCESS_KEY_ID")
    AWS_SECRET_ACCESS_KEY = env("AWS_SECRET_ACCESS_KEY")
    AWS_STORAGE_BUCKET_NAME = env("AWS_STORAGE_BUCKET_NAME")
    AWS_S3_REGION_NAME = env("AWS_S3_REGION_NAME", default="ap-south-1")
    AWS_S3_CUSTOM_DOMAIN = f"{AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com"
    AWS_DEFAULT_ACL = "private"
    AWS_S3_OBJECT_PARAMETERS = {"CacheControl": "max-age=86400"}
    STATIC_URL = '/static/'
    STATIC_ROOT = BASE_DIR / 'staticfiles'
    MEDIA_URL = '/media/'
    MEDIA_ROOT = BASE_DIR / 'media'
    STORAGES = {
        'default': {'BACKEND': 'storages.backends.s3.S3Storage'},
        'staticfiles': {'BACKEND': 'django.contrib.staticfiles.storage.StaticFilesStorage'},
    }
else:
    MEDIA_URL = "/media/"
    MEDIA_ROOT = BASE_DIR / "media"
    STATIC_URL = "/static/"
    STATIC_ROOT = BASE_DIR / "staticfiles"

# ─── EMAIL / SMS ─────────────────────────────────────────────────
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = env("EMAIL_HOST", default="smtp.gmail.com")
EMAIL_PORT = env.int("EMAIL_PORT", default=587)
EMAIL_USE_TLS = env.bool("EMAIL_USE_TLS", default=True)
EMAIL_USE_SSL = env.bool("EMAIL_USE_SSL", default=False)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", default="")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", default="noreply@fleetpro.in")

TWILIO_ACCOUNT_SID = env("TWILIO_ACCOUNT_SID", default="")
TWILIO_AUTH_TOKEN = env("TWILIO_AUTH_TOKEN", default="")
TWILIO_PHONE_NUMBER = env("TWILIO_PHONE_NUMBER", default="")

# ─── CORS ────────────────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = env.list(
    "CORS_ALLOWED_ORIGINS",
    default=["http://localhost:3000", "http://localhost:5173"],
)
CORS_ALLOW_CREDENTIALS = True

# ─── SPECTACULAR (OpenAPI) ───────────────────────────────────────
SPECTACULAR_SETTINGS = {
    "TITLE": "FleetPro Vehicle Rental API",
    "DESCRIPTION": "Production-grade REST API for Vehicle Rental Management System",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "COMPONENT_SPLIT_REQUEST": True,
    "TAGS": [
        {"name": "auth", "description": "Authentication & user management"},
        {"name": "vehicles", "description": "Vehicle fleet management"},
        {"name": "bookings", "description": "Booking lifecycle management"},
        {"name": "drivers", "description": "Driver management"},
        {"name": "customers", "description": "Customer profiles & KYC"},
        {"name": "payments", "description": "Payments, invoices & refunds"},
        {"name": "damage", "description": "Damage reports & fines"},
        {"name": "analytics", "description": "Reports & analytics"},
    ],
}

# ─── SECURITY ────────────────────────────────────────────────────
if not DEBUG:
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_SSL_REDIRECT = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    X_FRAME_OPTIONS = "DENY"

# ─── BUSINESS LOGIC CONSTANTS ────────────────────────────────────
FLEETPRO = {
    "LATE_FEE_PER_HOUR": 100,           # ₹ per hour
    "CANCELLATION_WINDOW_HOURS": 24,    # free cancel window
    "DEFAULT_SECURITY_DEPOSIT": 5000,  # ₹
    "MAX_BOOKING_DAYS": 30,
    "GST_RATE": 0.18,
    "DAMAGE_ASSESSMENT_HOURS": 48,
    "OTP_EXPIRY_MINUTES": 10,
    "CURRENCY": "INR",
    "CURRENCY_SYMBOL": "₹",
}

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{levelname} {asctime} {module} {process:d} {thread:d} {message}",
            "style": "{",
        },
    },
    "handlers": {
        "file": {
            "level": "INFO",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": BASE_DIR / "logs/fleetpro.log",
            "maxBytes": 10 * 1024 * 1024,
            "backupCount": 5,
            "formatter": "verbose",
        },
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
    },
    "root": {"handlers": ["console", "file"], "level": "INFO"},
    "loggers": {
        "django": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},
        "apps": {"handlers": ["console", "file"], "level": "DEBUG", "propagate": False},
    },
}

# Optional server-side language model. No key is shipped to the browser.
FLEETPRO_AI_API_KEY = env('FLEETPRO_AI_API_KEY', default='')
FLEETPRO_AI_MODEL = env('FLEETPRO_AI_MODEL', default='gpt-4.1-mini')
REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']['intelligence'] = '20/minute'

# Provider settings remain server-side; absent credentials disable external operations.
RAZORPAY_KEY_ID=env('RAZORPAY_KEY_ID', default='')
RAZORPAY_KEY_SECRET=env('RAZORPAY_KEY_SECRET', default='')
RAZORPAY_WEBHOOK_SECRET=env('RAZORPAY_WEBHOOK_SECRET', default='')
REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']['checkout']='15/minute'

PRIVATE_MEDIA_ROOT=BASE_DIR/'private_uploads'
PRIVATE_S3_BUCKET=env('PRIVATE_S3_BUCKET',default='')
PRIVATE_S3_ENDPOINT=env('PRIVATE_S3_ENDPOINT',default='')
AWS_PRIVATE_REGION=env('AWS_PRIVATE_REGION',default='ap-south-1')
PRIVATE_UPLOAD_MAX_BYTES=10*1024*1024
PRIVATE_UPLOAD_SCAN_REQUIRED=env.bool('PRIVATE_UPLOAD_SCAN_REQUIRED',default=not DEBUG)
CLAMAV_HOST=env('CLAMAV_HOST',default='clamav')
CLAMAV_PORT=env.int('CLAMAV_PORT',default=3310)
DATA_UPLOAD_MAX_MEMORY_SIZE=11*1024*1024
FILE_UPLOAD_MAX_MEMORY_SIZE=1024*1024

SECURE_REDIRECT_EXEMPT=[r'^health/live/$',r'^internal/metrics$']
CSRF_TRUSTED_ORIGINS=env.list('CSRF_TRUSTED_ORIGINS',default=[])
if env('SENTRY_DSN',default=''):
    import sentry_sdk
    sentry_sdk.init(dsn=env('SENTRY_DSN'),send_default_pii=False,traces_sample_rate=0.05)

METRICS_TOKEN=env('METRICS_TOKEN',default='')
BACKUP_STATUS_FILE=env('BACKUP_STATUS_FILE',default=str(BASE_DIR/'backups/last-success.json'))


SPECTACULAR_SETTINGS['ENUM_NAME_OVERRIDES']={'BookingStatus': 'apps.core.schema_choices.BOOKING_STATUS', 'BookingPaymentStatus': 'apps.core.schema_choices.BOOKING_PAYMENT_STATUS', 'VehicleStatus': 'apps.core.schema_choices.VEHICLE_STATUS', 'MaintenanceStatus': 'apps.core.schema_choices.MAINTENANCE_STATUS', 'PaymentStatus': 'apps.core.schema_choices.PAYMENT_STATUS', 'InvoiceStatus': 'apps.core.schema_choices.INVOICE_STATUS', 'DamageStatus': 'apps.core.schema_choices.DAMAGE_STATUS', 'PenaltyStatus': 'apps.core.schema_choices.PENALTY_STATUS', 'NotificationStatus': 'apps.core.schema_choices.NOTIFICATION_STATUS', 'VehicleFuel': 'apps.core.schema_choices.FUEL', 'VehicleTransmission': 'apps.core.schema_choices.TRANSMISSION', 'UserRole': 'apps.core.schema_choices.USER_ROLE', 'ChatHistoryRole': 'apps.core.schema_choices.HISTORY_ROLE', 'AttendanceStatus': 'apps.core.schema_choices.ATTENDANCE_STATUS'}

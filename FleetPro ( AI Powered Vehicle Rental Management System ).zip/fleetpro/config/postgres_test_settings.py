"""Real PostgreSQL test profile; no SQLite substitution permitted."""
from .local_settings import *
DATABASES={'default':env.db('TEST_DATABASE_URL')}
DATABASES['default']['CONN_MAX_AGE']=0
DATABASES['default']['TEST']={'NAME':'test_fleetpro_integration'}

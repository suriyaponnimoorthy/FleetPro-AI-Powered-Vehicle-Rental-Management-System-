"""
config/celery.py — Celery application configuration
"""

import os
from celery import Celery
from celery.signals import task_failure, task_success
from django.conf import settings

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

app = Celery("fleetpro")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

# ── Scheduled Tasks ───────────────────────────────────────────
from celery.schedules import crontab

app.conf.beat_schedule = {
    "process-overdue-bookings": {
        "task": "apps.bookings.tasks.process_overdue_bookings",
        "schedule": crontab(minute="*/30"),
    },
    "auto-complete-stale-bookings": {
        "task": "apps.bookings.tasks.auto_complete_bookings",
        "schedule": crontab(hour=2, minute=0),
    },
    "send-maintenance-alerts": {
        "task": "apps.bookings.tasks.send_maintenance_alerts",
        "schedule": crontab(hour=8, minute=0),
    },
    "daily-revenue-report": {
        "task": "apps.payments.tasks.generate_daily_revenue_report",
        "schedule": crontab(hour=23, minute=55),
    },
}


# ── Signal Handlers ───────────────────────────────────────────
@task_failure.connect
def on_task_failure(sender, task_id, exception, traceback, **kwargs):
    import logging
    logger = logging.getLogger("apps.tasks")
    logger.error(f"Task {sender.name}[{task_id}] failed: {exception}")
    try:
        import sentry_sdk
        sentry_sdk.capture_exception(exception)
    except ImportError:
        pass


@app.task(bind=True)
def debug_task(self):
    print(f"Request: {self.request!r}")

app.conf.beat_schedule['worker-heartbeat']={'task':'apps.core.tasks.worker_heartbeat','schedule':60.0}

app.conf.beat_schedule['nightly-encrypted-backup']={'task':'apps.core.tasks.nightly_backup','schedule':crontab(hour=2,minute=30),'options':{'queue':'backup'}}

app.conf.beat_schedule["dispatch-cancellation-refunds"] = {
    "task": "apps.commerce.tasks.dispatch_cancellation_refunds",
    "schedule": 60.0,
    "options": {"queue": "payments"},
}

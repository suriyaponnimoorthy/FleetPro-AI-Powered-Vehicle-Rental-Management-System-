"""
config/exceptions.py  — Custom DRF exception handler
config/pagination.py  — Standard pagination
apps/core/health_urls.py — Health check endpoint
"""

# ─── config/exceptions.py ────────────────────────────────────

import logging
from django.db import IntegrityError, DatabaseError
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import exception_handler
from rest_framework.exceptions import (
    ValidationError, AuthenticationFailed, NotAuthenticated,
    PermissionDenied, NotFound, Throttled,
)

logger = logging.getLogger("apps.exceptions")


def custom_exception_handler(exc, context):
    """
    Standardized error response format:
    {
        "error": "Human-readable error message",
        "code": "ERROR_CODE",
        "details": { ... }  # Optional field-level errors
    }
    """
    response = exception_handler(exc, context)

    if response is None:
        # Handle unhandled exceptions
        if isinstance(exc, IntegrityError):
            logger.error(f"DB IntegrityError: {exc}")
            return Response(
                {"error": "Database constraint violation. Please check your input.",
                 "code": "DB_INTEGRITY_ERROR"},
                status=status.HTTP_409_CONFLICT,
            )
        if isinstance(exc, DatabaseError):
            logger.error(f"DatabaseError: {exc}")
            return Response(
                {"error": "A database error occurred. Please try again.",
                 "code": "DB_ERROR"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
        logger.exception(f"Unhandled exception: {exc}")
        return Response(
            {"error": "An unexpected error occurred. Our team has been notified.",
             "code": "INTERNAL_ERROR"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

    # Standardize the response body
    error_data = response.data
    if isinstance(exc, ValidationError):
        return Response(
            {
                "error": "Validation failed. Please check your input.",
                "code": "VALIDATION_ERROR",
                "details": error_data,
            },
            status=response.status_code,
        )

    if isinstance(exc, AuthenticationFailed):
        return Response(
            {"error": "Authentication credentials are invalid.", "code": "AUTHENTICATION_FAILED"},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    if isinstance(exc, NotAuthenticated):
        return Response(
            {"error": "Authentication required. Please provide a valid token.", "code": "NOT_AUTHENTICATED"},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    if isinstance(exc, PermissionDenied):
        return Response(
            {"error": "You do not have permission to perform this action.", "code": "PERMISSION_DENIED"},
            status=status.HTTP_403_FORBIDDEN,
        )

    if isinstance(exc, NotFound):
        return Response(
            {"error": "The requested resource was not found.", "code": "NOT_FOUND"},
            status=status.HTTP_404_NOT_FOUND,
        )

    if isinstance(exc, Throttled):
        return Response(
            {
                "error": f"Too many requests. Try again in {exc.wait} seconds.",
                "code": "RATE_LIMITED",
                "retry_after": exc.wait,
            },
            status=status.HTTP_429_TOO_MANY_REQUESTS,
        )

    # Fallback — wrap existing response data
    if isinstance(error_data, dict) and "detail" in error_data:
        response.data = {"error": str(error_data["detail"]), "code": "ERROR"}

    return response


# ─── config/pagination.py ────────────────────────────────────

from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response


class StandardResultsPagination(PageNumberPagination):
    """
    Standard pagination: page=1&page_size=20
    Response includes: count, next, previous, total_pages, results
    """
    page_size = 20
    page_size_query_param = "page_size"
    max_page_size = 100
    page_query_param = "page"

    def get_paginated_response(self, data):
        return Response({
            "count": self.page.paginator.count,
            "total_pages": self.page.paginator.num_pages,
            "current_page": self.page.number,
            "page_size": self.get_page_size(self.request),
            "next": self.get_next_link(),
            "previous": self.get_previous_link(),
            "results": data,
        })

    def get_paginated_response_schema(self, schema):
        return {
            "type": "object",
            "properties": {
                "count":        {"type": "integer"},
                "total_pages":  {"type": "integer"},
                "current_page": {"type": "integer"},
                "page_size":    {"type": "integer"},
                "next":         {"type": "string", "nullable": True},
                "previous":     {"type": "string", "nullable": True},
                "results":      schema,
            },
        }


class LargeResultsPagination(PageNumberPagination):
    """For analytics endpoints that return larger datasets."""
    page_size = 100
    page_size_query_param = "page_size"
    max_page_size = 500


# ─── apps/core/health_urls.py ────────────────────────────────

from django.urls import path
from django.http import JsonResponse
from django.db import connection
from django.core.cache import cache
from django.utils import timezone
import redis


def health_check(request):
    """
    Health check endpoint for load balancers and Docker.
    Returns 200 if all services are operational.
    """
    checks = {}
    overall_status = "healthy"

    # Database check
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = f"error: {str(e)}"
        overall_status = "degraded"

    # Redis/Cache check
    try:
        cache.set("health_check", "ok", 10)
        val = cache.get("health_check")
        checks["cache"] = "ok" if val == "ok" else "error"
    except Exception as e:
        checks["cache"] = f"error: {str(e)}"
        overall_status = "degraded"

    http_status = 200 if overall_status == "healthy" else 503
    return JsonResponse(
        {
            "status": overall_status,
            "timestamp": timezone.now().isoformat(),
            "version": "1.0.0",
            "services": checks,
        },
        status=http_status,
    )


def readiness_check(request):
    """Kubernetes readiness probe."""
    return JsonResponse({"status": "ready"})


health_urlpatterns = [
    path("",        health_check,   name="health-check"),
    path("ready/",  readiness_check, name="readiness-check"),
]

from apps.core.private_files import private_storage, validate_private_file
"""
apps/drivers/models.py — Driver profile model
apps/customers/models.py — Customer profile model
"""

import uuid
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


# ═══════════════════════════════════════════════════════════════
#  DRIVER
# ═══════════════════════════════════════════════════════════════

class CustomerProfile(models.Model):
    """
    Extended customer profile with KYC, documents, loyalty points.
    Linked 1:1 to auth User.
    """

    class KYCStatus(models.TextChoices):
        PENDING   = "pending",   "Pending"
        SUBMITTED = "submitted", "Documents Submitted"
        VERIFIED  = "verified",  "Verified"
        REJECTED  = "rejected",  "Rejected"

    class Gender(models.TextChoices):
        MALE        = "male",        "Male"
        FEMALE      = "female",      "Female"
        OTHER       = "other",       "Other"
        PREFER_NOT  = "prefer_not",  "Prefer Not to Say"

    id                       = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user                     = models.OneToOneField(
        "authentication.User", on_delete=models.CASCADE, related_name="customer_profile"
    )
    date_of_birth            = models.DateField(null=True, blank=True)
    gender                   = models.CharField(max_length=10, choices=Gender.choices, blank=True)
    address                  = models.TextField(blank=True)
    city                     = models.CharField(max_length=100, blank=True, db_index=True)
    state                    = models.CharField(max_length=100, blank=True)
    pincode                  = models.CharField(max_length=10, blank=True)

    # Emergency contact
    emergency_contact_name   = models.CharField(max_length=200, blank=True)
    emergency_contact_phone  = models.CharField(max_length=20, blank=True)

    # Driving license
    dl_number                = models.CharField(max_length=50, blank=True, db_index=True)
    dl_expiry_date           = models.DateField(null=True, blank=True)
    dl_document              = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="customers/licenses/", blank=True)

    # KYC documents
    aadhar_number            = models.CharField(max_length=20, blank=True)
    aadhar_document          = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="customers/aadhar/", blank=True)
    pan_number               = models.CharField(max_length=10, blank=True)
    pan_document             = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="customers/pan/", blank=True)
    selfie_with_id           = models.ImageField(storage=private_storage, validators=[validate_private_file], upload_to="customers/selfie/", blank=True)

    # KYC status
    kyc_status               = models.CharField(
        max_length=20, choices=KYCStatus.choices, default=KYCStatus.PENDING, db_index=True
    )
    kyc_verified_at          = models.DateTimeField(null=True, blank=True)
    kyc_verified_by          = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="kyc_verified_customers"
    )
    kyc_rejection_reason     = models.TextField(blank=True)

    # Aggregated stats (updated by triggers)
    total_bookings           = models.PositiveIntegerField(default=0)
    total_spend              = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    loyalty_points           = models.PositiveIntegerField(default=0)

    # Account standing
    is_blacklisted           = models.BooleanField(default=False, db_index=True)
    blacklist_reason         = models.TextField(blank=True)
    blacklisted_by           = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="blacklisted_customers"
    )
    blacklisted_at           = models.DateTimeField(null=True, blank=True)

    # Preferences
    preferred_vehicle_type   = models.CharField(max_length=20, blank=True)
    notes                    = models.TextField(blank=True)

    created_at               = models.DateTimeField(auto_now_add=True)
    updated_at               = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer_profiles"
        indexes = [
            models.Index(fields=["kyc_status"]),
            models.Index(fields=["is_blacklisted"]),
            models.Index(fields=["city", "kyc_status"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.get_full_name()} — Customer"

    @property
    def is_dl_valid(self):
        from django.utils import timezone
        if self.dl_expiry_date:
            return self.dl_expiry_date >= timezone.now().date()
        return False

    @property
    def tier(self):
        """Loyalty tier based on total spend."""
        if self.total_spend >= 200000:
            return "Platinum"
        elif self.total_spend >= 50000:
            return "Gold"
        elif self.total_spend >= 10000:
            return "Silver"
        return "Bronze"

# apps/customers/admin.py
from django.contrib import admin
from apps.customers.models import CustomerProfile


@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display  = ("user", "city", "kyc_status", "is_blacklisted",
                     "total_bookings", "total_spend", "loyalty_points")
    list_filter   = ("kyc_status", "is_blacklisted")
    search_fields = ("user__email", "user__first_name", "dl_number", "aadhar_number")
    readonly_fields = ("total_bookings", "total_spend", "loyalty_points",
                       "kyc_verified_at", "blacklisted_at", "created_at", "updated_at")
    ordering      = ("-created_at",)

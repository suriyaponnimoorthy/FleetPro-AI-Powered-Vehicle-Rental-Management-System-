# apps/customers/serializers.py
# Serializers defined in apps/drivers/serializers.py (combined module)
# Re-export for clean imports

from apps.drivers.serializers import CustomerListSerializer, CustomerDetailSerializer  # noqa

__all__ = ["CustomerListSerializer", "CustomerDetailSerializer"]

"""
apps/customers/views.py — re-export from drivers/views.py combined file
"""
# CustomerViewSet is defined in apps/drivers/views.py (combined file)
# Import here for the router
from apps.drivers.views import CustomerViewSet  # noqa

__all__ = ["CustomerViewSet"]

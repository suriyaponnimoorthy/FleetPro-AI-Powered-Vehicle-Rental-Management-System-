# apps/customers/filters.py
import django_filters
from apps.customers.models import CustomerProfile


class CustomerFilter(django_filters.FilterSet):
    kyc_status    = django_filters.MultipleChoiceFilter(choices=CustomerProfile.KYCStatus.choices)
    city          = django_filters.CharFilter(field_name="city", lookup_expr="iexact")
    spend_min     = django_filters.NumberFilter(field_name="total_spend", lookup_expr="gte")
    spend_max     = django_filters.NumberFilter(field_name="total_spend", lookup_expr="lte")
    is_blacklisted = django_filters.BooleanFilter()
    joined_from   = django_filters.DateFilter(field_name="created_at__date", lookup_expr="gte")
    joined_to     = django_filters.DateFilter(field_name="created_at__date", lookup_expr="lte")

    class Meta:
        model  = CustomerProfile
        fields = ["kyc_status", "is_blacklisted", "city"]

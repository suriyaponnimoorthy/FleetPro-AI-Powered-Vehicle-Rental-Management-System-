from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
import logging
from datetime import timedelta
from decimal import Decimal
from rest_framework import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.throttling import UserRateThrottle
from django.conf import settings
from django.utils import timezone
from apps.vehicles.serializers import VehicleListSerializer
from apps.bookings.models import Booking
from .services import eligible_inventory, rank_inventory, language_response, ai_rerank

logger = logging.getLogger(__name__)

class IntelligenceThrottle(UserRateThrottle):
    scope = 'intelligence'

class PreferenceSerializer(serializers.Serializer):
    seats = serializers.IntegerField(min_value=1, max_value=50, default=1)
    budget_per_day = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=Decimal('1'), required=False)
    city = serializers.CharField(max_length=100, required=False, allow_blank=True)
    category = serializers.ChoiceField(choices=['car', 'bike', 'luxury', 'electric', 'commercial'], required=False, allow_blank=True)
    fuel_type = serializers.ChoiceField(choices=['petrol', 'diesel', 'electric', 'hybrid', 'cng'], required=False, allow_blank=True)
    transmission = serializers.ChoiceField(choices=['manual', 'automatic', 'cvt'], required=False, allow_blank=True)
    pickup_datetime = serializers.DateTimeField(required=False)
    return_datetime = serializers.DateTimeField(required=False)
    use_history = serializers.BooleanField(default=False)
    use_ai = serializers.BooleanField(default=False)
    trip_brief = serializers.CharField(max_length=1000, required=False, allow_blank=True)

    def validate(self, data):
        start, end = data.get('pickup_datetime'), data.get('return_datetime')
        if bool(start) != bool(end):
            raise serializers.ValidationError('Supply both pickup and return dates.')
        if start and (start < timezone.now() or end <= start):
            raise serializers.ValidationError('Select a future pickup and a later return.')
        if start and end - start > timedelta(days=settings.FLEETPRO['MAX_BOOKING_DAYS']):
            raise serializers.ValidationError('Rental duration exceeds the maximum.')
        return data

class RecommendationView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_classes = [IntelligenceThrottle]

    @extend_schema(request=PreferenceSerializer,responses=OpenApiTypes.OBJECT)
    def post(self, request):
        serializer = PreferenceSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        prefs = serializer.validated_data
        history = ()
        if prefs['use_history'] and getattr(request.user, 'role', '') == 'customer':
            history = set(str(x) for x in Booking.objects.filter(customer__user=request.user,
                status='completed').values_list('vehicle__category_id', flat=True).distinct())
        ranked = rank_inventory(eligible_inventory(prefs, request.user), prefs, history)[:12]
        engine = 'content-based-v1'
        ai_status = 'disabled'
        if prefs.get('use_ai') and prefs.get('trip_brief'):
            if settings.FLEETPRO_AI_API_KEY and ranked:
                try:
                    ranked = ai_rerank(ranked, prefs['trip_brief'])
                    engine = 'ai-reranked-v1'
                    ai_status = 'applied'
                except Exception:
                    ai_status = 'unavailable; used content-based ranking'
                    logger.warning('AI reranking unavailable; used content-based ranking')
            else:
                ai_status = 'not configured or no eligible candidates; used content-based ranking'
        results = []
        for item in ranked:
            vehicle = VehicleListSerializer(item['vehicle'], context={'request': request}).data
            results.append({**vehicle, 'match_score': item['score'], 'reasons': item['reasons']})
        return Response({'results': results, 'engine': engine, 'ai_status': ai_status,
            'score_note': 'Preference score, not a probability or learned prediction.',
            'availability_checked': bool(prefs.get('pickup_datetime')),
            'message': 'No matches. Try another city, lower seat count, or higher budget.' if not results else '',
            'generated_at': timezone.now().isoformat()})

class HistoryItemSerializer(serializers.Serializer):
    role = serializers.ChoiceField(choices=['user', 'assistant'])
    content = serializers.CharField(max_length=1500)

class ChatSerializer(serializers.Serializer):
    message = serializers.CharField(max_length=1500)
    history = HistoryItemSerializer(many=True, max_length=8, default=list)
    allow_external_ai = serializers.BooleanField(default=False)

class ChatView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_classes = [IntelligenceThrottle]

    @extend_schema(request=ChatSerializer,responses=OpenApiTypes.OBJECT)
    def post(self, request):
        serializer = ChatSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        text = data['message'].lower()
        mode = 'local-guide'
        if any(x in text for x in ['bookings', 'my booking', 'my trip', 'my journey', 'reservation status']):
            mode = 'account-guide'
            if getattr(request.user, 'role', '') == 'customer':
                bookings = Booking.objects.filter(customer__user=request.user).order_by('-created_at')[:3]
                lines = [f"{b.booking_number}: {b.status}; return {b.return_datetime:%d %b %Y %H:%M %Z}." for b in bookings]
                answer = '\n'.join(lines) or 'You have no bookings yet. Find a vehicle in the collection to get started.'
            else:
                answer = 'Use Bookings to view the reservations permitted for your role.'
        elif any(x in text for x in ['refund', 'cancel', 'policy', 'deposit', 'kyc', 'document', 'payment']):
            answer = ('A verified customer profile is required to request a rental. Rates shown are per day; '
                'tax and the refundable security deposit are itemized before a booking request. '
                'For cancellation, refunds or document support, contact an employee through your rental branch. '
                'I cannot process payments or change reservations.')
        elif settings.FLEETPRO_AI_API_KEY and data['allow_external_ai']:
            vehicles = list(eligible_inventory({}, request.user)[:20])
            inventory = [{'name': v.display_name, 'city': v.branch.city,
                'daily_rate_inr': str(v.get_daily_rate()), 'seats': v.seating_capacity,
                'fuel': v.fuel_type, 'transmission': v.transmission} for v in vehicles]
            try:
                answer = language_response(data['message'], data['history'], inventory)
                mode = 'ai-concierge'
            except Exception:
                logger.warning('AI provider unavailable; returned local guidance')
                answer = 'The AI concierge is temporarily unavailable. Use Find my match to compare vehicles with live inventory, or ask about your bookings or rental requirements.'
                mode = 'local-fallback'
        else:
            answer = ('Tell the match finder your city, daily budget, passenger count and travel dates. '
                'It checks inventory and explains each recommendation. I can also help with your bookings, '
                'deposits and rental requirements. General conversational AI requires the server integration '
                'and your consent below.')
        return Response({'answer': answer, 'mode': mode, 'can_execute_actions': False})

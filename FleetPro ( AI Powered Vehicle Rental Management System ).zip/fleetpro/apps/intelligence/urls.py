from django.urls import path
from .views import RecommendationView, ChatView
urlpatterns = [path('recommendations/', RecommendationView.as_view()), path('chat/', ChatView.as_view())]

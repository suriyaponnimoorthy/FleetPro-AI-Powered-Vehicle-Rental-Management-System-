# apps/notifications/serializers.py
from rest_framework import serializers
from apps.notifications.models import NotificationLog


class NotificationLogSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True)
    is_read    = serializers.SerializerMethodField()

    class Meta:
        model  = NotificationLog
        fields = [
            "id", "user", "user_email", "channel", "type",
            "subject", "body", "status", "is_read",
            "metadata", "sent_at", "read_at", "created_at",
        ]
        read_only_fields = ["id", "user", "created_at", "sent_at"]

    def get_is_read(self, obj) -> bool:
        return obj.status == NotificationLog.Status.READ

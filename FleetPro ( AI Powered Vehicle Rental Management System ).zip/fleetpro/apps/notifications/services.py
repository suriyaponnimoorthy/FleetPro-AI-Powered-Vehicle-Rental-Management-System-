import logging
from django.conf import settings
from django.utils import timezone
from .models import NotificationLog
logger=logging.getLogger(__name__)

class NotificationService:
    def _log(self,user,channel,subject='',status='sent',metadata=None):
        # Do not persist OTPs, identity documents, or complete email bodies in logs.
        return NotificationLog.objects.create(user=user,channel=channel,type='delivery',subject=subject,
            body='',status=status,metadata=metadata or {},sent_at=timezone.now() if status=='sent' else None)

    def send_email(self,user,subject,template,context):
        from django.core.mail import EmailMultiAlternatives
        from django.template.loader import render_to_string
        from django.utils.html import strip_tags
        html=render_to_string(template,context)
        try:
            email=EmailMultiAlternatives(subject,strip_tags(html),settings.DEFAULT_FROM_EMAIL,[user.email])
            email.attach_alternative(html,'text/html')
            if email.send(fail_silently=False)!=1:raise RuntimeError('Email not accepted')
        except Exception:
            self._log(user,'email',subject,'failed');logger.warning('Email delivery failed for user %s',user.pk);raise
        self._log(user,'email',subject);return True

    def send_sms(self,user,message):
        if not user.phone:
            self._log(user,'sms',status='failed',metadata={'reason':'missing_recipient'});return False
        if not(settings.TWILIO_ACCOUNT_SID and settings.TWILIO_AUTH_TOKEN and settings.TWILIO_PHONE_NUMBER):
            self._log(user,'sms',status='failed',metadata={'reason':'not_configured'});return False
        try:
            from twilio.rest import Client
            result=Client(settings.TWILIO_ACCOUNT_SID,settings.TWILIO_AUTH_TOKEN).messages.create(body=message,from_=settings.TWILIO_PHONE_NUMBER,to=str(user.phone))
            # Acceptance is distinct from delivered. Status is updated via a later authenticated provider fetch.
            self._log(user,'sms',status='pending',metadata={'sid':result.sid,'provider_status':result.status})
            return True
        except Exception:
            self._log(user,'sms',status='failed');logger.warning('SMS delivery failed for user %s',user.pk);raise

    def create_in_app_notification(self,user,notification_type,title,body,metadata=None):
        NotificationLog.objects.create(user=user,channel='in_app',type=notification_type,subject=title,body=body[:2000],status='sent',metadata=metadata or {},sent_at=timezone.now())

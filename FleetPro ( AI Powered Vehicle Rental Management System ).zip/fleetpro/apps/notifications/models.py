"""
apps/notifications/models.py  — Notification log model
apps/notifications/serializers.py — Serializer
apps/notifications/services.py — re-export (defined in payments/views.py)
"""

import uuid
from django.db import models


class NotificationLog(models.Model):
    """Persisted log of every notification sent to a user."""

    class Channel(models.TextChoices):
        EMAIL  = "email",  "Email"
        SMS    = "sms",    "SMS"
        PUSH   = "push",   "Push"
        IN_APP = "in_app", "In-App"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        SENT    = "sent",    "Sent"
        FAILED  = "failed",  "Failed"
        READ    = "read",    "Read"

    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user       = models.ForeignKey(
        "authentication.User", on_delete=models.CASCADE, related_name="notifications"
    )
    channel    = models.CharField(max_length=10, choices=Channel.choices, db_index=True)
    type       = models.CharField(max_length=50, db_index=True)
    subject    = models.CharField(max_length=300, blank=True)
    body       = models.TextField()
    status     = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    metadata   = models.JSONField(default=dict, blank=True)
    sent_at    = models.DateTimeField(null=True, blank=True)
    read_at    = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = "notification_logs"
        indexes  = [
            models.Index(fields=["user", "status", "created_at"]),
            models.Index(fields=["channel", "status"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return f"[{self.channel}] {self.type} → {self.user.email}"


# ──────────────────────────────────────────────────────────────
# apps/notifications/serializers.py
# ──────────────────────────────────────────────────────────────

from rest_framework import serializers


class NotificationLogSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True)
    is_read    = serializers.SerializerMethodField()

    class Meta:
        model  = NotificationLog
        fields = [
            "id", "user", "user_email", "channel", "type",
            "subject", "body", "status", "is_read",
            "metadata", "sent_at", "read_at", "created_at",
        ]
        read_only_fields = ["id", "user", "created_at", "sent_at"]

    def get_is_read(self, obj):
        return obj.status == NotificationLog.Status.READ

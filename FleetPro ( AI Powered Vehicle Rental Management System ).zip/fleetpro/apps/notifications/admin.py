# apps/notifications/admin.py
from django.contrib import admin
from apps.notifications.models import NotificationLog


@admin.register(NotificationLog)
class NotificationLogAdmin(admin.ModelAdmin):
    list_display  = ("user", "channel", "type", "status", "sent_at", "created_at")
    list_filter   = ("channel", "status", "type")
    search_fields = ("user__email", "subject")
    readonly_fields = ("created_at", "sent_at", "read_at")

"""
apps/notifications/views.py  — re-export from payments/views.py
apps/notifications/services.py — NotificationService
"""
from apps.payments.views import NotificationViewSet, NotificationService  # noqa

__all__ = ["NotificationViewSet", "NotificationService"]

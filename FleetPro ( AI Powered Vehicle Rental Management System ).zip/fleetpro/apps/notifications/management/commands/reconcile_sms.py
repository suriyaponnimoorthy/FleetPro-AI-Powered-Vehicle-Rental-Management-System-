from django.core.management.base import BaseCommand,CommandError
from django.conf import settings
from django.utils import timezone
from apps.notifications.models import NotificationLog
class Command(BaseCommand):
    help='Read provider SMS delivery statuses; never sends a message.'
    def handle(self,*args,**options):
        if not(settings.TWILIO_ACCOUNT_SID and settings.TWILIO_AUTH_TOKEN):raise CommandError('Twilio credentials not configured.')
        from twilio.rest import Client
        client=Client(settings.TWILIO_ACCOUNT_SID,settings.TWILIO_AUTH_TOKEN)
        checked=0
        for row in NotificationLog.objects.filter(channel='sms',status='pending').order_by('created_at')[:200]:
            sid=row.metadata.get('sid')
            if not sid:continue
            try:message=client.messages(sid).fetch()
            except Exception:raise CommandError('Provider fetch failed; no delivery status assumed.')
            row.metadata={**row.metadata,'provider_status':message.status}
            if message.status=='delivered':row.status='sent';row.sent_at=timezone.now()
            elif message.status in ['failed','undelivered']:row.status='failed'
            row.save(update_fields=['status','metadata','sent_at']);checked+=1
        self.stdout.write(f'{checked} delivery statuses checked.')

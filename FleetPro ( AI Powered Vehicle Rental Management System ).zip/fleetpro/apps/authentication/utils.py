import secrets

def generate_otp():
    return str(secrets.randbelow(1000000)).zfill(6)

def get_client_ip(request):
    # Forwarded headers require a trusted proxy configuration; do not trust arbitrary clients.
    return request.META.get('REMOTE_ADDR', '127.0.0.1')

def get_device_type(request):
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    return 'mobile' if any(x in ua for x in ['android', 'iphone', 'mobile']) else 'desktop'

def otp_digest(user_id, purpose, destination, code):
    from django.utils.crypto import salted_hmac

    return salted_hmac("fleetpro.otp.v1", f"{user_id}:{purpose}:{destination}:{code}",
                       algorithm="sha256").hexdigest()

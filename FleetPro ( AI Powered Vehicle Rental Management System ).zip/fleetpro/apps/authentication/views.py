"""
apps/authentication/views.py
JWT auth flows: login, register, OTP, refresh, logout, password reset.
"""

import logging
from django.utils import timezone
from django.db import transaction
from django.utils.crypto import constant_time_compare
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken
from django.contrib.auth import get_user_model
from rest_framework import status, generics, viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.exceptions import AuthenticationFailed, ValidationError
from rest_framework_simplejwt.views import (
    TokenObtainPairView, TokenRefreshView, TokenVerifyView
)
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.utils import get_md5_hash_password
from .browser import COOKIE, COOKIE_PATH, require_csrf, set_refresh_cookie
from rest_framework_simplejwt.exceptions import TokenError
from drf_spectacular.utils import extend_schema
from apps.core.access import scope

from .models import OTPVerification, UserSession, ActivityLog
from .serializers import (
    UserRegistrationSerializer, UserProfileSerializer,
    CustomTokenObtainSerializer, ChangePasswordSerializer,
    ForgotPasswordSerializer, ResetPasswordSerializer,
    SendOTPSerializer, VerifyOTPSerializer,
    ActivityLogSerializer, UserDetailSerializer, LogoutRequestSerializer,
)
from .permissions import IsSuperAdmin, IsAdminOrStaff
from .utils import otp_digest, get_client_ip, get_device_type

logger = logging.getLogger("apps.authentication")
User = get_user_model()


def consume_otp(user, purpose, code):
    """Called while holding the user row lock."""
    record = user.otps.filter(otp_type=purpose, is_used=False).order_by("-created_at").first()
    if not record or not record.is_valid:
        return False
    destination = str(user.phone or "") if purpose == OTPVerification.OTPType.PHONE_VERIFY else user.email
    digest = otp_digest(user.pk, purpose, destination, code)
    valid = bool(destination and destination == record.destination and constant_time_compare(record.code, digest))
    record.attempts += 1
    record.is_used = valid or record.attempts >= 3
    record.save(update_fields=["attempts", "is_used"])
    return valid


def revoke_sessions(user):
    tokens = OutstandingToken.objects.filter(user=user, expires_at__gt=timezone.now())
    BlacklistedToken.objects.bulk_create(
        [BlacklistedToken(token=token) for token in tokens], ignore_conflicts=True
    )
    UserSession.objects.filter(user=user, is_active=True).update(is_active=False)


class CustomTokenObtainView(TokenObtainPairView):
    """
    POST /api/v1/auth/login/
    Returns access + refresh tokens. Tracks session and IP.
    Enforces account lockout after 5 failed attempts.
    """
    serializer_class = CustomTokenObtainSerializer
    permission_classes = [AllowAny]
    throttle_scope = "login"

    @extend_schema(summary="Login — obtain JWT tokens", tags=["auth"])
    @transaction.atomic
    def post(self, request, *args, **kwargs):
        browser = request.headers.get("X-FleetPro-Browser") == "1"
        if browser:
            require_csrf(request)
        serializer = self.get_serializer(data=request.data)
        email = request.data.get("email", "")

        try:
            user = User.objects.select_for_update().get(email=email)
        except User.DoesNotExist:
            return Response(
                {"error": "Invalid credentials."},
                status=status.HTTP_401_UNAUTHORIZED
            )

        if user.is_locked:
            return Response(
                {"error": "Account locked due to too many failed attempts. Try again in 30 minutes."},
                status=status.HTTP_423_LOCKED
            )

        try:
            serializer.is_valid(raise_exception=True)
        except (AuthenticationFailed, ValidationError):
            user.increment_failed_login()
            remaining = max(0, 5 - user.failed_login_attempts)
            return Response(
                {
                    "error": "Invalid credentials.",
                    "attempts_remaining": remaining,
                },
                status=status.HTTP_401_UNAUTHORIZED
            )

        # Successful login
        user.reset_failed_login()
        user.last_login_ip = get_client_ip(request)
        user.last_login = timezone.now()
        user.save(update_fields=["failed_login_attempts", "locked_until", "last_login_ip", "last_login"])

        tokens = serializer.validated_data

        # Record session
        refresh_token = tokens.get("refresh")
        if refresh_token:
            try:
                from rest_framework_simplejwt.tokens import RefreshToken as RT
                rt = RT(refresh_token)
                UserSession.objects.create(
                    user=user,
                    refresh_token_jti=rt["jti"],
                    ip_address=get_client_ip(request),
                    user_agent=request.META.get("HTTP_USER_AGENT", "")[:500],
                    device_type=get_device_type(request),
                )
            except Exception:
                pass

        ActivityLog.objects.create(
            user=user,
            action=ActivityLog.Action.LOGIN,
            ip_address=get_client_ip(request),
            user_agent=request.META.get("HTTP_USER_AGENT", "")[:500],
            description=f"User logged in from {get_client_ip(request)}",
        )

        response = Response({
            **tokens,
            "user": {
                "id": str(user.id),
                "email": user.email,
                "full_name": user.get_full_name(),
                "role": getattr(user, 'role', ''),
                "is_kyc_verified": user.is_kyc_verified,
            }
        })
        return set_refresh_cookie(response) if browser else response


class RevocableRefreshSerializer(TokenRefreshSerializer):
    @transaction.atomic
    def validate(self, attrs):
        token = RefreshToken(attrs["refresh"])
        user = User.objects.select_for_update().filter(
            pk=token[api_settings.USER_ID_CLAIM], is_active=True
        ).first()
        if not user or token.get(api_settings.REVOKE_TOKEN_CLAIM) != get_md5_hash_password(user.password):
            raise TokenError("Session revoked.")
        # Revalidate blacklisting under the same user lock as password reset and rotation.
        return super().validate(attrs)


class CustomTokenRefreshView(TokenRefreshView):
    serializer_class = RevocableRefreshSerializer

    @extend_schema(summary="Refresh access token", tags=["auth"])
    def post(self, request, *args, **kwargs):
        if request.headers.get("X-FleetPro-Browser") != "1":
            return super().post(request, *args, **kwargs)
        require_csrf(request)
        from rest_framework_simplejwt.exceptions import InvalidToken

        refresh = request.COOKIES.get(COOKIE)
        if not refresh:
            raise InvalidToken("Session expired or revoked.")
        serializer = self.get_serializer(data={"refresh": refresh})
        try:
            serializer.is_valid(raise_exception=True)
        except TokenError as error:
            raise InvalidToken("Session expired or revoked.") from error
        return set_refresh_cookie(Response(serializer.validated_data))


class CustomTokenVerifyView(TokenVerifyView):
    @extend_schema(summary="Verify token validity", tags=["auth"])
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)


class LogoutView(APIView):

    """
    POST /api/v1/auth/logout/
    Blacklists refresh token and invalidates session.
    """
    permission_classes = [AllowAny]
    serializer_class = LogoutRequestSerializer

    @extend_schema(summary="Logout — blacklist refresh token", tags=["auth"],
                   request=LogoutRequestSerializer, responses={200: {"type": "object"}})
    def post(self, request):
        browser = request.headers.get("X-FleetPro-Browser") == "1"
        if browser:
            require_csrf(request)
            refresh = request.COOKIES.get(COOKIE)
        elif request.user.is_authenticated:
            refresh = request.data.get("refresh")
        else:
            return Response({"error": "Authentication required."}, status=401)

        if refresh:
            try:
                token = RefreshToken(refresh)
                user_id = token[api_settings.USER_ID_CLAIM]
                if browser or str(request.user.pk) == str(user_id):
                    with transaction.atomic():
                        user = User.objects.select_for_update().get(pk=user_id)
                        token = RefreshToken(refresh)
                        token.blacklist()
                        UserSession.objects.filter(user=user, refresh_token_jti=token["jti"]).update(is_active=False)
                        ActivityLog.objects.create(user=user, action=ActivityLog.Action.LOGOUT,
                                                   ip_address=get_client_ip(request))
            except (TokenError, User.DoesNotExist):
                pass

        response = Response({"message": "Logged out successfully."})
        if browser:
            response.delete_cookie(COOKIE, path=COOKIE_PATH, samesite="Strict")
        response["Cache-Control"] = "no-store"
        return response


class RegisterView(generics.CreateAPIView):
    """
    POST /api/v1/auth/register/
    Public customer registration.
    """
    serializer_class = UserRegistrationSerializer
    permission_classes = [AllowAny]
    throttle_scope = "anon"

    @extend_schema(summary="Register new customer account", tags=["auth"])
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save(role=User.Role.CUSTOMER)

        # Auto-send email OTP for verification
        from .tasks import send_otp_task
        send_otp_task.delay(str(user.id), OTPVerification.OTPType.EMAIL_VERIFY)

        return Response(
            {
                "message": "Registration successful. Please verify your email.",
                "user_id": str(user.id),
                "email": user.email,
            },
            status=status.HTTP_201_CREATED,
        )


class ForgotPasswordView(APIView):
    serializer_class = ForgotPasswordSerializer
    permission_classes = [AllowAny]
    throttle_scope = "otp"

    @extend_schema(summary="Request password reset OTP", tags=["auth"])
    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data["email"]

        try:
            user = User.objects.get(email=email, is_active=True)
            from .tasks import send_otp_task
            send_otp_task.delay(str(user.id), OTPVerification.OTPType.PASSWORD_RESET)
        except User.DoesNotExist:
            pass  # Don't reveal if email exists

        return Response({"message": "If the email exists, a reset OTP has been sent."})


class ResetPasswordView(APIView):
    throttle_scope = "otp_verify"
    serializer_class = ResetPasswordSerializer
    permission_classes = [AllowAny]

    @extend_schema(summary="Reset password using OTP", tags=["auth"])
    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            user = User.objects.select_for_update().filter(
                email=serializer.validated_data["email"], is_active=True
            ).first()
            if not user or not consume_otp(user, OTPVerification.OTPType.PASSWORD_RESET,
                                           serializer.validated_data["otp"]):
                return Response({"error": "Invalid or expired OTP."}, status=400)
            user.set_password(serializer.validated_data["new_password"])
            user.save(update_fields=["password"])
            revoke_sessions(user)

        return Response({"message": "Password reset successful. Please login."})


class SendOTPView(APIView):
    serializer_class = SendOTPSerializer
    permission_classes = [IsAuthenticated]
    throttle_scope = "otp"

    @extend_schema(summary="Send OTP to email or phone", tags=["auth"])
    def post(self, request):
        serializer = SendOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        otp_type = serializer.validated_data["otp_type"]

        from .tasks import send_otp_task
        send_otp_task.delay(str(request.user.id), otp_type)
        return Response({"message": f"OTP sent for {otp_type}."})


class VerifyOTPView(APIView):
    throttle_scope = "otp_verify"
    serializer_class = VerifyOTPSerializer
    permission_classes = [IsAuthenticated]

    @extend_schema(summary="Verify OTP code", tags=["auth"])
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        otp_type = serializer.validated_data["otp_type"]
        with transaction.atomic():
            user = User.objects.select_for_update().get(pk=request.user.pk)
            if not consume_otp(user, otp_type, serializer.validated_data["code"]):
                return Response({"error": "Invalid or expired OTP."}, status=400)
            if otp_type == OTPVerification.OTPType.EMAIL_VERIFY:
                user.is_email_verified = True
                user.save(update_fields=["is_email_verified"])
            elif otp_type == OTPVerification.OTPType.PHONE_VERIFY:
                user.is_phone_verified = True
                user.save(update_fields=["is_phone_verified"])

        return Response({"message": "OTP verified successfully.", "verified": True})


class ChangePasswordView(APIView):
    serializer_class = ChangePasswordSerializer
    permission_classes = [IsAuthenticated]

    @extend_schema(summary="Change password (authenticated)", tags=["auth"])
    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            user = User.objects.select_for_update().get(pk=request.user.pk)
            if not user.check_password(serializer.validated_data["current_password"]):
                return Response({"error": "Current password is incorrect."}, status=400)
            user.set_password(serializer.validated_data["new_password"])
            user.save(update_fields=["password"])
            revoke_sessions(user)
        return Response({"message": "Password changed successfully."})


class ProfileView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/v1/auth/profile/"""
    serializer_class = UserProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user


class UserViewSet(viewsets.ModelViewSet):
    """
    Admin user management.
    GET    /api/v1/users/           — list all users
    POST   /api/v1/users/           — create user
    GET    /api/v1/users/{id}/      — user detail
    PATCH  /api/v1/users/{id}/      — update user
    DELETE /api/v1/users/{id}/      — deactivate user
    POST   /api/v1/users/{id}/activate/   — reactivate
    POST   /api/v1/users/{id}/deactivate/ — deactivate
    """
    queryset = User.objects.all().select_related("branch")
    serializer_class = UserDetailSerializer
    permission_classes = [IsAdminOrStaff]
    filterset_fields = ["role", "is_active", "is_kyc_verified", "branch"]
    search_fields = ["email", "first_name", "last_name", "phone"]
    ordering_fields = ["date_joined", "last_login", "role"]

    def get_queryset(self):
        return scope(super().get_queryset(), self.request.user)

    def get_permissions(self):
        if self.action not in ["list", "retrieve"]:
            return [IsSuperAdmin()]
        return [IsAdminOrStaff()]

    def destroy(self, request, *args, **kwargs):
        # Soft delete — deactivate instead of delete
        user = self.get_object()
        user.is_active = False
        user.save(update_fields=["is_active"])
        return Response({"message": "User deactivated."}, status=status.HTTP_200_OK)

    from rest_framework.decorators import action as drf_action

    @drf_action(detail=True, methods=["post"])
    def activate(self, request, pk=None):
        user = self.get_object()
        user.is_active = True
        user.failed_login_attempts = 0
        user.locked_until = None
        user.save(update_fields=["is_active", "failed_login_attempts", "locked_until"])
        return Response({"message": f"User {user.email} activated."})

    @drf_action(detail=True, methods=["post"])
    def deactivate(self, request, pk=None):
        user = self.get_object()
        user.is_active = False
        user.save(update_fields=["is_active"])
        return Response({"message": f"User {user.email} deactivated."})


class ActivityLogView(generics.ListAPIView):
    """GET /api/v1/auth/activity-logs/ — paginated audit trail"""
    serializer_class = ActivityLogSerializer
    permission_classes = [IsAdminOrStaff]
    filterset_fields = ["action", "model_name"]
    search_fields = ["user__email", "description", "object_id"]
    ordering = ["-timestamp"]

    def get_queryset(self):
        qs = scope(ActivityLog.objects.select_related("user"), self.request.user, "user__branch")
        user_id = self.request.query_params.get("user_id")
        if user_id:
            qs = qs.filter(user_id=user_id)
        return qs

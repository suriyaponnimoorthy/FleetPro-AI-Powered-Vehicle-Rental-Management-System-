from django.contrib.auth.hashers import check_password, make_password
from django.db import migrations


def retire_credentials(apps, schema_editor):
    database = schema_editor.connection.alias
    User = apps.get_model("authentication", "User")
    OTP = apps.get_model("authentication", "OTPVerification")
    Session = apps.get_model("authentication", "UserSession")
    Outstanding = apps.get_model("token_blacklist", "OutstandingToken")
    Blacklisted = apps.get_model("token_blacklist", "BlacklistedToken")

    OTP.objects.using(database).filter(destination="").update(is_used=True, code="")
    User.objects.using(database).filter(is_phone_verified=True).update(is_phone_verified=False)
    drivers = User.objects.using(database).filter(role="driver").only("pk", "password")
    for user in drivers.iterator(chunk_size=100):
        if check_password("Driver@123!", user.password):
            drivers.filter(pk=user.pk).update(password=make_password(None))
            Session.objects.using(database).filter(user_id=user.pk).update(is_active=False)
            tokens = Outstanding.objects.using(database).filter(user_id=user.pk)
            Blacklisted.objects.using(database).bulk_create(
                [Blacklisted(token_id=pk) for pk in tokens.values_list("pk", flat=True)],
                ignore_conflicts=True,
            )


class Migration(migrations.Migration):
    dependencies = [
        ("authentication", "0003_bind_otp_destination"),
        ("token_blacklist", "0013_alter_blacklistedtoken_options_and_more"),
    ]
    operations = [migrations.RunPython(retire_credentials, migrations.RunPython.noop)]

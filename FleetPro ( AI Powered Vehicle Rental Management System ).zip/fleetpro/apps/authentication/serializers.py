"""
apps/authentication/serializers.py
JWT token serializer + user registration, profile, OTP serializers.
"""

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import ActivityLog, OTPVerification

User = get_user_model()


class CustomTokenObtainSerializer(TokenObtainPairSerializer):
    """Extends JWT serializer to embed user role in token payload."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["role"]            = user.role
        token["email"]           = user.email
        token["is_kyc_verified"] = user.is_kyc_verified
        return token


class UserRegistrationSerializer(serializers.ModelSerializer):
    password         = serializers.CharField(write_only=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model  = User
        fields = ["email", "first_name", "last_name", "phone", "password", "confirm_password"]

    def validate(self, attrs):
        if attrs["password"] != attrs.pop("confirm_password"):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        return attrs

    def validate_email(self, value):
        if User.objects.filter(email=value.lower()).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value.lower()

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        # Auto-create customer profile
        from apps.customers.models import CustomerProfile
        CustomerProfile.objects.get_or_create(user=user)
        return user


class UserProfileSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source="get_full_name", read_only=True)

    class Meta:
        model  = User
        fields = [
            "id", "email", "first_name", "last_name", "full_name",
            "phone", "role", "profile_photo",
            "is_email_verified", "is_phone_verified", "is_kyc_verified",
            "date_joined", "last_login",
        ]
        read_only_fields = [
            "id", "email", "role", "is_email_verified",
            "is_phone_verified", "is_kyc_verified", "date_joined", "last_login",
        ]


    def update(self, instance, validated_data):
        from django.db import transaction
        from .models import OTPVerification

        with transaction.atomic():
            instance = User.objects.select_for_update().get(pk=instance.pk)
            if "phone" in validated_data and str(validated_data["phone"] or "") != str(instance.phone or ""):
                validated_data["is_phone_verified"] = False
                OTPVerification.objects.filter(user=instance, otp_type=OTPVerification.OTPType.PHONE_VERIFY,
                                               is_used=False).update(is_used=True)
            return super().update(instance, validated_data)


class UserDetailSerializer(serializers.ModelSerializer):
    """Admin-level user detail — includes branch, login metadata."""
    full_name   = serializers.CharField(source="get_full_name", read_only=True)
    branch_name = serializers.CharField(source="branch.name", read_only=True, allow_null=True)

    class Meta:
        model  = User
        fields = [
            "id", "email", "first_name", "last_name", "full_name",
            "phone", "role", "profile_photo",
            "branch", "branch_name",
            "is_active", "is_staff",
            "is_email_verified", "is_phone_verified", "is_kyc_verified",
            "date_joined", "last_login", "last_login_ip",
            "failed_login_attempts", "locked_until",
        ]
        read_only_fields = [
            "id", "date_joined", "last_login", "last_login_ip",
            "failed_login_attempts", "locked_until",
        ]


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField()
    new_password     = serializers.CharField(validators=[validate_password])
    confirm_password = serializers.CharField()

    def validate_current_password(self, value):
        user = self.context["request"].user
        if not user.check_password(value):
            raise serializers.ValidationError("Current password is incorrect.")
        return value

    def validate(self, attrs):
        if attrs["new_password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        if attrs["new_password"] == attrs["current_password"]:
            raise serializers.ValidationError(
                {"new_password": "New password must be different from current."}
            )
        return attrs


class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()


class ResetPasswordSerializer(serializers.Serializer):
    email        = serializers.EmailField()
    otp          = serializers.CharField(max_length=6, min_length=6)
    new_password = serializers.CharField(validators=[validate_password])
    confirm_password = serializers.CharField()

    def validate(self, attrs):
        if attrs["new_password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        return attrs


class SendOTPSerializer(serializers.Serializer):
    otp_type = serializers.ChoiceField(choices=OTPVerification.OTPType.choices)


class VerifyOTPSerializer(serializers.Serializer):
    otp_type = serializers.ChoiceField(choices=OTPVerification.OTPType.choices)
    code     = serializers.CharField(max_length=6, min_length=6)


class ActivityLogSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source="user.email", read_only=True, allow_null=True)
    user_name  = serializers.SerializerMethodField()

    class Meta:
        model  = ActivityLog
        fields = [
            "id", "user", "user_email", "user_name",
            "action", "model_name", "object_id",
            "description", "ip_address",
            "changes", "timestamp",
        ]

    def get_user_name(self, obj) -> str | None:
        if obj.user:
            return obj.user.get_full_name()
        return "System"


class LogoutRequestSerializer(serializers.Serializer):
    refresh=serializers.CharField()

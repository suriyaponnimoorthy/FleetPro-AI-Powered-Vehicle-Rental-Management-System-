"""Same-origin browser session transport. API clients may still use bearer tokens."""
from django.conf import settings
from django.middleware.csrf import CsrfViewMiddleware, get_token
from django.views.decorators.cache import never_cache
from django.http import JsonResponse
from rest_framework.exceptions import PermissionDenied

COOKIE = "fleetpro_refresh"
COOKIE_PATH = "/api/v1/auth/"


@never_cache
def csrf_token(request):
    return JsonResponse({"csrfToken": get_token(request)})


def require_csrf(request):
    middleware = CsrfViewMiddleware(lambda req: None)
    middleware.process_request(request._request)
    if middleware.process_view(request._request, lambda req: None, (), {}) is not None:
        raise PermissionDenied("CSRF verification failed.")


def set_refresh_cookie(response):
    refresh = response.data.pop("refresh", None)
    if refresh:
        response.set_cookie(COOKIE, refresh, path=COOKIE_PATH, httponly=True,
                            secure=not settings.DEBUG, samesite="Strict",
                            max_age=int(settings.SIMPLE_JWT["REFRESH_TOKEN_LIFETIME"].total_seconds()))
    response["Cache-Control"] = "no-store"
    return response

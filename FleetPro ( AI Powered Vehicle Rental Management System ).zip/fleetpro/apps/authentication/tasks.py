from celery import shared_task
from django.conf import settings
from django.db import transaction
from django.core.mail import send_mail
from django.utils import timezone
from .models import User, OTPVerification
from .utils import generate_otp, otp_digest

@shared_task
def send_otp_task(user_id, otp_type):
    with transaction.atomic():
        user = User.objects.select_for_update().filter(id=user_id, is_active=True).first()
        if user is None:
            return
        destination = str(user.phone or "") if otp_type == "phone_verify" else user.email
        if not destination:
            return
        recent = OTPVerification.objects.filter(user=user, otp_type=otp_type,
            created_at__gte=timezone.now() - timezone.timedelta(hours=1))
        if recent.count() >= 5 or recent.filter(destination=destination,
            created_at__gte=timezone.now() - timezone.timedelta(minutes=1)
        ).exists():
            return
        code = generate_otp()
        OTPVerification.objects.filter(user=user, otp_type=otp_type, is_used=False).update(is_used=True)
        OTPVerification.objects.create(
            user=user, otp_type=otp_type, destination=destination,
            code=otp_digest(user.pk, otp_type, destination, code),
            expires_at=timezone.now() + timezone.timedelta(minutes=settings.FLEETPRO["OTP_EXPIRY_MINUTES"]),
        )
    if otp_type == 'phone_verify':
        from apps.notifications.services import NotificationService
        NotificationService().send_sms(user, f'FleetPro verification code: {code}. Do not share it.')
    else:
        send_mail('FleetPro verification code', f'Your verification code is {code}. Do not share it.', settings.DEFAULT_FROM_EMAIL, [user.email])

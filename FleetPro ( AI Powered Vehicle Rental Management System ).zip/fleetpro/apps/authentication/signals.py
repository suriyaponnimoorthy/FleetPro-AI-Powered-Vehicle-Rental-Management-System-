"""
apps/authentication/signals.py — Auth signals
apps/bookings/signals.py      — Booking lifecycle signals
"""

# ──────────────────────────────────────────────────────────────
# apps/authentication/signals.py
# ──────────────────────────────────────────────────────────────

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model

User = get_user_model()


@receiver(post_save, sender=User)
def create_role_profile(sender, instance, created, **kwargs):
    """
    Auto-create CustomerProfile when a customer user is created,
    or DriverProfile stub when a driver user is created.
    """
    if not created:
        return

    if instance.role == "customer":
        try:
            from apps.customers.models import CustomerProfile
            CustomerProfile.objects.get_or_create(user=instance)
        except Exception:
            pass

    elif instance.role == "driver":
        # Driver profile is created explicitly via the admin/API
        # but we ensure the flag is consistent
        pass

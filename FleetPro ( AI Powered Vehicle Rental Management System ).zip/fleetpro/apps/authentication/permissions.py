"""
apps/authentication/permissions.py
Custom DRF permission classes for role-based access control.
"""

from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsSuperAdmin(BasePermission):
    """Only super_admin role."""
    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.is_authenticated and
            request.user.role == "super_admin"
        )


class IsAdminOrAbove(BasePermission):
    """super_admin or admin."""
    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.is_authenticated and
            request.user.role in ["super_admin", "admin"]
        )


class IsAdminOrStaff(BasePermission):
    """super_admin, admin, or staff."""
    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.is_authenticated and
            request.user.role in ["super_admin", "admin", "staff"]
        )


class IsDriver(BasePermission):
    """Driver role only."""
    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.is_authenticated and
            request.user.role == "driver"
        )


class IsCustomer(BasePermission):
    """Customer role only."""
    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.is_authenticated and
            request.user.role == "customer"
        )


class IsOwnerOrAdminOrStaff(BasePermission):
    """
    Object-level: owner (customer/driver) can read/write their own records.
    Admin and staff can access all records.
    """
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

    def has_object_permission(self, request, view, obj):
        user = request.user

        if user.role in ["super_admin", "admin", "staff"]:
            return True

        # Check object ownership
        # Booking: customer owns it
        if hasattr(obj, "customer") and hasattr(obj.customer, "user"):
            if obj.customer.user == user:
                return True

        # Booking: driver owns it (read only)
        if hasattr(obj, "driver") and obj.driver and hasattr(obj.driver, "user"):
            if obj.driver.user == user and request.method in SAFE_METHODS:
                return True

        # CustomerProfile: user owns it
        if hasattr(obj, "user") and obj.user == user:
            return True

        return False


class IsKYCVerified(BasePermission):
    """Customer must have verified KYC."""
    def has_permission(self, request, view):
        if not (request.user and request.user.is_authenticated):
            return False
        if request.user.role != "customer":
            return True  # Non-customers bypass KYC check
        try:
            return request.user.customer_profile.kyc_status == "verified"
        except Exception:
            return False


class ReadOnly(BasePermission):
    """Safe methods only."""
    def has_permission(self, request, view):
        return request.method in SAFE_METHODS

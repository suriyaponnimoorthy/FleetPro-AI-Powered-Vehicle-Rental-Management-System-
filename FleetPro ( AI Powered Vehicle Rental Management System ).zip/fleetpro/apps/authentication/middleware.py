"""
apps/authentication/middleware.py
Request logging, activity tracking, and IP-based rate limiting middleware.
"""

import time
import logging
import json
from django.utils import timezone
from django.core.cache import cache
from django.http import JsonResponse

logger = logging.getLogger("apps.middleware")


class ActivityLoggingMiddleware:
    """
    Logs all mutating API requests (POST/PUT/PATCH/DELETE) to the ActivityLog.
    Captures request metadata, response status, and execution time.
    """

    SKIP_PATHS = ["/health/", "/static/", "/media/", "/admin/jsi18n/"]
    LOG_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start_time = time.monotonic()
        response = self.get_response(request)
        duration_ms = int((time.monotonic() - start_time) * 1000)

        # Skip non-API paths and safe methods
        if (
            request.method in self.LOG_METHODS
            and request.path.startswith("/api/")
            and not any(request.path.startswith(p) for p in self.SKIP_PATHS)
            and hasattr(request, "user")
            and request.user.is_authenticated
        ):
            try:
                self._log_activity(request, response, duration_ms)
            except Exception as e:
                logger.warning(f"ActivityLoggingMiddleware error: {e}")

        return response

    def _log_activity(self, request, response, duration_ms):
        from .models import ActivityLog

        # Map HTTP method to action
        method_action_map = {
            "POST":   ActivityLog.Action.CREATE,
            "PUT":    ActivityLog.Action.UPDATE,
            "PATCH":  ActivityLog.Action.UPDATE,
            "DELETE": ActivityLog.Action.DELETE,
        }

        action = method_action_map.get(request.method, ActivityLog.Action.VIEW)
        path_parts = request.path.strip("/").split("/")
        model_name = path_parts[2].replace("-", "_").title() if len(path_parts) > 2 else ""
        object_id  = path_parts[3] if len(path_parts) > 3 else ""

        ActivityLog.objects.create(
            user=request.user,
            action=action,
            model_name=model_name,
            object_id=object_id,
            description=f"{request.method} {request.path} → {response.status_code} ({duration_ms}ms)",
            ip_address=self._get_client_ip(request),
            user_agent=request.META.get("HTTP_USER_AGENT", "")[:500],
        )

    @staticmethod
    def _get_client_ip(request):
        x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded:
            return x_forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR", "0.0.0.0")


class RateLimitMiddleware:
    """
    IP-based rate limiting using Redis.
    Limits: 200 requests/minute for API endpoints.
    Stricter limits on auth endpoints (handled by DRF throttle).
    """

    RATE_LIMIT = 200       # requests
    WINDOW_SECONDS = 60    # per minute
    EXEMPT_PATHS = ["/health/", "/static/", "/media/"]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.path.startswith("/api/"):
            return self.get_response(request)

        if any(request.path.startswith(p) for p in self.EXEMPT_PATHS):
            return self.get_response(request)

        ip = self._get_client_ip(request)
        cache_key = f"ratelimit:ip:{ip}"

        try:
            count = cache.get(cache_key, 0)
            if count >= self.RATE_LIMIT:
                logger.warning(f"Rate limit exceeded for IP: {ip}")
                return JsonResponse(
                    {
                        "error": "Too many requests. Please slow down.",
                        "retry_after": self.WINDOW_SECONDS,
                    },
                    status=429,
                    headers={"Retry-After": str(self.WINDOW_SECONDS)},
                )
            # Increment counter (set with TTL on first request)
            if count == 0:
                cache.set(cache_key, 1, self.WINDOW_SECONDS)
            else:
                cache.incr(cache_key)
        except Exception:
            pass  # Redis failure: don't block requests

        return self.get_response(request)

    @staticmethod
    def _get_client_ip(request):
        x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded:
            return x_forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR", "0.0.0.0")


class SecurityHeadersMiddleware:
    """Adds security headers not covered by Django settings."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response["X-Content-Type-Options"] = "nosniff"
        response["X-Frame-Options"] = "DENY"
        response["X-XSS-Protection"] = "1; mode=block"
        response["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        return response

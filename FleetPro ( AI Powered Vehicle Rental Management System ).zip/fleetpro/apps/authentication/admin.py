"""
apps/authentication/admin.py  — User, OTP, Session, ActivityLog admin
apps/vehicles/admin.py        — Vehicle, Branch, Category admin
apps/bookings/admin.py        — Booking, Inspection admin
apps/payments/admin.py        — Payment, Invoice, Damage, Penalty admin
apps/drivers/admin.py         — Driver, Attendance admin
apps/customers/admin.py       — CustomerProfile admin
apps/notifications/admin.py   — NotificationLog admin
"""

# ── authentication/admin.py ───────────────────────────────────
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from apps.authentication.models import User, OTPVerification, UserSession, ActivityLog


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display  = ("email", "get_full_name", "role", "is_active", "is_kyc_verified", "date_joined")
    list_filter   = ("role", "is_active", "is_staff", "is_kyc_verified")
    search_fields = ("email", "first_name", "last_name", "phone")
    ordering      = ("-date_joined",)
    readonly_fields = ("date_joined", "last_login", "last_login_ip", "failed_login_attempts")
    fieldsets = (
        (None,            {"fields": ("email", "password")}),
        ("Personal",      {"fields": ("first_name", "last_name", "phone", "profile_photo")}),
        ("Role & Branch", {"fields": ("role", "branch")}),
        ("Verification",  {"fields": ("is_email_verified", "is_phone_verified", "is_kyc_verified")}),
        ("Permissions",   {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Security",      {"fields": ("failed_login_attempts", "locked_until", "last_login_ip"), "classes": ("collapse",)}),
        ("Dates",         {"fields": ("date_joined", "last_login"), "classes": ("collapse",)}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "password1", "password2", "first_name", "last_name", "role")}),
    )


@admin.register(OTPVerification)
class OTPVerificationAdmin(admin.ModelAdmin):
    list_display  = ("user", "otp_type", "is_used", "attempts", "expires_at", "created_at")
    list_filter   = ("otp_type", "is_used")
    search_fields = ("user__email",)
    readonly_fields = ("created_at",)


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display  = ("user", "action", "model_name", "object_id", "ip_address", "timestamp")
    list_filter   = ("action", "model_name")
    search_fields = ("user__email", "description", "object_id")
    readonly_fields = ("timestamp",)
    ordering = ("-timestamp",)



from apps.core.private_files import private_storage, validate_private_file
"""
apps/vehicles/models.py
Fleet management: Branch, Vehicle, Category, Insurance, Maintenance, ServiceHistory.
"""

import uuid
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


class Branch(models.Model):
    """Multi-branch support for the rental business."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    code = models.CharField(max_length=10, unique=True)
    address = models.TextField()
    city = models.CharField(max_length=100, db_index=True)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    opening_time = models.TimeField(default="08:00")
    closing_time = models.TimeField(default="20:00")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "vehicle_branches"
        verbose_name_plural = "branches"

    def __str__(self):
        return f"{self.name} ({self.code})"


class VehicleCategory(models.Model):
    """Vehicle categories with base pricing configuration."""

    class CategoryType(models.TextChoices):
        CAR = "car", "Car"
        BIKE = "bike", "Bike"
        LUXURY = "luxury", "Luxury"
        ELECTRIC = "electric", "Electric"
        COMMERCIAL = "commercial", "Commercial"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)  # Sedan, SUV, Hatchback, etc.
    type = models.CharField(max_length=20, choices=CategoryType.choices)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=100, blank=True)
    base_price_per_day = models.DecimalField(max_digits=10, decimal_places=2)
    base_price_per_hour = models.DecimalField(max_digits=10, decimal_places=2)
    security_deposit = models.DecimalField(max_digits=10, decimal_places=2, default=5000)
    is_active = models.BooleanField(default=True)
    sort_order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        db_table = "vehicle_categories"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return f"{self.name} ({self.type})"


class Vehicle(models.Model):
    """Core vehicle entity with full tracking."""

    class Status(models.TextChoices):
        AVAILABLE = "available", "Available"
        RENTED = "rented", "Currently Rented"
        RESERVED = "reserved", "Reserved"
        MAINTENANCE = "maintenance", "Under Maintenance"
        INACTIVE = "inactive", "Inactive"
        RETIRED = "retired", "Retired"

    class FuelType(models.TextChoices):
        PETROL = "petrol", "Petrol"
        DIESEL = "diesel", "Diesel"
        ELECTRIC = "electric", "Electric"
        HYBRID = "hybrid", "Hybrid"
        CNG = "cng", "CNG"

    class TransmissionType(models.TextChoices):
        MANUAL = "manual", "Manual"
        AUTOMATIC = "automatic", "Automatic"
        CVT = "cvt", "CVT"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    registration_number = models.CharField(max_length=20, unique=True, db_index=True)
    make = models.CharField(max_length=100)          # Toyota
    model = models.CharField(max_length=100)         # Innova Crysta
    variant = models.CharField(max_length=100, blank=True)  # ZX Plus
    year = models.PositiveSmallIntegerField()
    color = models.CharField(max_length=50)

    category = models.ForeignKey(VehicleCategory, on_delete=models.PROTECT, related_name="vehicles")
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="vehicles")

    # Status & availability
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.AVAILABLE, db_index=True)
    is_active = models.BooleanField(default=True)

    # Technical specs
    fuel_type = models.CharField(max_length=20, choices=FuelType.choices)
    transmission = models.CharField(max_length=20, choices=TransmissionType.choices, default=TransmissionType.MANUAL)
    seating_capacity = models.PositiveSmallIntegerField(default=5)
    engine_cc = models.PositiveSmallIntegerField(null=True, blank=True)
    mileage_kmpl = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True)
    odometer_reading = models.PositiveIntegerField(default=0)  # in km

    # Pricing overrides (NULL = use category price)
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    price_per_hour = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    security_deposit = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    # Registration & compliance
    rc_number = models.CharField(max_length=50, blank=True)
    rc_expiry_date = models.DateField(null=True, blank=True)
    fitness_expiry_date = models.DateField(null=True, blank=True)
    permit_expiry_date = models.DateField(null=True, blank=True)
    pollution_expiry_date = models.DateField(null=True, blank=True)

    # GPS
    gps_device_id = models.CharField(max_length=100, blank=True)
    last_known_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    last_known_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    last_location_update = models.DateTimeField(null=True, blank=True)

    # Features
    features = models.JSONField(default=list)  # ["AC", "Music System", "GPS", ...]
    description = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    # Ratings (denormalized for performance)
    total_trips = models.PositiveIntegerField(default=0)
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.00)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "vehicles"
        indexes = [
            models.Index(fields=["status", "branch"]),
            models.Index(fields=["category", "status"]),
            models.Index(fields=["registration_number"]),
            models.Index(fields=["fuel_type", "status"]),
        ]
        ordering = ["make", "model"]

    def __str__(self):
        return f"{self.make} {self.model} — {self.registration_number}"

    @property
    def display_name(self):
        return f"{self.year} {self.make} {self.model}"

    def get_daily_rate(self):
        return self.price_per_day or self.category.base_price_per_day

    def get_security_deposit(self):
        return self.security_deposit or self.category.security_deposit


class VehicleImage(models.Model):
    """Multiple images per vehicle with ordering."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="vehicles/images/")
    caption = models.CharField(max_length=200, blank=True)
    is_primary = models.BooleanField(default=False)
    sort_order = models.PositiveSmallIntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "vehicle_images"
        ordering = ["sort_order"]


class VehicleInsurance(models.Model):
    """Insurance policy tracking per vehicle."""

    class InsuranceType(models.TextChoices):
        COMPREHENSIVE = "comprehensive", "Comprehensive"
        THIRD_PARTY = "third_party", "Third Party"
        ZERO_DEP = "zero_dep", "Zero Depreciation"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="insurance_policies")
    policy_number = models.CharField(max_length=100, unique=True)
    insurance_company = models.CharField(max_length=200)
    insurance_type = models.CharField(max_length=20, choices=InsuranceType.choices)
    start_date = models.DateField()
    end_date = models.DateField(db_index=True)
    premium_amount = models.DecimalField(max_digits=12, decimal_places=2)
    insured_value = models.DecimalField(max_digits=14, decimal_places=2)
    agent_name = models.CharField(max_length=200, blank=True)
    agent_phone = models.CharField(max_length=20, blank=True)
    document = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="vehicles/insurance/", blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "vehicle_insurance"
        indexes = [models.Index(fields=["vehicle", "is_active", "end_date"])]

    @property
    def is_expired(self):
        return self.end_date < timezone.now().date()

    @property
    def days_to_expiry(self):
        delta = self.end_date - timezone.now().date()
        return delta.days


class MaintenanceSchedule(models.Model):
    """Scheduled maintenance tracking."""

    class MaintenanceType(models.TextChoices):
        ROUTINE = "routine", "Routine Service"
        OIL_CHANGE = "oil_change", "Oil Change"
        TIRE_ROTATION = "tire_rotation", "Tire Rotation"
        BRAKE_SERVICE = "brake_service", "Brake Service"
        MAJOR_SERVICE = "major_service", "Major Service"
        REPAIR = "repair", "Repair"
        INSPECTION = "inspection", "Inspection"

    class Status(models.TextChoices):
        SCHEDULED = "scheduled", "Scheduled"
        IN_PROGRESS = "in_progress", "In Progress"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"
        OVERDUE = "overdue", "Overdue"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="maintenance_schedules")
    maintenance_type = models.CharField(max_length=20, choices=MaintenanceType.choices)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SCHEDULED)
    scheduled_date = models.DateField(db_index=True)
    completed_date = models.DateField(null=True, blank=True)
    odometer_at_service = models.PositiveIntegerField(null=True, blank=True)
    next_service_km = models.PositiveIntegerField(null=True, blank=True)
    next_service_date = models.DateField(null=True, blank=True)
    service_center = models.CharField(max_length=200, blank=True)
    technician_name = models.CharField(max_length=200, blank=True)
    estimated_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    actual_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    description = models.TextField(blank=True)
    parts_replaced = models.JSONField(default=list)
    created_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, related_name="maintenance_created"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "vehicle_maintenance_schedules"
        indexes = [
            models.Index(fields=["vehicle", "status"]),
            models.Index(fields=["scheduled_date", "status"]),
        ]
        ordering = ["-scheduled_date"]

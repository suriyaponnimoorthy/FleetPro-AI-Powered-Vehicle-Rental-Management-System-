from apps.core.access import scope, check_relations, BranchWriteMixin, require_branch
"""
apps/vehicles/views.py
Vehicle, Category, Branch, Maintenance, Insurance ViewSets.
"""

import logging
from django.db.models import Q, Avg, Count
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema, OpenApiParameter

from .models import (
    Vehicle, VehicleCategory, Branch,
    VehicleImage, VehicleInsurance, MaintenanceSchedule
)
from .serializers import (
    VehicleListSerializer, VehicleDetailSerializer, VehicleCreateUpdateSerializer,
    VehicleCategorySerializer, BranchSerializer, VehicleImageSerializer,
    InsuranceSerializer, MaintenanceSerializer,
)
from .filters import VehicleFilter
from apps.authentication.permissions import IsAdminOrStaff, ReadOnly

logger = logging.getLogger("apps.vehicles")


class VehicleViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if getattr(user, 'role', '') in ['admin', 'staff', 'super_admin']:
            return scope(qs, user, 'branch')
        return qs if getattr(user, 'role', '') == 'customer' else qs.none()

    """
    Full vehicle fleet management.

    list:       GET  /api/v1/vehicles/           — paginated fleet list
    create:     POST /api/v1/vehicles/            — add vehicle (admin)
    retrieve:   GET  /api/v1/vehicles/{id}/       — vehicle detail
    update:     PUT  /api/v1/vehicles/{id}/       — full update (admin)
    partial:    PATCH /api/v1/vehicles/{id}/      — partial update
    destroy:    DELETE /api/v1/vehicles/{id}/     — soft deactivate

    Extra:
    images:     POST /api/v1/vehicles/{id}/images/       — upload image
    availability: GET /api/v1/vehicles/{id}/availability/ — date range check
    """

    queryset = Vehicle.objects.select_related(
        "category", "branch"
    ).prefetch_related(
        "images", "insurance_policies", "maintenance_schedules"
    ).filter(is_active=True)

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = VehicleFilter
    search_fields = ["make", "model", "registration_number", "variant", "color"]
    ordering_fields = [
        "make", "model", "year", "average_rating",
        "total_trips", "category__base_price_per_day"
    ]
    ordering = ["make", "model"]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_serializer_class(self):
        if self.action == "list":
            return VehicleListSerializer
        if self.action in ["create", "update", "partial_update"]:
            return VehicleCreateUpdateSerializer
        if getattr(self.request.user, 'role', '')=="customer": return VehicleListSerializer
        return VehicleDetailSerializer

    def get_permissions(self):
        if self.action in ["list", "retrieve", "availability"]:
            return [IsAuthenticated()]
        return [IsAdminOrStaff()]

    def destroy(self, request, *args, **kwargs):
        vehicle = self.get_object()
        # Prevent deletion if vehicle has active booking
        from apps.bookings.models import Booking
        if Booking.objects.filter(
            vehicle=vehicle,
            status__in=[Booking.Status.ACTIVE, Booking.Status.CONFIRMED]
        ).exists():
            return Response(
                {"error": "Cannot deactivate a vehicle with active bookings."},
                status=status.HTTP_409_CONFLICT
            )
        vehicle.is_active = False
        vehicle.status = Vehicle.Status.INACTIVE
        vehicle.save(update_fields=["is_active", "status", "updated_at"])
        return Response({"message": "Vehicle deactivated."})

    @extend_schema(summary="Upload vehicle image", tags=["vehicles"])
    @action(detail=True, methods=["post"], url_path="images",
            parser_classes=[MultiPartParser])
    def upload_image(self, request, pk=None):
        vehicle = self.get_object()
        image_file = request.FILES.get("image")
        if not image_file:
            return Response({"error": "No image provided."}, status=400)

        from rest_framework import serializers
        field=serializers.ImageField()
        field.run_validation(image_file)
        if image_file.size>10*1024*1024 or image_file.content_type not in ['image/jpeg','image/png']:
            return Response({'error':'Upload a JPEG or PNG under 10 MiB.'},status=400)
        image_file.seek(0)
        is_primary = request.data.get("is_primary", "false").lower() == "true"
        caption    = request.data.get("caption", "")

        # If marking as primary, unset existing primary
        if is_primary:
            vehicle.images.filter(is_primary=True).update(is_primary=False)

        img = VehicleImage.objects.create(
            vehicle=vehicle,
            image=image_file,
            caption=caption,
            is_primary=is_primary,
        )
        return Response(VehicleImageSerializer(img, context={"request": request}).data,
                        status=status.HTTP_201_CREATED)

    @extend_schema(summary="Check vehicle availability for date range", tags=["vehicles"])
    @action(detail=True, methods=["get"], url_path="availability")
    def availability(self, request, pk=None):
        vehicle = self.get_object()
        pickup  = request.query_params.get("pickup_datetime")
        return_ = request.query_params.get("return_datetime")

        if not pickup or not return_:
            return Response(
                {"error": "pickup_datetime and return_datetime are required."},
                status=status.HTTP_400_BAD_REQUEST
            )

        from apps.bookings.serializers import AvailabilityCheckSerializer
        serializer = AvailabilityCheckSerializer(data={'pickup_datetime': pickup, 'return_datetime': return_})
        serializer.is_valid(raise_exception=True)
        pickup_dt = serializer.validated_data['pickup_datetime']
        return_dt = serializer.validated_data['return_datetime']

        from apps.bookings.models import Booking
        is_available = Booking.check_vehicle_availability(
            vehicle.id, pickup_dt, return_dt
        )

        # Get conflicting bookings if not available
        conflicts = []
        if not is_available and getattr(request.user, 'role', '') in ["admin","staff","super_admin"]:
            from django.db.models import Q
            conflicting = Booking.objects.filter(
                vehicle=vehicle,
                status__in=[Booking.Status.CONFIRMED, Booking.Status.ACTIVE],
            ).filter(
                Q(pickup_datetime__lt=return_dt) & Q(return_datetime__gt=pickup_dt)
            ).values("booking_number", "pickup_datetime", "return_datetime", "status")
            conflicts = list(conflicting)

        return Response({
            "vehicle_id":   str(vehicle.id),
            "vehicle_name": vehicle.display_name,
            "is_available": is_available,
            "status":       vehicle.status,
            "daily_rate":   str(vehicle.get_daily_rate()),
            "conflicts":    conflicts,
            "next_available": self._get_next_available(vehicle) if not is_available else None,
        })

    def _get_next_available(self, vehicle):
        from apps.bookings.models import Booking
        from django.utils import timezone
        last_booking = Booking.objects.filter(
            vehicle=vehicle,
            status__in=[Booking.Status.CONFIRMED, Booking.Status.ACTIVE],
            return_datetime__gte=timezone.now()
        ).order_by("-return_datetime").first()
        return last_booking.return_datetime if last_booking else None

    @extend_schema(summary="Get maintenance history", tags=["vehicles"])
    @action(detail=True, methods=["get"], url_path="maintenance")
    def maintenance(self, request, pk=None):
        vehicle = self.get_object()
        schedules = vehicle.maintenance_schedules.order_by("-scheduled_date")
        return Response(MaintenanceSerializer(schedules, many=True).data)

    @extend_schema(summary="Fleet summary statistics", tags=["vehicles"])
    @action(detail=False, methods=["get"], url_path="fleet-stats")
    def fleet_stats(self, request):
        from apps.bookings.models import Booking
        stats = self.get_queryset().aggregate(
            total=Count("id"),
            available=Count("id", filter=Q(status="available")),
            rented=Count("id", filter=Q(status="rented")),
            maintenance=Count("id", filter=Q(status="maintenance")),
            reserved=Count("id", filter=Q(status="reserved")),
            avg_rating=Avg("average_rating"),
        )
        by_category = (
            self.get_queryset()
            .values("category__name", "category__type")
            .annotate(count=Count("id"), rented=Count("id", filter=Q(status="rented")))
            .order_by("category__name")
        )
        return Response({"summary": stats, "by_category": list(by_category)})


class VehicleCategoryViewSet(viewsets.ModelViewSet):
    queryset = VehicleCategory.objects.filter(is_active=True).order_by("sort_order")
    serializer_class = VehicleCategorySerializer
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [IsAuthenticated()]
        return [__import__("apps.authentication.permissions",fromlist=["IsSuperAdmin"]).IsSuperAdmin()]


class BranchViewSet(viewsets.ModelViewSet):
    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if getattr(user, 'role', '') in ['admin', 'staff', 'super_admin']:
            return qs if getattr(user, 'role', '')=='super_admin' else qs.filter(pk=user.branch_id) if user.branch_id else qs.none()
        return qs if getattr(user, 'role', '') == 'customer' else qs.none()

    queryset = Branch.objects.filter(is_active=True).order_by("name")
    serializer_class = BranchSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["name", "city", "code"]
    filterset_fields = ["city", "state", "is_active"]

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [IsAuthenticated()]
        return [__import__("apps.authentication.permissions", fromlist=["IsSuperAdmin"]).IsSuperAdmin()]


class MaintenanceViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if getattr(user, 'role', '') in ['admin', 'staff', 'super_admin']:
            return scope(qs, user, 'vehicle__branch')
        return qs if getattr(user, 'role', '') == 'customer' else qs.none()

    """Maintenance schedule management."""

    queryset = MaintenanceSchedule.objects.select_related(
        "vehicle", "created_by"
    ).order_by("-scheduled_date")
    serializer_class = MaintenanceSerializer
    permission_classes = [IsAdminOrStaff]
    filterset_fields = ["vehicle", "status", "maintenance_type"]
    search_fields = ["vehicle__registration_number", "vehicle__make", "vehicle__model"]
    ordering_fields = ["scheduled_date", "estimated_cost", "actual_cost"]

    def perform_create(self, serializer):
        check_relations(self.request.user, serializer.validated_data)
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=["post"], url_path="complete")
    def complete(self, request, pk=None):
        schedule = self.get_object()
        if schedule.status == MaintenanceSchedule.Status.COMPLETED:
            return Response({"error": "Already completed."}, status=400)
        from django.utils import timezone
        schedule.status        = MaintenanceSchedule.Status.COMPLETED
        schedule.completed_date = timezone.now().date()
        schedule.actual_cost   = request.data.get("actual_cost", schedule.estimated_cost)
        schedule.save(update_fields=["status", "completed_date", "actual_cost", "updated_at"])

        # Re-mark vehicle as available if it was in maintenance
        if schedule.vehicle.status == Vehicle.Status.MAINTENANCE:
            schedule.vehicle.status = Vehicle.Status.AVAILABLE
            schedule.vehicle.save(update_fields=["status", "updated_at"])

        return Response({"message": "Maintenance completed.", "vehicle_now": "available"})


class InsuranceViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if getattr(user, 'role', '') in ['admin', 'staff', 'super_admin']:
            return scope(qs, user, 'vehicle__branch')
        return qs if getattr(user, 'role', '') == 'customer' else qs.none()

    """Vehicle insurance policy management."""

    queryset = VehicleInsurance.objects.select_related("vehicle").order_by("end_date")
    serializer_class = InsuranceSerializer
    permission_classes = [IsAdminOrStaff]
    filterset_fields = ["vehicle", "insurance_type", "is_active"]
    search_fields = ["policy_number", "insurance_company", "vehicle__registration_number"]

    @action(detail=False, methods=["get"], url_path="expiring-soon")
    def expiring_soon(self, request):
        """Return policies expiring within 30 days."""
        from django.utils import timezone
        from datetime import timedelta
        threshold = timezone.now().date() + timedelta(days=30)
        expiring = self.get_queryset().filter(
            is_active=True,
            end_date__lte=threshold,
        ).select_related("vehicle__branch")
        return Response(InsuranceSerializer(expiring, many=True).data)

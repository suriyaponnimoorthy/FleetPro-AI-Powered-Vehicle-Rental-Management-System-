# apps/vehicles/filters.py
import django_filters
from django.db.models import Q
from apps.vehicles.models import Vehicle


class VehicleFilter(django_filters.FilterSet):
    status        = django_filters.MultipleChoiceFilter(choices=Vehicle.Status.choices)
    fuel_type     = django_filters.MultipleChoiceFilter(choices=Vehicle.FuelType.choices)
    transmission  = django_filters.MultipleChoiceFilter(choices=Vehicle.TransmissionType.choices)
    category_type = django_filters.CharFilter(field_name="category__type", lookup_expr="iexact")
    category      = django_filters.UUIDFilter(field_name="category__id")
    branch        = django_filters.UUIDFilter(field_name="branch__id")
    city          = django_filters.CharFilter(field_name="branch__city", lookup_expr="iexact")
    price_min     = django_filters.NumberFilter(method="filter_price_min")
    price_max     = django_filters.NumberFilter(method="filter_price_max")
    seats_min     = django_filters.NumberFilter(field_name="seating_capacity", lookup_expr="gte")
    year_from     = django_filters.NumberFilter(field_name="year", lookup_expr="gte")
    year_to       = django_filters.NumberFilter(field_name="year", lookup_expr="lte")
    rating_min    = django_filters.NumberFilter(field_name="average_rating", lookup_expr="gte")

    class Meta:
        model  = Vehicle
        fields = ["status", "fuel_type", "transmission", "category", "category_type", "branch", "city"]

    def filter_price_min(self, queryset, name, value):
        return queryset.filter(
            Q(price_per_day__gte=value) |
            Q(price_per_day__isnull=True, category__base_price_per_day__gte=value)
        )

    def filter_price_max(self, queryset, name, value):
        return queryset.filter(
            Q(price_per_day__lte=value) |
            Q(price_per_day__isnull=True, category__base_price_per_day__lte=value)
        )

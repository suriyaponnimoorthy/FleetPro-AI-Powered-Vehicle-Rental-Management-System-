# apps/vehicles/admin.py
from django.contrib import admin
from apps.vehicles.models import (
    Branch, VehicleCategory, Vehicle,
    VehicleImage, VehicleInsurance, MaintenanceSchedule,
)


@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display  = ("name", "code", "city", "state", "phone", "is_active")
    list_filter   = ("is_active", "state")
    search_fields = ("name", "code", "city")
    ordering      = ("name",)


@admin.register(VehicleCategory)
class VehicleCategoryAdmin(admin.ModelAdmin):
    list_display  = ("name", "type", "base_price_per_day", "security_deposit", "is_active", "sort_order")
    list_filter   = ("type", "is_active")
    ordering      = ("sort_order",)


class VehicleImageInline(admin.TabularInline):
    model  = VehicleImage
    extra  = 1
    fields = ("image", "caption", "is_primary", "sort_order")


class VehicleInsuranceInline(admin.TabularInline):
    model  = VehicleInsurance
    extra  = 0
    fields = ("policy_number", "insurance_company", "insurance_type", "end_date", "is_active")


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display  = ("registration_number", "make", "model", "year",
                     "category", "branch", "status", "fuel_type", "average_rating", "total_trips")
    list_filter   = ("status", "fuel_type", "category", "branch", "year")
    search_fields = ("registration_number", "make", "model", "variant")
    readonly_fields = ("total_trips", "average_rating", "created_at", "updated_at")
    inlines       = [VehicleImageInline, VehicleInsuranceInline]
    ordering      = ("make", "model")


@admin.register(VehicleInsurance)
class InsuranceAdmin(admin.ModelAdmin):
    list_display  = ("policy_number", "vehicle", "insurance_company",
                     "insurance_type", "end_date", "is_active")
    list_filter   = ("insurance_type", "is_active")
    search_fields = ("policy_number", "vehicle__registration_number", "insurance_company")


@admin.register(MaintenanceSchedule)
class MaintenanceAdmin(admin.ModelAdmin):
    list_display  = ("vehicle", "maintenance_type", "status", "scheduled_date",
                     "estimated_cost", "actual_cost")
    list_filter   = ("status", "maintenance_type")
    search_fields = ("vehicle__registration_number", "service_center")
    date_hierarchy = "scheduled_date"

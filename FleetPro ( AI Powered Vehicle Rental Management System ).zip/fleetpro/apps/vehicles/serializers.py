"""
apps/vehicles/serializers.py
Serializers for Vehicle, Category, Branch, Insurance, Maintenance.
"""

from rest_framework import serializers
from django.utils import timezone

from .models import (
    Vehicle, VehicleCategory, Branch, VehicleImage,
    VehicleInsurance, MaintenanceSchedule,
)


class VehicleCategorySerializer(serializers.ModelSerializer):
    vehicle_count = serializers.SerializerMethodField()

    class Meta:
        model = VehicleCategory
        fields = [
            "id", "name", "type", "description", "icon",
            "base_price_per_day", "base_price_per_hour",
            "security_deposit", "is_active", "sort_order", "vehicle_count",
        ]

    def get_vehicle_count(self, obj) -> int:
        return obj.vehicles.filter(is_active=True).count()


class BranchSerializer(serializers.ModelSerializer):
    vehicle_count = serializers.SerializerMethodField()

    class Meta:
        model = Branch
        fields = [
            "id", "name", "code", "address", "city", "state",
            "pincode", "phone", "email", "latitude", "longitude",
            "is_active", "opening_time", "closing_time", "vehicle_count",
        ]

    def get_vehicle_count(self, obj) -> int:
        return obj.vehicles.filter(is_active=True).count()


class VehicleImageSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = VehicleImage
        fields = ["id", "image", "image_url", "caption", "is_primary", "sort_order", "uploaded_at"]
        read_only_fields = ["uploaded_at"]

    def get_image_url(self, obj) -> str | None:
        if obj.image:
            request = self.context.get("request")
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        return None


class InsuranceSerializer(serializers.ModelSerializer):
    vehicle_name = serializers.CharField(source="vehicle.display_name", read_only=True)
    vehicle_reg  = serializers.CharField(source="vehicle.registration_number", read_only=True)
    is_expired   = serializers.BooleanField(read_only=True)
    days_to_expiry = serializers.IntegerField(read_only=True)

    class Meta:
        model = VehicleInsurance
        fields = [
            "id", "vehicle", "vehicle_name", "vehicle_reg",
            "policy_number", "insurance_company", "insurance_type",
            "start_date", "end_date", "premium_amount", "insured_value",
            "agent_name", "agent_phone", "document",
            "is_active", "is_expired", "days_to_expiry", "created_at",
        ]
        read_only_fields = ["created_at"]

    def validate(self, attrs):
        if attrs.get("end_date") and attrs.get("start_date"):
            if attrs["end_date"] <= attrs["start_date"]:
                raise serializers.ValidationError(
                    {"end_date": "End date must be after start date."}
                )
        return attrs


class MaintenanceSerializer(serializers.ModelSerializer):
    vehicle_name = serializers.CharField(source="vehicle.display_name", read_only=True)
    vehicle_reg  = serializers.CharField(source="vehicle.registration_number", read_only=True)
    created_by_name = serializers.SerializerMethodField()
    is_overdue   = serializers.SerializerMethodField()

    class Meta:
        model = MaintenanceSchedule
        fields = [
            "id", "vehicle", "vehicle_name", "vehicle_reg",
            "maintenance_type", "status",
            "scheduled_date", "completed_date",
            "odometer_at_service", "next_service_km", "next_service_date",
            "service_center", "technician_name",
            "estimated_cost", "actual_cost",
            "description", "parts_replaced",
            "created_by", "created_by_name",
            "is_overdue", "created_at", "updated_at",
        ]
        read_only_fields = ["created_by", "created_at", "updated_at"]

    def get_created_by_name(self, obj) -> str | None:
        if obj.created_by:
            return obj.created_by.get_full_name()
        return None

    def get_is_overdue(self, obj) -> bool:
        if obj.status == MaintenanceSchedule.Status.SCHEDULED:
            return obj.scheduled_date < timezone.now().date()
        return False


class VehicleListSerializer(serializers.ModelSerializer):
    """Compact serializer for list views and availability search results."""
    category_name  = serializers.CharField(source="category.name", read_only=True)
    category_type  = serializers.CharField(source="category.type", read_only=True)
    branch_name    = serializers.CharField(source="branch.name", read_only=True)
    branch_city    = serializers.CharField(source="branch.city", read_only=True)
    daily_rate     = serializers.SerializerMethodField()
    security_deposit_amount = serializers.SerializerMethodField()
    primary_image  = serializers.SerializerMethodField()

    class Meta:
        model = Vehicle
        fields = [
            "id", "registration_number", "make", "model", "variant",
            "year", "color", "status", "fuel_type", "transmission",
            "seating_capacity", "mileage_kmpl",
            "category_name", "category_type",
            "branch_name", "branch_city",
            "daily_rate", "security_deposit_amount",
            "average_rating", "total_trips",
            "primary_image", "features",
        ]

    def get_daily_rate(self, obj) -> str | None:
        return str(obj.get_daily_rate())

    def get_security_deposit_amount(self, obj) -> str | None:
        return str(obj.get_security_deposit())

    def get_primary_image(self, obj) -> str | None:
        img = next((i for i in obj.images.all() if i.is_primary), None)
        if img is None:
            img = next(iter(obj.images.all()), None)
        if img and img.image:
            request = self.context.get("request")
            return request.build_absolute_uri(img.image.url) if request else img.image.url
        return None


class VehicleDetailSerializer(serializers.ModelSerializer):
    """Full detail with nested relations."""
    category    = VehicleCategorySerializer(read_only=True)
    branch      = BranchSerializer(read_only=True)
    images      = VehicleImageSerializer(many=True, read_only=True)
    daily_rate  = serializers.SerializerMethodField()
    security_deposit_amount = serializers.SerializerMethodField()
    insurance_status = serializers.SerializerMethodField()
    upcoming_maintenance = serializers.SerializerMethodField()
    active_booking = serializers.SerializerMethodField()

    class Meta:
        model = Vehicle
        fields = [
            "id", "registration_number", "make", "model", "variant",
            "year", "color", "category", "branch",
            "status", "is_active", "fuel_type", "transmission",
            "seating_capacity", "engine_cc", "mileage_kmpl",
            "odometer_reading", "daily_rate", "security_deposit_amount",
            "rc_number", "rc_expiry_date", "fitness_expiry_date",
            "permit_expiry_date", "pollution_expiry_date",
            "gps_device_id", "last_known_lat", "last_known_lng",
            "features", "description", "notes",
            "total_trips", "average_rating",
            "images", "insurance_status", "upcoming_maintenance",
            "active_booking", "created_at", "updated_at",
        ]

    def get_daily_rate(self, obj) -> str | None:
        return str(obj.get_daily_rate())

    def get_security_deposit_amount(self, obj) -> str | None:
        return str(obj.get_security_deposit())

    def get_insurance_status(self, obj) -> dict | None:
        policy = obj.insurance_policies.filter(is_active=True).order_by("-end_date").first()
        if not policy:
            return {"status": "no_policy", "message": "No active insurance policy found."}
        return {
            "status": "expired" if policy.is_expired else "active",
            "days_to_expiry": policy.days_to_expiry,
            "policy_number": policy.policy_number,
            "insurance_type": policy.insurance_type,
            "insurance_company": policy.insurance_company,
            "end_date": policy.end_date,
        }

    def get_upcoming_maintenance(self, obj) -> dict | None:
        sched = obj.maintenance_schedules.filter(
            status=MaintenanceSchedule.Status.SCHEDULED,
        ).order_by("scheduled_date").first()
        if not sched:
            return None
        return {
            "id": str(sched.id),
            "type": sched.maintenance_type,
            "scheduled_date": sched.scheduled_date,
            "estimated_cost": str(sched.estimated_cost),
            "service_center": sched.service_center,
        }

    def get_active_booking(self, obj) -> dict | None:
        from apps.bookings.models import Booking
        booking = obj.bookings.filter(
            status=Booking.Status.ACTIVE
        ).select_related("customer__user").first()
        if not booking:
            return None
        return {
            "booking_number": booking.booking_number,
            "customer_name": booking.customer.user.get_full_name(),
            "return_datetime": booking.return_datetime,
        }


class VehicleCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vehicle
        exclude = ["total_trips", "average_rating", "created_at", "updated_at",
                   "last_location_update"]

    def validate_registration_number(self, value):
        return value.upper().strip().replace(" ", "-")

    def validate_year(self, value):
        import datetime
        current_year = datetime.date.today().year
        if value < 2000 or value > current_year + 1:
            raise serializers.ValidationError(
                f"Year must be between 2000 and {current_year + 1}."
            )
        return value

    def validate(self, attrs):
        price = attrs.get("price_per_day")
        if price is not None and price <= 0:
            raise serializers.ValidationError({"price_per_day": "Price must be a positive value."})
        return attrs

from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
import uuid
from django.conf import settings
from django.shortcuts import get_object_or_404
from rest_framework import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.exceptions import ValidationError
from rest_framework.throttling import UserRateThrottle
from apps.core.access import scope
from .models import CheckoutOrder, RefundRequest
from .services import new_order, new_refund, verified_webhook, reconcile_order
from .gateway import GatewayUnavailable

class CheckoutThrottle(UserRateThrottle):scope='checkout'
def key(request):
    try:return uuid.UUID(request.headers.get('Idempotency-Key',''))
    except ValueError:raise ValidationError('Supply a UUID Idempotency-Key header.')

def visible_orders(user):
    qs=CheckoutOrder.objects.select_related('booking__vehicle','booking__customer')
    return qs.filter(booking__customer__user=user) if getattr(user, 'role', '')=='customer' else scope(qs,user,'booking__vehicle__branch')

def order_data(order):
    return {'id':str(order.pk),'booking':str(order.booking_id),'status':order.status,'amount_paise':order.amount_paise,
        'currency':order.currency,'provider_order_id':order.provider_order_id,'key_id':settings.RAZORPAY_KEY_ID,
        'mode':'live' if settings.RAZORPAY_KEY_ID.startswith('rzp_live_') else 'test',
        'refundable_paise':order.amount_paise-sum(r.amount_paise for r in order.refunds.all() if r.status!='failed'),
        'refunds':[{'id':str(r.pk),'amount_paise':r.amount_paise,'status':r.status} for r in order.refunds.all()]}

class OrderSerializer(serializers.Serializer):booking=serializers.UUIDField()
class RefundSerializer(serializers.Serializer):
    order=serializers.UUIDField()
    amount_paise=serializers.IntegerField(min_value=1)
    reason=serializers.CharField(max_length=500)

class OrderView(APIView):
    permission_classes=[IsAuthenticated];throttle_classes=[CheckoutThrottle]
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        qs=visible_orders(request.user).order_by('-created_at')
        if request.query_params.get('booking'):
            try:booking_id=uuid.UUID(request.query_params['booking'])
            except ValueError:raise ValidationError('Invalid booking identifier.')
            qs=qs.filter(booking_id=booking_id)
        return Response({'results':[order_data(x) for x in qs[:100]]})
    @extend_schema(request=OrderSerializer,responses=OpenApiTypes.OBJECT)
    def post(self,request):
        s=OrderSerializer(data=request.data);s.is_valid(raise_exception=True)
        from apps.bookings.models import Booking
        get_object_or_404(Booking,pk=s.validated_data['booking'])
        try:order=new_order(request.user,s.validated_data['booking'],key(request))
        except GatewayUnavailable:return Response({'error':'Gateway not configured or unavailable. No success has been recorded. Check reconciliation before retrying.'},status=503)
        return Response(order_data(order),status=200)

class RefundView(APIView):
    permission_classes=[IsAuthenticated];throttle_classes=[CheckoutThrottle]
    @extend_schema(request=RefundSerializer,responses=OpenApiTypes.OBJECT)
    def post(self,request):
        s=RefundSerializer(data=request.data);s.is_valid(raise_exception=True);data=s.validated_data
        get_object_or_404(visible_orders(request.user),pk=data['order'])
        try:r=new_refund(request.user,data['order'],data['amount_paise'],key(request),data['reason'])
        except GatewayUnavailable:return Response({'error':'Refund not confirmed. Reconcile its status before another request.'},status=503)
        return Response({'id':str(r.pk),'status':r.status,'amount_paise':r.amount_paise},status=202)

class ReconcileView(APIView):
    permission_classes=[IsAuthenticated];throttle_classes=[CheckoutThrottle]
    @extend_schema(request=None,responses=OpenApiTypes.OBJECT)
    def post(self,request,pk):
        order=get_object_or_404(visible_orders(request.user),pk=pk)
        try:reconcile_order(order)
        except GatewayUnavailable:return Response({'error':'Provider verification unavailable. Status unchanged.'},status=503)
        order.refresh_from_db();return Response(order_data(order))

class WebhookView(APIView):
    permission_classes=[AllowAny];authentication_classes=[];throttle_classes=[]
    @extend_schema(request=OpenApiTypes.OBJECT,responses=OpenApiTypes.OBJECT)
    def post(self,request):
        raw=request.body
        if len(request.headers.get('X-Razorpay-Event-Id',''))>128:raise ValidationError('Invalid event identifier.')
        if len(raw)>262144:return Response({'error':'Payload too large'},status=413)
        try:state=verified_webhook(raw,request.headers.get('X-Razorpay-Signature',''),request.headers.get('X-Razorpay-Event-Id',''))
        except GatewayUnavailable:return Response({'error':'Webhook not configured'},status=503)
        # Unmatched events must be redelivered, not acknowledged as completed.
        return Response({'status':state},status=503 if state=='unmatched' else 200)

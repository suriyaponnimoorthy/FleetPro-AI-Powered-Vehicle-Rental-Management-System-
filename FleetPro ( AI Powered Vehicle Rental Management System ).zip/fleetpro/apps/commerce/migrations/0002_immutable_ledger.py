from django.db import migrations

def install(apps,schema_editor):
    if schema_editor.connection.vendor!='postgresql':return
    schema_editor.execute('''CREATE FUNCTION fleetpro_ledger_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Ledger entries are append-only'; END $$''')
    schema_editor.execute('''CREATE TRIGGER ledger_immutable BEFORE UPDATE OR DELETE ON commerce_ledgerentry FOR EACH ROW EXECUTE FUNCTION fleetpro_ledger_immutable()''')

def uninstall(apps,schema_editor):
    if schema_editor.connection.vendor!='postgresql':return
    schema_editor.execute('DROP TRIGGER IF EXISTS ledger_immutable ON commerce_ledgerentry')
    schema_editor.execute('DROP FUNCTION IF EXISTS fleetpro_ledger_immutable()')

class Migration(migrations.Migration):
    dependencies=[('commerce','0001_initial')]
    operations=[migrations.RunPython(install,uninstall)]

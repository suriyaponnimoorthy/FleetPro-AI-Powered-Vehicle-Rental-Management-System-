from django.urls import path
from .views import OrderView, RefundView, ReconcileView, WebhookView
urlpatterns=[path('orders/',OrderView.as_view()),path('refunds/',RefundView.as_view()),path('orders/<uuid:pk>/reconcile/',ReconcileView.as_view()),path('webhook/',WebhookView.as_view())]

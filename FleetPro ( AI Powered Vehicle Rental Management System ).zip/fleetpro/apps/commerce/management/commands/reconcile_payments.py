from django.core.management.base import BaseCommand, CommandError
from apps.commerce.models import CheckoutOrder
from apps.commerce.services import reconcile_order
class Command(BaseCommand):
    help='Verify known gateway captures/refunds and append missing ledger records.'
    def add_arguments(self,parser):parser.add_argument('--order',required=True)
    def handle(self,*args,**options):
        try:
            order=CheckoutOrder.objects.get(pk=options['order']);reconcile_order(order)
        except Exception as exc:raise CommandError('Reconciliation failed; inspect provider status. No credentials or raw payloads logged.') from exc
        self.stdout.write(self.style.SUCCESS('Reconciled against authenticated gateway data.'))

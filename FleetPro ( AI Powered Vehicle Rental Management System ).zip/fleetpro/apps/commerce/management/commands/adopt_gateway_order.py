from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from apps.commerce.models import CheckoutOrder
from apps.commerce.gateway import call
class Command(BaseCommand):
    help='Attach a verified gateway order after ambiguous creation, using its local receipt.'
    def add_arguments(self,p):p.add_argument('local_order');p.add_argument('provider_order')
    @transaction.atomic
    def handle(self,*a,**o):
        local=CheckoutOrder.objects.select_for_update().get(pk=o['local_order'])
        remote=call('GET','orders/'+o['provider_order'])
        if remote.get('receipt')!=local.id.hex or remote.get('amount')!=local.amount_paise or remote.get('currency')!=local.currency:
            raise CommandError('Receipt, amount or currency mismatch.')
        if local.provider_order_id and local.provider_order_id!=remote['id']:raise CommandError('Order already attached.')
        local.provider_order_id=remote['id'];local.status='created';local.save()
        self.stdout.write('Verified and attached. Now run reconcile_payments.')

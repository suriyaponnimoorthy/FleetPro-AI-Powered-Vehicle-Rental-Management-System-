import hashlib
import hmac
import json
from decimal import Decimal
from uuid import uuid5
from django.conf import settings
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from rest_framework.exceptions import ValidationError, PermissionDenied
from apps.bookings.models import Booking, BookingCancellation
from apps.payments.models import Payment
from apps.core.access import require_branch
from .models import CheckoutOrder, RefundRequest, GatewayEvent, LedgerEntry
from . import gateway


def paise(amount):
    value=Decimal(amount)*100
    if not value.is_finite() or value!=value.to_integral_value():raise ValidationError('Invalid monetary precision.')
    return int(value)

def access_booking(user,booking,employee_only=False):
    if user.role=='customer' and not employee_only:
        if booking.customer.user_id!=user.pk:raise PermissionDenied('Not your booking.')
    else:require_branch(user,booking.vehicle.branch_id)

def new_order(user,booking_id,key):
    if not gateway.configured():raise gateway.GatewayUnavailable(False)
    with transaction.atomic():
        booking=Booking.objects.select_for_update(of=('self',)).select_related('vehicle','customer').get(pk=booking_id)
        access_booking(user,booking)
        if booking.status not in ['pending','confirmed']:
            raise ValidationError('This booking is not payable.')
        existing=CheckoutOrder.objects.filter(idempotency_key=key).first()
        if existing:
            if existing.booking_id!=booking.pk or existing.requested_by_id!=user.pk:raise ValidationError('Idempotency key already used.')
            return existing
        if booking.amount_paid or CheckoutOrder.objects.filter(booking=booking,status='captured').exists():
            raise ValidationError('This booking already has a payment; reconcile it before another charge.')
        if CheckoutOrder.objects.filter(booking=booking,status__in=['initiating','created','unknown']).exists():raise ValidationError('A checkout already exists. Resume or reconcile it instead of creating another charge.')
        amount=paise(booking.total_amount)
        if amount<=0:raise ValidationError('Booking total must be positive.')
        deposit=paise(booking.security_deposit)
        order=CheckoutOrder.objects.create(booking=booking,requested_by=user,idempotency_key=key,amount_paise=amount,
            deposit_paise=deposit,rental_paise=amount-deposit)
    try:
        data=gateway.call('POST','orders',{'amount':amount,'currency':'INR','receipt':order.id.hex,'notes':{'fleetpro_order':str(order.id)}})
        if data.get('amount')!=amount or data.get('currency')!='INR' or not str(data.get('id','')).startswith('order_'):raise gateway.GatewayUnavailable()
    except gateway.GatewayUnavailable as exc:
        CheckoutOrder.objects.filter(pk=order.pk,status='initiating').update(status='unknown' if exc.ambiguous else 'failed')
        raise
    CheckoutOrder.objects.filter(pk=order.pk,status='initiating').update(provider_order_id=data['id'],status='created')
    order.refresh_from_db();return order

def new_refund(user,order_id,amount,key,reason):
    if not gateway.configured():raise gateway.GatewayUnavailable(False)
    with transaction.atomic():
        # Same lock order for captures, refunds and reconciliation: booking -> order.
        snapshot=CheckoutOrder.objects.get(pk=order_id)
        booking=Booking.objects.select_for_update(of=('self',)).select_related('vehicle').get(pk=snapshot.booking_id)
        access_booking(user,booking,True)
        order=CheckoutOrder.objects.select_for_update().get(pk=order_id)
        existing=RefundRequest.objects.filter(idempotency_key=key).first()
        if existing:
            if existing.order_id!=order.pk or existing.amount_paise!=amount:raise ValidationError('Idempotency key payload differs.')
            return existing
        if order.status!='captured':raise ValidationError('Only verified captures can be refunded.')
        reserved=order.refunds.exclude(status='failed').aggregate(total=Sum('amount_paise'))['total'] or 0
        if amount<=0 or amount+reserved>order.amount_paise:raise ValidationError('Refund exceeds the unrefunded captured amount.')
        refund=RefundRequest.objects.create(order=order,requested_by=user,idempotency_key=key,amount_paise=amount,reason=reason)
    return submit_refund(refund, order)


def submit_refund(refund, order):
    amount = refund.amount_paise
    try:
        data=gateway.call('POST',f'payments/{order.provider_payment_id}/refund',
            {'amount':amount,'speed':'normal','receipt':refund.id.hex,'notes':{'fleetpro_refund':str(refund.id)}},refund.idempotency_key)
        if data.get('amount')!=amount or data.get('payment_id')!=order.provider_payment_id or not str(data.get('id','')).startswith('rfnd_'):raise gateway.GatewayUnavailable()
    except gateway.GatewayUnavailable as exc:
        RefundRequest.objects.filter(pk=refund.pk,status='initiating').update(status='unknown' if exc.ambiguous else 'failed')
        raise
    # API acceptance is not settlement. Only webhook or authenticated fetch settles.
    RefundRequest.objects.filter(pk=refund.pk,status='initiating').update(provider_refund_id=data['id'],status='pending')
    refund.refresh_from_db();return refund

def queue_cancellation_refund(booking):
    """Called under the booking lock by both cancellation and capture settlement."""
    cancellation = BookingCancellation.objects.filter(booking=booking).first()
    if cancellation is None:
        return
    orders = list(booking.checkout_orders.filter(status="captured").order_by("created_at"))
    if not orders:
        return
    captured = sum(order.amount_paise for order in orders)
    fee = paise(cancellation.cancellation_fee)
    target = max(0, captured - fee)
    already_reserved = sum(
        order.refunds.exclude(status="failed").aggregate(total=Sum("amount_paise"))["total"] or 0
        for order in orders
    )
    remaining = max(0, target - already_reserved)
    for order in orders:
        key = uuid5(cancellation.pk, str(order.pk))
        reserved = order.refunds.exclude(status="failed").aggregate(total=Sum("amount_paise"))["total"] or 0
        amount = min(remaining, order.amount_paise - reserved)
        if amount > 0:
            _, created = RefundRequest.objects.get_or_create(
                idempotency_key=key, defaults={
                    "order": order, "requested_by": cancellation.cancelled_by_user or order.requested_by,
                    "amount_paise": amount, "reason": "Booking cancellation", "status": "queued",
                }
            )
            if created:
                remaining -= amount
    update_cancellation_refund(booking, cancellation, target)


def update_cancellation_refund(booking, cancellation=None, target=None):
    cancellation = cancellation or BookingCancellation.objects.filter(booking=booking).first()
    if cancellation is None:
        return
    if target is None:
        captured = booking.checkout_orders.filter(status="captured").aggregate(total=Sum("amount_paise"))["total"] or 0
        target = max(0, captured - paise(cancellation.cancellation_fee))
    refunds = RefundRequest.objects.filter(order__booking=booking)
    settled = refunds.filter(status="processed").aggregate(total=Sum("amount_paise"))["total"] or 0
    if not target:
        state = BookingCancellation.RefundStatus.NOT_APPLICABLE
    elif settled >= target:
        state = BookingCancellation.RefundStatus.PROCESSED
    elif refunds.filter(status__in=["queued", "initiating", "pending", "unknown"]).exists():
        state = BookingCancellation.RefundStatus.PENDING
    else:
        state = BookingCancellation.RefundStatus.FAILED
    cancellation.refund_amount = Decimal(target) / 100
    cancellation.refund_status = state
    cancellation.save(update_fields=["refund_amount", "refund_status"])


def _balance(booking):
    rows=LedgerEntry.objects.filter(order__booking=booking)
    credits=rows.filter(kind__startswith='capture_').aggregate(total=Sum('amount_paise'))['total'] or 0
    debits=rows.filter(kind__startswith='refund_').aggregate(total=Sum('amount_paise'))['total'] or 0
    booking.amount_paid=Decimal(credits-debits)/100
    booking.payment_status='refunded' if credits and credits==debits else 'paid' if booking.amount_paid>=booking.total_amount else 'partial' if booking.amount_paid>0 else 'pending'
    booking.save(update_fields=['amount_paid','payment_status','updated_at'])

def _entry(order,kind,amount,source,refund=None,method='card'):
    if amount<=0:return
    LedgerEntry.objects.create(order=order,kind=kind,amount_paise=amount,source_key=source,refund=refund)
    pay_type={'capture_rental':'booking_payment','capture_deposit':'security_deposit','refund_rental':'refund','refund_deposit':'deposit_refund'}[kind]
    Payment.objects.create(booking=order.booking,customer=order.booking.customer,payment_type=pay_type,
        method=method if method in ['upi','card','net_banking','wallet'] else 'card',status='success',amount=Decimal(amount)/100,
        gateway_transaction_id=source.split(':')[0],notes='Verified by gateway event/fetch',paid_at=timezone.now())

def settle_capture(entity):
    order=CheckoutOrder.objects.get(provider_order_id=entity['order_id'])
    booking=Booking.objects.select_for_update().get(pk=order.booking_id)
    order=CheckoutOrder.objects.select_for_update().get(pk=order.pk)
    if entity.get('status')!='captured' or entity.get('currency')!=order.currency or entity.get('amount')!=order.amount_paise:
        raise ValidationError('Captured amount, currency or status differs from order.')
    if order.status=='captured':
        if order.provider_payment_id!=entity['id']:raise ValidationError('Unexpected second capture; manual reconciliation required.')
        return
    if not str(entity.get('id','')).startswith('pay_'):raise ValidationError('Invalid payment reference.')
    order.provider_payment_id=entity['id'];order.status='captured';order.save(update_fields=['provider_payment_id','status','updated_at'])
    _entry(order,'capture_rental',order.rental_paise,entity['id']+':rental',method=entity.get('method','card'))
    _entry(order,'capture_deposit',order.deposit_paise,entity['id']+':deposit',method=entity.get('method','card'))
    _balance(booking)
    if booking.status == Booking.Status.CANCELLED:
        queue_cancellation_refund(booking)

def settle_refund(entity,event_type):
    refund=RefundRequest.objects.filter(provider_refund_id=entity['id']).first()
    if not refund:
        local=(entity.get('notes') or {}).get('fleetpro_refund')
        if not local:raise RefundRequest.DoesNotExist()
        refund=RefundRequest.objects.get(pk=local)
    snapshot=refund.order
    booking=Booking.objects.select_for_update().get(pk=snapshot.booking_id)
    order=CheckoutOrder.objects.select_for_update().get(pk=snapshot.pk)
    refund=RefundRequest.objects.select_for_update().get(pk=refund.pk)
    if entity.get('payment_id')!=order.provider_payment_id or entity.get('amount')!=refund.amount_paise or entity.get('currency')!='INR':raise ValidationError('Refund does not match its capture.')
    if refund.provider_refund_id and refund.provider_refund_id!=entity['id']:raise ValidationError('Refund identifier mismatch.')
    if refund.status=='processed':return
    refund.provider_refund_id=entity['id']
    if event_type=='refund.failed' and entity.get('status')=='failed':
        refund.status='failed';refund.save();update_cancellation_refund(booking);return
    if event_type!='refund.processed' or entity.get('status')!='processed':raise ValidationError('Refund is not processed.')
    refunded=order.ledger.filter(kind__startswith='refund_').aggregate(total=Sum('amount_paise'))['total'] or 0
    if refunded+refund.amount_paise>order.amount_paise:raise ValidationError('Cumulative refund exceeds capture.')
    prior_deposit=order.ledger.filter(kind='refund_deposit').aggregate(total=Sum('amount_paise'))['total'] or 0
    deposit=min(refund.amount_paise,max(0,order.deposit_paise-prior_deposit))
    _entry(order,'refund_deposit',deposit,entity['id']+':deposit',refund)
    _entry(order,'refund_rental',refund.amount_paise-deposit,entity['id']+':rental',refund)
    refund.status='processed';refund.save();_balance(booking);update_cancellation_refund(booking)

@transaction.atomic
def ingest(payload,event_id,raw_hash):
    event,created=GatewayEvent.objects.select_for_update().get_or_create(event_id=event_id,defaults={'payload_hash':raw_hash,'event_type':payload.get('event','')})
    if event.payload_hash!=raw_hash:raise ValidationError('Event identifier reused with different content.')
    if event.status=='processed':return 'duplicate'
    kind=payload.get('event','')
    # Savepoint allows unmatched deliveries to be retained and retried safely.
    try:
        with transaction.atomic():
            if kind=='payment.captured':settle_capture(payload['payload']['payment']['entity'])
            elif kind in ['refund.processed','refund.failed']:settle_refund(payload['payload']['refund']['entity'],kind)
            else:
                event.status='ignored';event.save();return 'ignored'
    except (CheckoutOrder.DoesNotExist,RefundRequest.DoesNotExist):
        event.status='unmatched';event.save();return 'unmatched'
    event.status='processed';event.save();return 'processed'

def verified_webhook(raw,signature,event_id):
    secret=settings.RAZORPAY_WEBHOOK_SECRET
    if not secret:raise gateway.GatewayUnavailable(False)
    expected=hmac.new(secret.encode(),raw,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature):raise PermissionDenied('Invalid webhook signature.')
    try:payload=json.loads(raw)
    except ValueError:raise ValidationError('Invalid webhook JSON.')
    if not isinstance(payload,dict):raise ValidationError('Invalid payload.')
    digest=hashlib.sha256(raw).hexdigest()
    try:return ingest(payload,event_id or digest,digest)
    except (KeyError,TypeError,AttributeError):raise ValidationError('Invalid webhook entity structure.')

@transaction.atomic
def reconcile_order(order):
    if not order.provider_order_id:raise ValidationError('Ambiguous order creation: locate its receipt in Razorpay and use adopt_gateway_order first.')
    items=gateway.collect(f'orders/{order.provider_order_id}/payments')
    for item in items:
        if item.get('status')=='captured':settle_capture(item)
    order.refresh_from_db()
    for refund in order.refunds.exclude(status__in=['processed','failed']).exclude(provider_refund_id=None):
        item=gateway.call('GET',f'refunds/{refund.provider_refund_id}')
        if item.get('status') in ['processed','failed']:settle_refund(item,'refund.'+item['status'])

    if order.provider_payment_id:
        by_receipt={r.id.hex:r for r in order.refunds.filter(status__in=['unknown','initiating'],provider_refund_id=None)}
        if by_receipt:
            for item in gateway.collect(f'payments/{order.provider_payment_id}/refunds'):
                local=by_receipt.get(item.get('receipt'))
                if local:
                    if item.get('amount')!=local.amount_paise:raise ValidationError('Recovered refund amount mismatch.')
                    local.provider_refund_id=item['id'];local.status='pending';local.save()
                    if item.get('status') in ['processed','failed']:settle_refund(item,'refund.'+item['status'])

"""Fixed-host Razorpay adapter. Provider secrets never leave the server."""
import re
import requests
from django.conf import settings

class GatewayUnavailable(Exception):
    def __init__(self, ambiguous=True): self.ambiguous=ambiguous

def configured():
    return bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET and settings.RAZORPAY_WEBHOOK_SECRET)

def call(method,path,body=None,idempotency_key=None,params=None):
    if not configured(): raise GatewayUnavailable(False)
    if not re.fullmatch(r'(orders(/[A-Za-z0-9_]+(/payments)?)?|payments/[A-Za-z0-9_]+/refunds?|refunds/[A-Za-z0-9_]+)',path):
        raise ValueError('Invalid gateway path')
    headers={'Content-Type':'application/json'}
    if idempotency_key:headers['X-Refund-Idempotency']=str(idempotency_key)
    try:
        response=requests.request(method,'https://api.razorpay.com/v1/'+path,json=body,
            auth=(settings.RAZORPAY_KEY_ID,settings.RAZORPAY_KEY_SECRET),headers=headers,params=params,timeout=(5,15))
    except requests.RequestException as exc:raise GatewayUnavailable() from exc
    if response.status_code>=400:raise GatewayUnavailable(response.status_code>=500 or response.status_code==429)
    try:return response.json()
    except ValueError as exc:raise GatewayUnavailable() from exc


def collect(path):
    for skip in range(0,5000,100):
        rows=call('GET',path,params={'count':100,'skip':skip}).get('items',[])
        yield from rows
        if len(rows)<100:return
    raise GatewayUnavailable()  # Refuse to report complete reconciliation if pagination was truncated.

from django.apps import AppConfig
class CommerceConfig(AppConfig):
    name='apps.commerce'
    default_auto_field='django.db.models.BigAutoField'

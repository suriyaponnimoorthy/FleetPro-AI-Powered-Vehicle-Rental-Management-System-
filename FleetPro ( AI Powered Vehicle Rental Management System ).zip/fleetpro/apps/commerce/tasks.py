"""Dispatch durable cancellation refunds without calling Razorpay inside a booking lock."""
import logging

from celery import shared_task
from django.db import transaction

from apps.bookings.models import Booking
from . import gateway
from .models import RefundRequest
from .services import submit_refund, update_cancellation_refund

logger = logging.getLogger(__name__)


@shared_task
def dispatch_cancellation_refunds():
    if not gateway.configured():
        return
    queued = RefundRequest.objects.filter(status="queued").order_by("created_at")
    for refund_id in list(queued.values_list("pk", flat=True)[:50]):
        with transaction.atomic():
            refund = RefundRequest.objects.select_related("order").get(pk=refund_id)
            booking = Booking.objects.select_for_update().get(pk=refund.order.booking_id)
            if not RefundRequest.objects.filter(pk=refund_id, status="queued").update(status="initiating"):
                continue
        try:
            submit_refund(refund, refund.order)
        except gateway.GatewayUnavailable as error:
            logger.warning("Cancellation refund %s requires reconciliation", refund_id)
            if not error.ambiguous:
                with transaction.atomic():
                    booking = Booking.objects.select_for_update().get(pk=booking.pk)
                    update_cancellation_refund(booking)

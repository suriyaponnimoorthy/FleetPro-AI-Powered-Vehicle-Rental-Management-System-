from django.contrib import admin
from .models import CheckoutOrder,RefundRequest,GatewayEvent,LedgerEntry
class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):return False
    def has_delete_permission(self,request,obj=None):return False
for model in [CheckoutOrder,RefundRequest,GatewayEvent,LedgerEntry]:admin.site.register(model,ReadOnlyAdmin)

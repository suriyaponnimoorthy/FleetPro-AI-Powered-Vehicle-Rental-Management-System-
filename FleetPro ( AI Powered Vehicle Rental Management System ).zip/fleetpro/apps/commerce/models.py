import uuid
from django.db import models
from django.db.models import Q

class CheckoutOrder(models.Model):
    id=models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    booking=models.ForeignKey('bookings.Booking',on_delete=models.PROTECT,related_name='checkout_orders')
    requested_by=models.ForeignKey('authentication.User',on_delete=models.PROTECT)
    idempotency_key=models.UUIDField(unique=True)
    amount_paise=models.PositiveBigIntegerField()
    rental_paise=models.PositiveBigIntegerField()
    deposit_paise=models.PositiveBigIntegerField()
    currency=models.CharField(max_length=3,default='INR')
    provider_order_id=models.CharField(max_length=100,unique=True,null=True,blank=True)
    provider_payment_id=models.CharField(max_length=100,unique=True,null=True,blank=True)
    status=models.CharField(max_length=20,default='initiating',choices=[(x,x) for x in ['initiating','created','unknown','captured','failed']])
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['booking'],condition=Q(status__in=['initiating','created','unknown']),name='one_open_checkout_per_booking'),models.CheckConstraint(condition=Q(amount_paise__gt=0),name='checkout_amount_positive')]

class RefundRequest(models.Model):
    id=models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    order=models.ForeignKey(CheckoutOrder,on_delete=models.PROTECT,related_name='refunds')
    requested_by=models.ForeignKey('authentication.User',on_delete=models.PROTECT)
    idempotency_key=models.UUIDField(unique=True)
    provider_refund_id=models.CharField(max_length=100,unique=True,null=True,blank=True)
    amount_paise=models.PositiveBigIntegerField()
    reason=models.CharField(max_length=500)
    status=models.CharField(max_length=20,default='initiating',choices=[(x,x) for x in ['queued','initiating','pending','unknown','processed','failed']])
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    class Meta:
        constraints=[models.CheckConstraint(condition=Q(amount_paise__gt=0),name='refund_amount_positive')]

class GatewayEvent(models.Model):
    event_id=models.CharField(max_length=128,primary_key=True)
    payload_hash=models.CharField(max_length=64)
    event_type=models.CharField(max_length=100)
    status=models.CharField(max_length=20,default='received')
    received_at=models.DateTimeField(auto_now_add=True)
    # Raw payment/customer payloads are deliberately not retained.

class ImmutableLedgerQuerySet(models.QuerySet):
    def update(self,**kwargs): raise ValueError('Ledger entries are append-only.')
    def delete(self): raise ValueError('Ledger entries are append-only.')

class LedgerEntry(models.Model):
    order=models.ForeignKey(CheckoutOrder,on_delete=models.PROTECT,related_name='ledger')
    refund=models.ForeignKey(RefundRequest,on_delete=models.PROTECT,null=True,blank=True)
    source_key=models.CharField(max_length=150,unique=True)
    kind=models.CharField(max_length=20,choices=[(x,x) for x in ['capture_rental','capture_deposit','refund_rental','refund_deposit']])
    amount_paise=models.PositiveBigIntegerField()
    created_at=models.DateTimeField(auto_now_add=True)
    objects=ImmutableLedgerQuerySet.as_manager()
    def save(self,*args,**kwargs):
        if self.pk: raise ValueError('Ledger entries are append-only.')
        super().save(*args,**kwargs)
    def delete(self,*args,**kwargs): raise ValueError('Ledger entries are append-only.')
    class Meta:
        constraints=[models.CheckConstraint(condition=Q(amount_paise__gt=0),name='ledger_amount_positive')]

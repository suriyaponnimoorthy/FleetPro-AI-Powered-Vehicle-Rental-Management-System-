import secrets
from django.urls import path
from django.http import JsonResponse
from django.db import connection
from django.core.cache import cache
from django.utils import timezone

def health_check(request):
    checks={}
    try:
        with connection.cursor() as cursor:cursor.execute('SELECT 1')
        checks['database']='ok'
    except Exception:checks['database']='unavailable'
    try:
        key='_health:'+secrets.token_hex(6);cache.set(key,'ok',5)
        checks['cache']='ok' if cache.get(key)=='ok' else 'unavailable';cache.delete(key)
    except Exception:checks['cache']='unavailable'
    healthy=all(v=='ok' for v in checks.values())
    response=JsonResponse({'status':'healthy' if healthy else 'degraded','services':checks,'timestamp':timezone.now().isoformat()},status=200 if healthy else 503)
    response['Cache-Control']='no-store';return response

def liveness(request):return JsonResponse({'status':'alive'})
urlpatterns=[path('',health_check),path('ready/',health_check),path('live/',liveness)]

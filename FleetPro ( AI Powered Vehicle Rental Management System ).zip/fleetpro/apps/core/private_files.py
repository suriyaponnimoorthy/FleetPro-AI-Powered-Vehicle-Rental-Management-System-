"""Private documents never use the public media storage or direct object URLs."""
import os
import socket
import struct
import uuid
from urllib.parse import urlencode
from pathlib import Path
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.exceptions import ValidationError
from django.utils.deconstruct import deconstructible

class PrivateURLMixin:
    def url(self,name):
        return '/api/v1/private-documents/content/?'+urlencode({'key':name})
    def get_available_name(self,name,max_length=None):
        # Do not retain identity-document filenames containing personal information.
        return super().get_available_name('documents/'+uuid.uuid4().hex+Path(name).suffix.lower(),max_length)

@deconstructible
class PrivateFileSystemStorage(PrivateURLMixin,FileSystemStorage):
    def __init__(self):super().__init__(location=settings.PRIVATE_MEDIA_ROOT,file_permissions_mode=0o600,directory_permissions_mode=0o700)

def private_storage():
    if settings.PRIVATE_S3_BUCKET:
        from storages.backends.s3 import S3Storage
        class PrivateS3Storage(PrivateURLMixin,S3Storage):pass
        return PrivateS3Storage(bucket_name=settings.PRIVATE_S3_BUCKET,default_acl=None,querystring_auth=True,
            file_overwrite=False,object_parameters={'ServerSideEncryption':'AES256'},
            region_name=settings.AWS_PRIVATE_REGION,endpoint_url=settings.PRIVATE_S3_ENDPOINT or None)
    return PrivateFileSystemStorage()

def scan_stream(file):
    if not settings.PRIVATE_UPLOAD_SCAN_REQUIRED:return
    try:
        with socket.create_connection((settings.CLAMAV_HOST,settings.CLAMAV_PORT),timeout=15) as sock:
            sock.sendall(b'zINSTREAM\0')
            for chunk in file.chunks(65536):sock.sendall(struct.pack('!I',len(chunk))+chunk)
            sock.sendall(struct.pack('!I',0))
            result=b''
            while b'\0' not in result and len(result)<4096:
                chunk=sock.recv(4096)
                if not chunk:break
                result+=chunk
            if result.strip(b'\0\n')!=b'stream: OK':raise ValidationError('File failed malware scanning.')
    except (OSError,TimeoutError) as exc:raise ValidationError('Document scanner unavailable; upload blocked.') from exc
    finally:file.seek(0)

def validate_private_file(file):
    if file.size<=0 or file.size>settings.PRIVATE_UPLOAD_MAX_BYTES:raise ValidationError('Document must be between 1 byte and 10 MiB.')
    import magic
    head=file.read(8192);file.seek(0)
    mime=magic.from_buffer(head,mime=True)
    if mime not in {'application/pdf','image/jpeg','image/png'}:raise ValidationError('Only genuine PDF, JPEG and PNG files are accepted.')
    if mime=='application/pdf' and (not head.startswith(b'%PDF-') or Path(file.name).suffix.lower()!='.pdf'):raise ValidationError('PDF content/extension mismatch.')
    if mime.startswith('image/'):
        from PIL import Image
        try:
            image=Image.open(file)
            if image.width*image.height>25000000:raise ValueError('Oversized image')
            expected='JPEG' if mime=='image/jpeg' else 'PNG'
            if image.format!=expected:raise ValueError('Invalid image')
            image.verify()
        except Exception as exc:raise ValidationError('Invalid image document.') from exc
        finally:file.seek(0)
    scan_stream(file)
    return mime

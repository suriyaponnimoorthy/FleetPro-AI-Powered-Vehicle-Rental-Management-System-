from pathlib import Path
from django.conf import settings
from django.core.files import File
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.apps import apps
from apps.core.private_views import RESOURCES
from apps.core.private_files import private_storage, validate_private_file

class Command(BaseCommand):
    help='Move historical local document files from public media into private storage. Run under maintenance mode.'
    def add_arguments(self,p):p.add_argument('--remove-public',action='store_true')
    def handle(self,*args,**options):
        count=0;root=Path(settings.MEDIA_ROOT).resolve();storage=private_storage()
        for kind,(label,fields) in RESOURCES.items():
            model=apps.get_model(label)
            for obj in model.objects.iterator():
                for field in fields:
                    current=getattr(obj,field)
                    if not current.name or current.name.startswith('documents/'):continue
                    source=(root/current.name).resolve()
                    if root not in source.parents or not source.is_file():continue
                    with source.open('rb') as handle:
                        uploaded=File(handle,name=source.name);validate_private_file(uploaded)
                        name=storage.save(source.name,uploaded)
                    with transaction.atomic():
                        setattr(obj,field,name);obj.save(update_fields=[field])
                    if options['remove_public']:source.unlink()
                    count+=1
        self.stdout.write(f'{count} document(s) migrated. Public routes must remain restricted.')

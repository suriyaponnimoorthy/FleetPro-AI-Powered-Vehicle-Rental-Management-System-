"""Read-only provider checks; never creates a charge or sends a message."""
import json
import socket
from django.conf import settings
from django.core.management.base import BaseCommand,CommandError
from django.core.cache import cache
from django.db import connection

class Command(BaseCommand):
    help='Check configuration, or use --live for non-transactional credential/connectivity probes.'
    def add_arguments(self,p):p.add_argument('--live',action='store_true');p.add_argument('--report')
    def handle(self,*a,**o):
        results={}
        def probe(name,configured,fn):
            if not configured:results[name]={'status':'not_configured'};return
            if not o['live']:results[name]={'status':'configured_not_live_tested'};return
            try:detail=fn();results[name]={'status':'passed','detail':detail}
            except Exception:results[name]={'status':'failed','detail':'Probe failed; credentials and response details are not logged.'}
        def db():
            with connection.cursor() as cursor:cursor.execute('SELECT version()');return connection.vendor
        probe('database',True,db)
        def redis():
            cache.set('_integration_probe','ready',10)
            if cache.get('_integration_probe')!='ready':raise ValueError()
            cache.delete('_integration_probe');return 'cache round-trip'
        probe('cache',True,redis)
        def ai():
            from apps.intelligence.services import language_response
            if not language_response('Give one brief tip for choosing a rental car.',[],[]):raise ValueError()
            return 'Response received; model '+settings.FLEETPRO_AI_MODEL
        probe('conversational_ai',bool(settings.FLEETPRO_AI_API_KEY),ai)
        def gateway():
            from apps.commerce.gateway import call
            call('GET','orders',params={'count':1});return 'Authenticated read; no payment created'
        probe('payment_credentials',bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET and settings.RAZORPAY_WEBHOOK_SECRET),gateway)
        def smtp():
            from django.core.mail import get_connection
            with get_connection() as backend:
                if backend.__class__.__module__!='django.core.mail.backends.smtp':raise ValueError()
            return 'SMTP connection/authentication only; no email sent'
        probe('email_smtp',bool(settings.EMAIL_HOST and settings.EMAIL_HOST_USER and settings.EMAIL_HOST_PASSWORD),smtp)
        def sms():
            from twilio.rest import Client
            Client(settings.TWILIO_ACCOUNT_SID,settings.TWILIO_AUTH_TOKEN).api.accounts(settings.TWILIO_ACCOUNT_SID).fetch()
            return 'Account read only; SMS delivery not tested'
        probe('sms_credentials',bool(settings.TWILIO_ACCOUNT_SID and settings.TWILIO_AUTH_TOKEN and settings.TWILIO_PHONE_NUMBER),sms)
        def storage():
            import boto3
            client=boto3.client('s3',region_name=settings.AWS_PRIVATE_REGION)
            response=client.get_public_access_block(Bucket=settings.PRIVATE_S3_BUCKET)
            if not all(response['PublicAccessBlockConfiguration'].values()):raise ValueError()
            return 'Private S3 public-access block verified; no document uploaded'
        if settings.PRIVATE_S3_BUCKET:probe('private_s3',True,storage)
        else:
            def local_storage():
                from apps.core.private_files import private_storage
                storage=private_storage()
                return 'Private local volume, not publicly served'
            probe('private_storage',True,local_storage)
        def scanner():
            with socket.create_connection((settings.CLAMAV_HOST,settings.CLAMAV_PORT),timeout=5) as sock:
                sock.sendall(b'zPING\0')
                if b'PONG' not in sock.recv(100):raise ValueError()
            return 'ClamAV reachable'
        probe('malware_scanner',settings.PRIVATE_UPLOAD_SCAN_REQUIRED,scanner)
        output=json.dumps({'live_probes':o['live'],'checks':results},indent=2)
        if o['report']:
            from pathlib import Path
            Path(o['report']).write_text(output)
        self.stdout.write(output)
        if o['live'] and any(r['status'] in ['not_configured','failed'] for r in results.values()):raise CommandError('Some integrations remain unverified; see statuses above.')

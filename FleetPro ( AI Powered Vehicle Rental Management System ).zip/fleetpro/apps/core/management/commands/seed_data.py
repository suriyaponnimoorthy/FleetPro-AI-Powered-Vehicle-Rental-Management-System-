"""
apps/core/management/commands/seed_data.py
Custom Django management command: python manage.py seed_data [--reset]
"""

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction


class Command(BaseCommand):
    help = "Seed FleetPro with realistic demo data"

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete all existing data before seeding (DANGEROUS in production)",
        )
        parser.add_argument(
            "--minimal",
            action="store_true",
            help="Seed minimal data (1 branch, 3 vehicles, 2 customers)",
        )

    @transaction.atomic
    def handle(self, *args, **options):
        if options["reset"]:
            if input("⚠️  This will DELETE all data. Type 'yes' to confirm: ") != "yes":
                raise CommandError("Aborted.")
            self._reset_data()

        self.stdout.write("🌱 Seeding FleetPro data...")

        self._seed_branches()
        self._seed_categories()
        self._seed_vehicles()
        self._seed_admin_users()
        self._seed_drivers()
        self._seed_customers()
        if not options.get("minimal"):
            self._assign_demo_branches()
        self._seed_bookings()

        self.stdout.write(self.style.SUCCESS("✅ Seed data complete!"))
        self.stdout.write("\n📋 Login Credentials:")
        self.stdout.write("  Super Admin : superadmin@fleetpro.in / FleetPro@2025!")
        self.stdout.write("  Admin       : admin@fleetpro.in       / Admin@123!")
        self.stdout.write("  Driver      : ramesh.kumar@fleetpro.in / Driver@123!")
        self.stdout.write("  Customer    : arjun.reddy@gmail.com    / Customer@123!")
        self.stdout.write("\n🌐 Swagger: http://localhost:8000/api/docs/")

    def _reset_data(self):
        from apps.payments.models import Payment, Invoice, DamageReport, Penalty
        from apps.bookings.models import Booking, BookingCancellation
        from apps.drivers.models import Driver
        from apps.customers.models import CustomerProfile
        from apps.vehicles.models import Vehicle, VehicleCategory, Branch
        from apps.authentication.models import User

        Payment.objects.all().delete()
        Penalty.objects.all().delete()
        DamageReport.objects.all().delete()
        Booking.objects.all().delete()
        Driver.objects.all().delete()
        CustomerProfile.objects.all().delete()
        Vehicle.objects.all().delete()
        VehicleCategory.objects.all().delete()
        Branch.objects.all().delete()
        User.objects.filter(is_superuser=False).delete()
        self.stdout.write(self.style.WARNING("  → All data deleted."))

    def _seed_branches(self):
        from apps.vehicles.models import Branch
        branches = [
            {"name": "Chennai Central",   "code": "CHN01", "city": "Chennai",   "state": "Tamil Nadu",  "address": "12 Anna Salai", "pincode": "600002", "phone": "04412345678"},
            {"name": "Mumbai Andheri",    "code": "MUM01", "city": "Mumbai",    "state": "Maharashtra", "address": "45 Link Road",  "pincode": "400053", "phone": "02298765432"},
            {"name": "Bengaluru MG Road", "code": "BLR01", "city": "Bengaluru", "state": "Karnataka",   "address": "78 MG Road",    "pincode": "560001", "phone": "08023456789"},
            {"name": "Delhi Connaught",   "code": "DEL01", "city": "Delhi",     "state": "Delhi",       "address": "22 CP",         "pincode": "110001", "phone": "01145678901"},
        ]
        for bd in branches:
            Branch.objects.get_or_create(code=bd["code"], defaults=bd)
        self.stdout.write(f"  ✓ {Branch.objects.count()} branches")

    def _seed_categories(self):
        from apps.vehicles.models import VehicleCategory
        cats = [
            {"name": "Hatchback",    "type": "car",      "base_price_per_day": 1100, "base_price_per_hour": 150, "security_deposit": 3000},
            {"name": "Sedan",        "type": "car",      "base_price_per_day": 1400, "base_price_per_hour": 180, "security_deposit": 4000},
            {"name": "SUV",          "type": "car",      "base_price_per_day": 2200, "base_price_per_hour": 280, "security_deposit": 6000},
            {"name": "Luxury Car",   "type": "luxury",   "base_price_per_day": 8000, "base_price_per_hour": 1000,"security_deposit": 20000},
            {"name": "Sports Bike",  "type": "bike",     "base_price_per_day": 1200, "base_price_per_hour": 160, "security_deposit": 3000},
            {"name": "Scooter",      "type": "bike",     "base_price_per_day": 600,  "base_price_per_hour": 80,  "security_deposit": 1500},
            {"name": "Electric SUV", "type": "electric", "base_price_per_day": 2500, "base_price_per_hour": 320, "security_deposit": 7000},
            {"name": "Electric Bike","type": "electric", "base_price_per_day": 800,  "base_price_per_hour": 110, "security_deposit": 2000},
        ]
        for c in cats:
            VehicleCategory.objects.get_or_create(name=c["name"], defaults=c)
        self.stdout.write(f"  ✓ {VehicleCategory.objects.count()} categories")

    def _seed_vehicles(self):
        from apps.vehicles.models import Vehicle, VehicleCategory, Branch, VehicleInsurance
        from datetime import date, timedelta
        from decimal import Decimal
        import random

        branch_map = {b.code: b for b in Branch.objects.all()}
        cat_map    = {c.name: c for c in VehicleCategory.objects.all()}

        vehicles_data = [
            {"reg": "KA-01-AB-1234", "make": "Toyota",      "model": "Innova Crysta",   "year": 2022, "color": "White",      "cat": "SUV",         "branch": "BLR01", "fuel": "diesel"},
            {"reg": "MH-12-CD-5678", "make": "Maruti",      "model": "Swift",            "year": 2023, "color": "Red",        "cat": "Hatchback",   "branch": "MUM01", "fuel": "petrol"},
            {"reg": "DL-01-EF-9012", "make": "BMW",         "model": "5 Series 530i",   "year": 2023, "color": "Black",      "cat": "Luxury Car",  "branch": "DEL01", "fuel": "petrol"},
            {"reg": "TN-09-GH-3456", "make": "Tata",        "model": "Nexon EV Max",    "year": 2023, "color": "Blue",       "cat": "Electric SUV","branch": "CHN01", "fuel": "electric"},
            {"reg": "KL-07-IJ-7890", "make": "Royal Enfield","model": "Classic 350",    "year": 2022, "color": "Green",      "cat": "Sports Bike", "branch": "CHN01", "fuel": "petrol"},
            {"reg": "GJ-06-KL-2345", "make": "Honda",       "model": "City ZX",         "year": 2022, "color": "Silver",     "cat": "Sedan",       "branch": "MUM01", "fuel": "petrol"},
            {"reg": "RJ-14-MN-6789", "make": "Hyundai",     "model": "Creta",           "year": 2023, "color": "Pearl White","cat": "SUV",         "branch": "DEL01", "fuel": "petrol"},
            {"reg": "AP-28-OP-1122", "make": "Honda",       "model": "Activa 6G",       "year": 2023, "color": "Blue",       "cat": "Scooter",     "branch": "BLR01", "fuel": "petrol"},
            {"reg": "MH-02-QR-3344", "make": "Mercedes",    "model": "E-Class 220d",    "year": 2022, "color": "Black",      "cat": "Luxury Car",  "branch": "MUM01", "fuel": "diesel"},
            {"reg": "TN-22-ST-5566", "make": "Ather",       "model": "450X Pro",        "year": 2023, "color": "Space Grey", "cat": "Electric Bike","branch": "CHN01","fuel": "electric"},
            {"reg": "KA-05-UV-7788", "make": "Maruti",      "model": "Brezza",          "year": 2023, "color": "Orange",     "cat": "SUV",         "branch": "BLR01", "fuel": "petrol"},
            {"reg": "DL-08-WX-9900", "make": "Kia",         "model": "Seltos HTX+",     "year": 2023, "color": "Red",        "cat": "SUV",         "branch": "DEL01", "fuel": "diesel"},
        ]

        created = 0
        for vd in vehicles_data:
            v, made = Vehicle.objects.get_or_create(
                registration_number=vd["reg"],
                defaults={
                    "make": vd["make"], "model": vd["model"], "year": vd["year"],
                    "color": vd["color"],
                    "category": cat_map[vd["cat"]],
                    "branch": branch_map[vd["branch"]],
                    "fuel_type": vd["fuel"],
                    "status": random.choice(["available", "available", "rented"]),
                    "seating_capacity": 2 if "Bike" in vd["cat"] or "Scooter" in vd["cat"] else 5,
                    "odometer_reading": random.randint(5000, 80000),
                },
            )
            if made:
                created += 1
                ins_companies = ["ICICI Lombard", "HDFC ERGO", "Bajaj Allianz", "New India"]
                VehicleInsurance.objects.create(
                    vehicle=v,
                    policy_number=f"POL-{vd['reg'].replace('-','')}",
                    insurance_company=random.choice(ins_companies),
                    insurance_type="comprehensive",
                    start_date=date.today() - timedelta(days=180),
                    end_date=date.today() + timedelta(days=185),
                    premium_amount=Decimal(str(random.randint(8000, 35000))),
                    insured_value=Decimal(str(random.randint(400000, 5000000))),
                )
        self.stdout.write(f"  ✓ {Vehicle.objects.count()} vehicles ({created} new)")

    def _seed_admin_users(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        sa, created = User.objects.get_or_create(
            email="superadmin@fleetpro.in",
            defaults={"first_name": "Super", "last_name": "Admin", "role": User.Role.SUPER_ADMIN,
                      "is_staff": True, "is_superuser": True, "is_email_verified": True, "is_kyc_verified": True},
        )
        if created:
            sa.set_password("FleetPro@2025!"); sa.save()

        ad, created = User.objects.get_or_create(
            email="admin@fleetpro.in",
            defaults={"first_name": "Amit", "last_name": "Sharma", "role": User.Role.ADMIN,
                      "is_staff": True, "is_email_verified": True},
        )
        if created:
            ad.set_password("Admin@123!"); ad.save()
        self.stdout.write("  ✓ Admin users")

    def _seed_drivers(self):
        from django.contrib.auth import get_user_model
        from apps.vehicles.models import Branch
        from apps.drivers.models import Driver
        from datetime import date, timedelta
        import random
        from decimal import Decimal

        User = get_user_model()
        branch_map = {b.code: b for b in Branch.objects.all()}
        drivers_data = [
            {"email": "ramesh.kumar@fleetpro.in",  "first": "Ramesh",  "last": "Kumar",  "branch": "CHN01", "emp": "DRV001", "dl": "TN0120180012345", "exp": 12, "salary": 22000},
            {"email": "vikram.sharma@fleetpro.in", "first": "Vikram",  "last": "Sharma", "branch": "MUM01", "emp": "DRV002", "dl": "MH0220190023456", "exp": 8,  "salary": 28000},
            {"email": "ravi.pillai@fleetpro.in",   "first": "Ravi",    "last": "Pillai", "branch": "BLR01", "emp": "DRV003", "dl": "KA0120200034567", "exp": 5,  "salary": 20000},
            {"email": "anil.tiwari@fleetpro.in",   "first": "Anil",    "last": "Tiwari", "branch": "DEL01", "emp": "DRV004", "dl": "DL0120170045678", "exp": 15, "salary": 25000},
            {"email": "sunil.nair@fleetpro.in",    "first": "Sunil",   "last": "Nair",   "branch": "CHN01", "emp": "DRV005", "dl": "KL0720000056789", "exp": 20, "salary": 32000},
        ]
        count = 0
        for dd in drivers_data:
            u, created = User.objects.get_or_create(
                email=dd["email"],
                defaults={"first_name": dd["first"], "last_name": dd["last"],
                          "role": User.Role.DRIVER, "is_email_verified": True},
            )
            if created:
                u.set_password("Driver@123!"); u.save()
            Driver.objects.get_or_create(
                user=u,
                defaults={
                    "branch": branch_map[dd["branch"]],
                    "employee_id": dd["emp"],
                    "dl_number": dd["dl"],
                    "dl_expiry_date": date.today() + timedelta(days=random.randint(180, 1800)),
                    "experience_years": dd["exp"],
                    "monthly_salary": dd["salary"],
                    "daily_rate": 500,
                    "average_rating": Decimal(str(round(random.uniform(3.5, 5.0), 1))),
                    "total_trips": random.randint(50, 400),
                },
            )
            count += 1
        self.stdout.write(f"  ✓ {count} drivers")

    def _seed_customers(self):
        from django.contrib.auth import get_user_model
        from apps.customers.models import CustomerProfile
        from datetime import date, timedelta
        import random
        from decimal import Decimal

        User = get_user_model()
        customers_data = [
            {"email": "arjun.reddy@gmail.com",  "first": "Arjun",  "last": "Reddy",  "city": "Chennai",   "spend": 54200,  "bookings": 18},
            {"email": "priya.mehta@gmail.com",  "first": "Priya",  "last": "Mehta",  "city": "Mumbai",    "spend": 18400,  "bookings": 7},
            {"email": "neha.joshi@gmail.com",   "first": "Neha",   "last": "Joshi",  "city": "Delhi",     "spend": 214000, "bookings": 32},
            {"email": "suresh.kumar@gmail.com", "first": "Suresh", "last": "Kumar",  "city": "Bengaluru", "spend": 38600,  "bookings": 11},
            {"email": "karan.verma@gmail.com",  "first": "Karan",  "last": "Verma",  "city": "Jaipur",    "spend": 7200,   "bookings": 3},
            {"email": "meena.gupta@gmail.com",  "first": "Meena",  "last": "Gupta",  "city": "Bengaluru", "spend": 38600,  "bookings": 11},
        ]
        count = 0
        for cd in customers_data:
            u, created = User.objects.get_or_create(
                email=cd["email"],
                defaults={"first_name": cd["first"], "last_name": cd["last"],
                          "role": User.Role.CUSTOMER, "is_email_verified": True, "is_kyc_verified": True},
            )
            if created:
                u.set_password("Customer@123!"); u.save()
            CustomerProfile.objects.update_or_create(
                user=u,
                defaults={
                    "city": cd["city"],
                    "kyc_status": "verified" if cd["spend"] > 10000 else "pending",
                    "total_bookings": cd["bookings"],
                    "total_spend": Decimal(str(cd["spend"])),
                    "loyalty_points": cd["spend"] // 100,
                    "dl_number": f"DL-{cd['first'][:3].upper()}-{random.randint(10000,99999)}",
                    "dl_expiry_date": date.today() + timedelta(days=random.randint(365, 1825)),
                },
            )
            count += 1
        self.stdout.write(f"  ✓ {count} customers")

    def _seed_bookings(self):
        from apps.bookings.models import Booking
        from apps.payments.models import Payment
        from apps.vehicles.models import Vehicle
        from apps.customers.models import CustomerProfile
        from django.contrib.auth import get_user_model
        from django.utils import timezone
        from datetime import timedelta
        from decimal import Decimal
        import random

        User = get_user_model()
        vehicles  = list(Vehicle.objects.filter(is_active=True))
        customers = list(CustomerProfile.objects.filter(kyc_status="verified"))
        superadmin = User.objects.filter(role="super_admin").first()

        if not vehicles or not customers:
            self.stdout.write(self.style.WARNING("  ⚠ Skipping bookings — no vehicles/customers"))
            return

        status_scenarios = [
            ("active", 5, 3), ("confirmed", 1, 2), ("pending", 2, 4),
            ("completed", 15, 5), ("completed", 20, 3), ("completed", 30, 7),
            ("cancelled", 4, 2),
        ]

        counter = 2401
        created = 0
        for bk_status, days_ago, duration in status_scenarios:
            v = random.choice(vehicles)
            c = random.choice(customers)
            now = timezone.now()
            pickup = now - timedelta(days=days_ago)
            return_ = pickup + timedelta(days=duration)
            daily_rate = v.get_daily_rate()
            base       = daily_rate * duration
            gst        = base * Decimal("0.18")
            deposit    = v.get_security_deposit()
            total      = base + gst + deposit

            status_map = {
                "active": Booking.Status.ACTIVE,
                "confirmed": Booking.Status.CONFIRMED,
                "pending": Booking.Status.PENDING,
                "completed": Booking.Status.COMPLETED,
                "cancelled": Booking.Status.CANCELLED,
            }

            bk, made = Booking.objects.get_or_create(
                booking_number=f"BK-{counter}",
                defaults={
                    "customer": c, "vehicle": v,
                    "pickup_datetime": pickup, "return_datetime": return_,
                    "pickup_location": f"{v.branch.city} Branch",
                    "drop_location": f"{v.branch.city} Branch",
                    "pickup_branch": v.branch, "drop_branch": v.branch,
                    "status": status_map.get(bk_status, Booking.Status.PENDING),
                    "payment_status": "paid" if bk_status in ["active","completed","confirmed"] else "pending",
                    "base_amount": base, "gst_amount": gst,
                    "security_deposit": deposit, "total_amount": total,
                    "amount_paid": total if bk_status in ["active","completed","confirmed"] else Decimal("0"),
                    "created_by": superadmin,
                }
            )
            if made:
                created += 1
                if bk_status in ["active", "completed", "confirmed"]:
                    Payment.objects.create(
                        booking=bk, customer=c,
                        payment_type=Payment.PaymentType.BOOKING_PAYMENT,
                        method=random.choice(["upi", "card", "net_banking"]),
                        status=Payment.Status.SUCCESS,
                        amount=base + gst,
                        taxable_amount=base,
                        cgst=gst / 2, sgst=gst / 2,
                        paid_at=pickup,
                    )
            counter += 1

        # Keep demo fleet status consistent with the seeded active rentals.
        active_ids = Booking.objects.filter(status='active').values_list('vehicle_id', flat=True)
        Vehicle.objects.filter(is_active=True, status__in=['available', 'rented']).update(status='available')
        Vehicle.objects.filter(id__in=active_ids).update(status='rented')

        self.stdout.write(f"  ✓ {created} bookings created")

    def _assign_demo_branches(self):
        from apps.authentication.models import User
        from apps.vehicles.models import Branch
        from apps.customers.models import CustomerProfile
        branch=Branch.objects.filter(code='CHN01').first()
        User.objects.filter(email='admin@fleetpro.in',branch=None).update(branch=branch)
        for profile in CustomerProfile.objects.select_related('user').filter(user__branch=None):
            home=Branch.objects.filter(city__iexact=profile.city).first() or branch
            User.objects.filter(pk=profile.user_id).update(branch=home)

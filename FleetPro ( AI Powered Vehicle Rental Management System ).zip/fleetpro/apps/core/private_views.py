from rest_framework import serializers
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from django.apps import apps
from django.http import FileResponse
from django.db import transaction
from apps.bookings.models import Booking
from django.shortcuts import get_object_or_404
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework.exceptions import PermissionDenied, ValidationError, NotFound
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser
from rest_framework.views import APIView
from rest_framework.response import Response
from apps.core.access import require_branch
from apps.core.private_files import validate_private_file
from apps.authentication.models import ActivityLog

RESOURCES={
 'customer':('customers.CustomerProfile',['dl_document','aadhar_document','pan_document','selfie_with_id']),
 'driver':('drivers.Driver',['dl_document','aadhar_document','police_verification']),
 'inspection':('bookings.VehicleInspection',['customer_signature']),
 'insurance':('vehicles.VehicleInsurance',['document']),
}

def authorize(user,obj,kind):
    if kind in ['customer','driver']:owner=obj.user_id;branch=obj.user.branch_id if kind=='customer' else obj.branch_id
    elif kind=='inspection':owner=obj.booking.customer.user_id;branch=obj.booking.vehicle.branch_id
    else:owner=None;branch=obj.vehicle.branch_id
    if user.pk==owner and user.role in ['customer','driver']:return
    require_branch(user,branch)

def audit(user,obj,field,action):
    ActivityLog.objects.create(user=user,action=action,model_name='PrivateDocument',object_id=str(obj.pk),description=f'{obj._meta.label}.{field}')

class DocumentUploadSerializer(serializers.Serializer):
    file=serializers.FileField()

class DocumentUploadView(APIView):
    permission_classes=[IsAuthenticated];parser_classes=[MultiPartParser]
    @extend_schema(request=DocumentUploadSerializer,responses=OpenApiTypes.OBJECT)
    @transaction.atomic
    def post(self,request,kind,pk,field):
        if kind not in RESOURCES or field not in RESOURCES[kind][1]:raise NotFound()
        model = apps.get_model(RESOURCES[kind][0])
        obj = get_object_or_404(model, pk=pk)
        authorize(request.user, obj, kind)
        if kind == "inspection":
            booking = Booking.objects.select_for_update().get(pk=obj.booking_id)
            obj = get_object_or_404(model.objects.select_for_update(), pk=pk)
            if getattr(obj, field) or booking.status in {
                Booking.Status.COMPLETED, Booking.Status.CANCELLED, Booking.Status.NO_SHOW,
            }:
                raise ValidationError("A signed or closed inspection cannot be changed.")
        else:
            obj = get_object_or_404(model.objects.select_for_update(), pk=pk)
        authorize(request.user, obj, kind)
        upload=request.FILES.get('file')
        if not upload:raise ValidationError('Supply the file field.')
        if field in ['selfie_with_id','customer_signature'] and upload.content_type not in ['image/jpeg','image/png']:
            raise ValidationError('This field requires a JPEG or PNG image.')
        try:mime=validate_private_file(upload)
        except DjangoValidationError as exc:raise ValidationError(exc.messages)
        if field in ['selfie_with_id','customer_signature'] and not mime.startswith('image/'):
            raise ValidationError('This field requires a genuine raster image.')
        # Retention: replaced objects are retained until an explicit audited retention job.
        setattr(obj,field,upload)
        if kind=='customer':
            obj.kyc_status = 'submitted'
            obj.kyc_verified_at = None
            obj.kyc_verified_by = None
            obj.save(update_fields=[field, 'kyc_status', 'kyc_verified_at', 'kyc_verified_by'])
            obj.user.is_kyc_verified=False;obj.user.save(update_fields=['is_kyc_verified'])
        else:obj.save(update_fields=[field])
        audit(request.user,obj,field,'update')
        return Response({'url':getattr(obj,field).url,'message':'Stored privately.'},status=201)

class DocumentContentView(APIView):
    permission_classes=[IsAuthenticated]
    @extend_schema(responses=OpenApiTypes.BINARY)
    def get(self,request):
        name=request.query_params.get('key','')
        if not name or len(name)>300 or '..' in name or name.startswith('/'):raise NotFound()
        for kind,(label,fields) in RESOURCES.items():
            model=apps.get_model(label)
            for field in fields:
                obj=model.objects.filter(**{field:name}).first()
                if not obj:continue
                authorize(request.user,obj,kind)
                file=getattr(obj,field)
                try:handle=file.open('rb')
                except FileNotFoundError:raise NotFound()
                audit(request.user,obj,field,'view')
                response=FileResponse(handle,as_attachment=True,filename='document'+__import__('pathlib').Path(name).suffix)
                response['Cache-Control']='private, no-store, max-age=0'
                response['X-Content-Type-Options']='nosniff'
                return response
        raise NotFound()

class MyDocumentsView(APIView):
    permission_classes=[IsAuthenticated]
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        if request.user.role!='customer':raise PermissionDenied('Customer account required.')
        obj=get_object_or_404(apps.get_model('customers.CustomerProfile'),user=request.user)
        return Response({'profile_id':str(obj.pk),'kyc_status':obj.kyc_status,'documents':{field:getattr(obj,field).url if getattr(obj,field) else None for field in RESOURCES['customer'][1]}})

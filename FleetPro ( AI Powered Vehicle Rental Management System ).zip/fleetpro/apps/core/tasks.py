from celery import shared_task
from django.core.cache import cache
from django.utils import timezone
@shared_task
def worker_heartbeat():cache.set('fleetpro:worker-heartbeat',timezone.now(),180)

@shared_task
def nightly_backup():
    import subprocess,sys
    from django.conf import settings
    subprocess.run([sys.executable,str(settings.BASE_DIR/'scripts/backup.py')],check=True,timeout=3600)

import hmac
from django.conf import settings
from django.http import HttpResponse
from django.core.cache import cache
from django.utils import timezone
from apps.commerce.models import CheckoutOrder,RefundRequest,GatewayEvent
from apps.notifications.models import NotificationLog

def metrics(request):
    expected=getattr(settings,'METRICS_TOKEN','')
    if not expected or not hmac.compare_digest(request.headers.get('Authorization',''),'Bearer '+expected):return HttpResponse(status=404)
    heartbeat=cache.get('fleetpro:worker-heartbeat')
    age=(timezone.now()-heartbeat).total_seconds() if heartbeat else -1
    values={
        'fleetpro_gateway_orders_uncertain':CheckoutOrder.objects.filter(status__in=['unknown','initiating']).count(),
        'fleetpro_refunds_unsettled':RefundRequest.objects.filter(status__in=['pending','unknown','initiating']).count(),
        'fleetpro_webhooks_unmatched':GatewayEvent.objects.filter(status='unmatched').count(),
        'fleetpro_delivery_failures_24h':NotificationLog.objects.filter(status='failed',created_at__gte=timezone.now()-timezone.timedelta(days=1)).count(),
        'fleetpro_worker_heartbeat_age_seconds':age,
    }
    from pathlib import Path
    import json
    try:
        backup=json.loads(Path(settings.BACKUP_STATUS_FILE).read_text())
        stamp=__import__('datetime').datetime.fromisoformat(backup['completed_at'])
        backup_age=(timezone.now()-stamp).total_seconds()
    except Exception:backup_age=-1
    values['fleetpro_backup_age_seconds']=backup_age
    values['fleetpro_backup_offsite_uploaded']=int(bool(backup.get('offsite_uploaded'))) if backup_age>=0 else 0
    text='\n'.join(f'# TYPE {name} gauge\n{name} {value}' for name,value in values.items())+'\n'
    response=HttpResponse(text,content_type='text/plain; version=0.0.4');response['Cache-Control']='no-store';return response

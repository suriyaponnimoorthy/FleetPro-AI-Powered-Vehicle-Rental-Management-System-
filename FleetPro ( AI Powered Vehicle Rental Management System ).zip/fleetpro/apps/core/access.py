"""One fail-closed branch policy for employee reads and related-object writes."""
from rest_framework.exceptions import PermissionDenied
EMPLOYEES = {'admin', 'staff'}

def scope(qs, user, path='branch'):
    if getattr(user, 'role', '') == 'super_admin':
        return qs
    if getattr(user, 'role', '') in EMPLOYEES:
        return qs.filter(**{path + '_id': user.branch_id}) if user.branch_id else qs.none()
    return qs.none()

def require_branch(user, branch_id):
    if getattr(user, 'role', '') == 'super_admin':
        return
    if getattr(user, 'role', '') not in EMPLOYEES or not user.branch_id or str(user.branch_id) != str(branch_id):
        raise PermissionDenied('This branch is outside your workspace.')

def check_relations(user, attrs):
    if getattr(user, 'role', '') not in EMPLOYEES | {'super_admin'}:
        return
    for key, value in attrs.items():
        if value is None:
            continue
        if key in {'branch', 'pickup_branch', 'drop_branch'}:
            require_branch(user, value.pk)
        elif key in {'vehicle', 'driver'}:
            require_branch(user, value.branch_id)
        elif key == 'booking':
            require_branch(user, value.vehicle.branch_id)
        elif key == 'customer':
            require_branch(user, value.user.branch_id)

    booking=attrs.get('booking')
    if booking:
        from rest_framework.exceptions import ValidationError
        if attrs.get('vehicle') and attrs['vehicle'].pk!=booking.vehicle_id:raise ValidationError('Vehicle differs from booking.')
        if attrs.get('customer') and attrs['customer'].pk!=booking.customer_id:raise ValidationError('Customer differs from booking.')

class BranchWriteMixin:
    def perform_create(self, serializer):
        check_relations(self.request.user, serializer.validated_data)
        serializer.save()

    def perform_update(self, serializer):
        check_relations(self.request.user, serializer.validated_data)
        serializer.save()

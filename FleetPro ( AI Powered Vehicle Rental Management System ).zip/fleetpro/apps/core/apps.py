from django.apps import AppConfig
class CoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.core"
    verbose_name = "Core"

    def ready(self):
        from . import production_checks
        from django.contrib import admin
        # Branch employees use scoped APIs. The unscoped Django console is super-admin only.
        admin.site.has_permission = lambda request: bool(request.user.is_active and request.user.is_staff and getattr(request.user, 'role', None)=='super_admin')

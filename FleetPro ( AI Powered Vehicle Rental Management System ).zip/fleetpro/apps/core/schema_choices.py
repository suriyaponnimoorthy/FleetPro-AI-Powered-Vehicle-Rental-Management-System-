from apps.bookings.models import Booking,BookingCancellation
from apps.vehicles.models import Vehicle,MaintenanceSchedule
from apps.payments.models import Payment,Invoice,DamageReport,Penalty
from apps.notifications.models import NotificationLog
from apps.authentication.models import User
from apps.drivers.models import DriverAttendance
BOOKING_STATUS=Booking.Status.choices
BOOKING_PAYMENT_STATUS=Booking.PaymentStatus.choices
VEHICLE_STATUS=Vehicle.Status.choices
MAINTENANCE_STATUS=MaintenanceSchedule.Status.choices
PAYMENT_STATUS=Payment.Status.choices
INVOICE_STATUS=Invoice.InvoiceStatus.choices
DAMAGE_STATUS=DamageReport.Status.choices
PENALTY_STATUS=Penalty.Status.choices
NOTIFICATION_STATUS=NotificationLog.Status.choices
FUEL=Vehicle.FuelType.choices
TRANSMISSION=Vehicle.TransmissionType.choices
USER_ROLE=User.Role.choices
HISTORY_ROLE=[('user','user'),('assistant','assistant')]
ATTENDANCE_STATUS=DriverAttendance._meta.get_field('status').choices

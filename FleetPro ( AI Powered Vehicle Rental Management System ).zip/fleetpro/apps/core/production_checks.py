from django.core.checks import register, Error, Tags
from django.conf import settings

@register(Tags.security, deploy=True)
def production_checks(app_configs, **kwargs):
    errors=[]
    if settings.DEBUG:errors.append(Error('DEBUG must be disabled.',id='fleetpro.E001'))
    if '*' in settings.ALLOWED_HOSTS:errors.append(Error('Wildcard hosts are not allowed.',id='fleetpro.E002'))
    if settings.DATABASES['default']['ENGINE']!='django.db.backends.postgresql':errors.append(Error('Production requires PostgreSQL.',id='fleetpro.E003'))
    if not settings.PRIVATE_UPLOAD_SCAN_REQUIRED:errors.append(Error('Production private uploads must require malware scanning.',id='fleetpro.E004'))
    if str(settings.PRIVATE_MEDIA_ROOT).startswith(str(settings.MEDIA_ROOT)+'/'):errors.append(Error('Private uploads cannot be stored under public MEDIA_ROOT.',id='fleetpro.E005'))
    if settings.EMAIL_BACKEND.endswith('console.EmailBackend'):errors.append(Error('Console email is not production delivery.',id='fleetpro.E006'))
    if not settings.SECURE_SSL_REDIRECT:errors.append(Error('HTTPS redirection is required.',id='fleetpro.E007'))
    return errors

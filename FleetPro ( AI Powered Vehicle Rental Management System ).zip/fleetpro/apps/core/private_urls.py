from django.urls import path
from .private_views import DocumentUploadView, DocumentContentView, MyDocumentsView
urlpatterns=[path('mine/',MyDocumentsView.as_view()),path('content/',DocumentContentView.as_view()),path('<str:kind>/<uuid:pk>/<str:field>/',DocumentUploadView.as_view())]

# apps/payments/admin.py
from django.contrib import admin
from apps.payments.models import Payment, Invoice, DamageReport, Penalty


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display  = ("transaction_id", "booking", "customer", "payment_type",
                     "method", "status", "amount", "paid_at")
    list_filter   = ("status", "payment_type", "method")
    search_fields = ("transaction_id", "gateway_transaction_id", "customer__user__email")
    readonly_fields = ("transaction_id", "created_at", "updated_at")
    date_hierarchy = "created_at"
    def has_add_permission(self,request): return False
    def has_change_permission(self,request,obj=None): return False
    def has_delete_permission(self,request,obj=None): return False


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display  = ("invoice_number", "customer", "status", "total_amount", "due_date", "paid_date")
    list_filter   = ("status",)
    search_fields = ("invoice_number", "customer__user__email")
    readonly_fields = ("invoice_number", "created_at")


@admin.register(DamageReport)
class DamageReportAdmin(admin.ModelAdmin):
    list_display  = ("report_number", "vehicle", "customer", "severity", "status",
                     "estimated_repair_cost", "is_insurance_claimed", "reported_at")
    list_filter   = ("severity", "status", "is_insurance_claimed")
    search_fields = ("report_number", "vehicle__registration_number", "customer__user__email")
    readonly_fields = ("report_number", "reported_at", "updated_at")


@admin.register(Penalty)
class PenaltyAdmin(admin.ModelAdmin):
    list_display  = ("booking", "customer", "penalty_type", "status", "amount", "created_at")
    list_filter   = ("penalty_type", "status")
    search_fields = ("booking__booking_number", "customer__user__email")

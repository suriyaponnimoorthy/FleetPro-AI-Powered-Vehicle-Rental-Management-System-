"""
apps/payments/models.py  &  apps/damage/models.py
Payment transactions, invoices, refunds, damage reports, fines, insurance claims.
"""

import uuid
from decimal import Decimal
from django.db import models
from django.utils import timezone


# ═══════════════════════════════════════════════════════════════════
#  PAYMENTS
# ═══════════════════════════════════════════════════════════════════

class Payment(models.Model):
    """Individual payment transaction (can be partial payments per booking)."""

    class PaymentType(models.TextChoices):
        BOOKING_PAYMENT = "booking_payment", "Booking Payment"
        SECURITY_DEPOSIT = "security_deposit", "Security Deposit"
        DEPOSIT_REFUND = "deposit_refund", "Security Deposit Refund"
        LATE_FEE = "late_fee", "Late Return Fee"
        DAMAGE_CHARGE = "damage_charge", "Damage Charge"
        PENALTY = "penalty", "Penalty"
        REFUND = "refund", "Refund"
        ADVANCE = "advance", "Advance Payment"

    class PaymentMethod(models.TextChoices):
        UPI = "upi", "UPI"
        CARD = "card", "Credit/Debit Card"
        NET_BANKING = "net_banking", "Net Banking"
        CASH = "cash", "Cash"
        WALLET = "wallet", "Wallet"
        BANK_TRANSFER = "bank_transfer", "Bank Transfer"
        CHEQUE = "cheque", "Cheque"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PROCESSING = "processing", "Processing"
        SUCCESS = "success", "Success"
        FAILED = "failed", "Failed"
        REFUNDED = "refunded", "Refunded"
        CANCELLED = "cancelled", "Cancelled"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_id = models.CharField(max_length=100, unique=True, db_index=True)
    booking = models.ForeignKey("bookings.Booking", on_delete=models.PROTECT, related_name="payments")
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.PROTECT)
    payment_type = models.CharField(max_length=25, choices=PaymentType.choices)
    method = models.CharField(max_length=20, choices=PaymentMethod.choices)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.PENDING, db_index=True)

    amount = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=3, default="INR")
    gateway_transaction_id = models.CharField(max_length=200, blank=True)
    gateway_response = models.JSONField(default=dict, blank=True)

    # Tax breakdown
    taxable_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    cgst = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    sgst = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    igst = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))

    notes = models.TextField(blank=True)
    processed_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, blank=True
    )
    paid_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "payments"
        indexes = [
            models.Index(fields=["booking", "status"]),
            models.Index(fields=["customer", "status"]),
            models.Index(fields=["payment_type", "status"]),
            models.Index(fields=["paid_at"]),
        ]
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.transaction_id:
            from apps.payments.utils import generate_transaction_id
            self.transaction_id = generate_transaction_id()
        if self.status == self.Status.SUCCESS and not self.paid_at:
            self.paid_at = timezone.now()
        super().save(*args, **kwargs)


class Invoice(models.Model):
    """GST-compliant invoice generated per booking."""

    class InvoiceStatus(models.TextChoices):
        DRAFT = "draft", "Draft"
        ISSUED = "issued", "Issued"
        PAID = "paid", "Paid"
        CANCELLED = "cancelled", "Cancelled"
        OVERDUE = "overdue", "Overdue"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    invoice_number = models.CharField(max_length=30, unique=True, db_index=True)
    booking = models.OneToOneField("bookings.Booking", on_delete=models.PROTECT, related_name="invoice")
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.PROTECT)
    status = models.CharField(max_length=15, choices=InvoiceStatus.choices, default=InvoiceStatus.DRAFT)

    # Amounts
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    taxable_amount = models.DecimalField(max_digits=12, decimal_places=2)
    cgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("9.00"))
    sgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("9.00"))
    cgst_amount = models.DecimalField(max_digits=10, decimal_places=2)
    sgst_amount = models.DecimalField(max_digits=10, decimal_places=2)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)

    # Line items
    line_items = models.JSONField(default=list)

    issued_date = models.DateField(auto_now_add=True)
    due_date = models.DateField()
    paid_date = models.DateField(null=True, blank=True)
    pdf_url = models.URLField(blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "invoices"
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.invoice_number:
            from apps.payments.utils import generate_invoice_number
            self.invoice_number = generate_invoice_number()
        super().save(*args, **kwargs)


# ═══════════════════════════════════════════════════════════════════
#  DAMAGE & PENALTIES
# ═══════════════════════════════════════════════════════════════════

class DamageReport(models.Model):
    """Vehicle damage report linked to a booking inspection."""

    class Severity(models.TextChoices):
        MINOR = "minor", "Minor"
        MODERATE = "moderate", "Moderate"
        MAJOR = "major", "Major"
        TOTAL_LOSS = "total_loss", "Total Loss"

    class Status(models.TextChoices):
        REPORTED = "reported", "Reported"
        UNDER_ASSESSMENT = "assessment", "Under Assessment"
        QUOTE_RECEIVED = "quoted", "Repair Quote Received"
        CUSTOMER_NOTIFIED = "notified", "Customer Notified"
        IN_REPAIR = "in_repair", "In Repair"
        REPAIRED = "repaired", "Repaired"
        CLAIMED = "claimed", "Insurance Claimed"
        CLOSED = "closed", "Closed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    report_number = models.CharField(max_length=20, unique=True)
    booking = models.ForeignKey("bookings.Booking", on_delete=models.PROTECT, related_name="damage_reports")
    vehicle = models.ForeignKey("vehicles.Vehicle", on_delete=models.PROTECT, related_name="damage_reports")
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.PROTECT)
    reported_by = models.ForeignKey("authentication.User", on_delete=models.SET_NULL, null=True)

    severity = models.CharField(max_length=15, choices=Severity.choices)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.REPORTED, db_index=True)
    damage_type = models.CharField(max_length=100)  # Dent, Scratch, Broken Glass, etc.
    damage_location = models.CharField(max_length=200)  # Front bumper, Rear door, etc.
    description = models.TextField()

    # Financials
    estimated_repair_cost = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    actual_repair_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    customer_liability_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    insurance_claim_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))

    # Evidence
    photos = models.JSONField(default=list)
    inspection_reference = models.ForeignKey(
        "bookings.VehicleInspection", on_delete=models.SET_NULL, null=True, blank=True
    )

    # Insurance
    is_insurance_claimed = models.BooleanField(default=False)
    insurance_claim_id = models.CharField(max_length=100, blank=True)
    insurance_policy = models.ForeignKey(
        "vehicles.VehicleInsurance", on_delete=models.SET_NULL, null=True, blank=True
    )

    repair_start_date = models.DateField(null=True, blank=True)
    repair_end_date = models.DateField(null=True, blank=True)
    repair_vendor = models.CharField(max_length=200, blank=True)

    customer_acknowledged = models.BooleanField(default=False)
    resolution_notes = models.TextField(blank=True)

    reported_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "damage_reports"
        indexes = [
            models.Index(fields=["booking", "status"]),
            models.Index(fields=["vehicle", "status"]),
            models.Index(fields=["customer", "status"]),
        ]
        ordering = ["-reported_at"]


class Penalty(models.Model):
    """Fine/penalty records for various violations."""

    class PenaltyType(models.TextChoices):
        LATE_RETURN = "late_return", "Late Return"
        LOW_FUEL = "low_fuel", "Returned with Low Fuel"
        TRAFFIC_FINE = "traffic_fine", "Traffic Fine"
        DAMAGE = "damage", "Damage Charge"
        SMOKING = "smoking", "Smoking in Vehicle"
        UNAUTHORIZED_DRIVER = "unauth_driver", "Unauthorized Driver"
        TOLL_CHARGES = "toll", "Toll Charges"
        OTHER = "other", "Other"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PAID = "paid", "Paid"
        DISPUTED = "disputed", "Disputed"
        WAIVED = "waived", "Waived"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking = models.ForeignKey("bookings.Booking", on_delete=models.PROTECT, related_name="penalties")
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.PROTECT)
    penalty_type = models.CharField(max_length=20, choices=PenaltyType.choices, db_index=True)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.PENDING)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    waived_reason = models.TextField(blank=True)
    waived_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, blank=True
    )
    payment = models.ForeignKey(Payment, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "penalties"
        indexes = [models.Index(fields=["customer", "status"])]
        ordering = ["-created_at"]

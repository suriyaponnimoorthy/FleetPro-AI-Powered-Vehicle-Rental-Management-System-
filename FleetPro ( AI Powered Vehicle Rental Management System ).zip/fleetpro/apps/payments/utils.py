# apps/payments/utils.py
import random
import string
from django.utils import timezone


def generate_transaction_id() -> str:
    """TXN-YYYYMMDD-XXXXXXXX"""
    date_str  = timezone.now().strftime("%Y%m%d")
    suffix    = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    candidate = f"TXN-{date_str}-{suffix}"
    from apps.payments.models import Payment
    if Payment.objects.filter(transaction_id=candidate).exists():
        return generate_transaction_id()
    return candidate


def generate_invoice_number() -> str:
    """INV-YYMM-XXXXX"""
    now       = timezone.now()
    prefix    = f"INV-{now.strftime('%y%m')}"
    suffix    = "".join(random.choices(string.digits, k=5))
    candidate = f"{prefix}-{suffix}"
    from apps.payments.models import Invoice
    if Invoice.objects.filter(invoice_number=candidate).exists():
        return generate_invoice_number()
    return candidate


def generate_invoice_pdf(invoice) -> bytes:
    """Generate PDF bytes for an invoice using ReportLab."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import (
            SimpleDocTemplate, Table, TableStyle,
            Paragraph, Spacer, HRFlowable,
        )
        import io

        buf    = io.BytesIO()
        doc    = SimpleDocTemplate(buf, pagesize=A4,
                                   topMargin=15*mm, bottomMargin=15*mm,
                                   leftMargin=20*mm, rightMargin=20*mm)
        styles = getSampleStyleSheet()
        story  = []

        # ── Header ────────────────────────────────────────────
        h1 = ParagraphStyle("h1", parent=styles["Heading1"],
                             fontSize=22, textColor=colors.HexColor("#1A1F36"))
        story.append(Paragraph("FleetPro Rentals Pvt. Ltd.", h1))
        story.append(Paragraph(
            "<font size='9' color='#6B7280'>GST: 29AABCC1234D1Z5 | "
            "12 Anna Salai, Chennai 600002 | support@fleetpro.in</font>",
            styles["Normal"]
        ))
        story.append(Spacer(1, 5*mm))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#F55D1E")))
        story.append(Spacer(1, 4*mm))

        # ── Invoice meta ───────────────────────────────────────
        meta = [
            ["TAX INVOICE", "", "Bill To:"],
            [f"#{invoice.invoice_number}", "", invoice.customer.user.get_full_name()],
            [f"Date: {invoice.issued_date.strftime('%d %b %Y')}", "", invoice.customer.user.email],
            [f"Due:  {invoice.due_date.strftime('%d %b %Y')}", "", ""],
            [f"Booking: {invoice.booking.booking_number}", "", ""],
        ]
        meta_t = Table(meta, colWidths=[80*mm, 30*mm, 60*mm])
        meta_t.setStyle(TableStyle([
            ("FONTNAME",  (0, 0), (0, 0), "Helvetica-Bold"),
            ("FONTSIZE",  (0, 0), (0, 0), 14),
            ("TEXTCOLOR", (0, 0), (0, 0), colors.HexColor("#F55D1E")),
            ("FONTNAME",  (2, 0), (2, 0), "Helvetica-Bold"),
            ("FONTSIZE",  (0, 1), (-1, -1), 9),
        ]))
        story.append(meta_t)
        story.append(Spacer(1, 6*mm))

        # ── Line items ─────────────────────────────────────────
        hdr  = [["Description", "Amount (₹)"]]
        rows = [[i.get("desc", i.get("description", "")), i.get("amount", "")] for i in (invoice.line_items or [])]
        totals = [
            ["", ""],
            ["Subtotal",         f"₹{invoice.subtotal}"],
            ["Discount",        f"-₹{invoice.discount}"],
            ["Taxable Amount",   f"₹{invoice.taxable_amount}"],
            ["CGST @ 9%",       f"₹{invoice.cgst_amount}"],
            ["SGST @ 9%",       f"₹{invoice.sgst_amount}"],
            ["", ""],
            ["TOTAL DUE",        f"₹{invoice.total_amount}"],
        ]
        all_rows = hdr + rows + totals
        lt = Table(all_rows, colWidths=[125*mm, 45*mm])
        lt.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0), colors.HexColor("#1A1F36")),
            ("TEXTCOLOR",     (0, 0), (-1, 0), colors.white),
            ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",      (0, 0), (-1, -1), 9),
            ("ALIGN",         (1, 0), (1, -1), "RIGHT"),
            ("ROWBACKGROUNDS",(0, 1), (-1, -5), [colors.white, colors.HexColor("#F7F8FC")]),
            ("FONTNAME",      (0, -1), (-1, -1), "Helvetica-Bold"),
            ("FONTSIZE",      (0, -1), (-1, -1), 12),
            ("TEXTCOLOR",     (0, -1), (-1, -1), colors.HexColor("#F55D1E")),
            ("LINEABOVE",     (0, -1), (-1, -1), 1.5, colors.HexColor("#F55D1E")),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ]))
        story.append(lt)
        story.append(Spacer(1, 8*mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#E5E7EB")))
        story.append(Paragraph(
            "<font size='8' color='#9CA3AF'>Thank you for choosing FleetPro! "
            "This is a computer-generated invoice and does not require a signature.</font>",
            styles["Normal"]
        ))
        doc.build(story)
        return buf.getvalue()

    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

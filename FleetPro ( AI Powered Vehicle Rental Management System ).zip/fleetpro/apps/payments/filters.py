# apps/payments/filters.py
import django_filters
from apps.payments.models import Payment, Invoice, DamageReport, Penalty


class PaymentFilter(django_filters.FilterSet):
    status        = django_filters.MultipleChoiceFilter(choices=Payment.Status.choices)
    payment_type  = django_filters.MultipleChoiceFilter(choices=Payment.PaymentType.choices)
    method        = django_filters.MultipleChoiceFilter(choices=Payment.PaymentMethod.choices)
    amount_min    = django_filters.NumberFilter(field_name="amount", lookup_expr="gte")
    amount_max    = django_filters.NumberFilter(field_name="amount", lookup_expr="lte")
    paid_from     = django_filters.DateFilter(field_name="paid_at__date", lookup_expr="gte")
    paid_to       = django_filters.DateFilter(field_name="paid_at__date", lookup_expr="lte")
    booking       = django_filters.UUIDFilter(field_name="booking__id")
    customer      = django_filters.UUIDFilter(field_name="customer__id")

    class Meta:
        model  = Payment
        fields = ["status", "payment_type", "method", "booking", "customer"]


class DamageReportFilter(django_filters.FilterSet):
    severity      = django_filters.MultipleChoiceFilter(choices=DamageReport.Severity.choices)
    status        = django_filters.MultipleChoiceFilter(choices=DamageReport.Status.choices)
    vehicle       = django_filters.UUIDFilter(field_name="vehicle__id")
    customer      = django_filters.UUIDFilter(field_name="customer__id")
    reported_from = django_filters.DateFilter(field_name="reported_at__date", lookup_expr="gte")
    reported_to   = django_filters.DateFilter(field_name="reported_at__date", lookup_expr="lte")

    class Meta:
        model  = DamageReport
        fields = ["severity", "status", "vehicle", "is_insurance_claimed"]


class PenaltyFilter(django_filters.FilterSet):
    status       = django_filters.MultipleChoiceFilter(choices=Penalty.Status.choices)
    penalty_type = django_filters.MultipleChoiceFilter(choices=Penalty.PenaltyType.choices)

    class Meta:
        model  = Penalty
        fields = ["status", "penalty_type", "customer", "booking"]

from apps.core.access import scope, BranchWriteMixin, check_relations
"""
apps/payments/views.py — Payment & Invoice CRUD
apps/damage/views.py   — Damage reports & penalties
apps/notifications/services.py — Notification dispatch
"""

import logging
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from apps.authentication.permissions import IsAdminOrStaff, IsOwnerOrAdminOrStaff

logger = logging.getLogger("apps.payments")


# ═══════════════════════════════════════════════════════════════
#  PAYMENT VIEWS
# ═══════════════════════════════════════════════════════════════

class PaymentViewSet(viewsets.ModelViewSet):
    """
    Payment transaction management.

    GET    /api/v1/payments/          — list (filtered by role)
    POST   /api/v1/payments/          — record payment
    GET    /api/v1/payments/{id}/     — payment detail
    POST   /api/v1/payments/{id}/refund/ — initiate refund
    GET    /api/v1/payments/summary/  — daily/monthly summary (admin)
    """
    from apps.payments.models import Payment, Invoice
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "payment_type", "method", "booking"]
    search_fields    = ["transaction_id", "gateway_transaction_id",
                        "booking__booking_number", "customer__user__email"]
    ordering_fields  = ["created_at", "paid_at", "amount"]
    ordering         = ["-created_at"]

    def get_queryset(self):
        from apps.payments.models import Payment
        qs = Payment.objects.select_related(
            "booking__vehicle", "customer__user", "processed_by"
        )
        user = self.request.user
        if getattr(user, 'role', '') == "customer":
            qs = qs.filter(customer__user=user)
        return scope(qs, user, "booking__vehicle__branch") if getattr(user, 'role', '') in ["admin","staff","super_admin"] else qs if getattr(user, 'role', '')=="customer" else qs.none()

    def get_serializer_class(self):
        from apps.payments.serializers import PaymentListSerializer, PaymentDetailSerializer, PaymentCreateSerializer
        if self.action == "create":
            return PaymentCreateSerializer
        if self.action == "list":
            return PaymentListSerializer
        return PaymentDetailSerializer

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [IsOwnerOrAdminOrStaff()]
        return [IsAdminOrStaff()]

    def create(self, request, *args, **kwargs):
        return Response({'error': 'Use checkout/orders; payment success requires provider verification.'}, status=405)

    def update(self, request, *args, **kwargs):
        return Response({'error': 'Payment history is read-only.'}, status=405)

    def destroy(self, request, *args, **kwargs):
        return Response({'error': 'Payment history is retained for audit.'}, status=405)

    @action(detail=True, methods=['post'])
    def refund(self, request, pk=None):
        self.get_object()
        return Response({'error': 'Use checkout/refunds with a verified capture and an idempotency key.'}, status=405)

    @action(detail=False, methods=["get"], url_path="summary")
    def summary(self, request):
        from apps.payments.models import Payment
        from django.db.models import Sum, Count
        from django.db.models.functions import Coalesce
        from django.db.models import DecimalField
        today = timezone.now().date()
        month_start = today.replace(day=1)

        stats = self.get_queryset().filter(status=Payment.Status.SUCCESS).exclude(payment_type__in=["refund", "deposit_refund"]).aggregate(
            today_total    = Coalesce(Sum("amount", filter=__import__("django.db.models", fromlist=["Q"]).Q(paid_at__date=today)), Decimal("0"), output_field=DecimalField()),
            month_total    = Coalesce(Sum("amount", filter=__import__("django.db.models", fromlist=["Q"]).Q(paid_at__date__gte=month_start)), Decimal("0"), output_field=DecimalField()),
            today_count    = Count("id", filter=__import__("django.db.models", fromlist=["Q"]).Q(paid_at__date=today)),
            pending_refunds= Count("id", filter=__import__("django.db.models", fromlist=["Q"]).Q(status="refunded", paid_at__date=today)),
        )
        return Response(stats)


class InvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    """Invoice retrieval and PDF download."""
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ["status", "customer"]
    search_fields    = ["invoice_number", "booking__booking_number", "customer__user__email"]

    def get_queryset(self):
        from apps.payments.models import Invoice
        qs = Invoice.objects.select_related("booking__vehicle", "customer__user")
        if getattr(self.request.user, 'role', '') == "customer":
            qs = qs.filter(customer__user=self.request.user)
        user = self.request.user
        return scope(qs, user, "booking__vehicle__branch") if getattr(user, 'role', '') in ["admin","staff","super_admin"] else qs if getattr(user, 'role', '')=="customer" else qs.none()

    def get_serializer_class(self):
        from apps.payments.serializers import InvoiceSerializer
        return InvoiceSerializer

    @action(detail=True, methods=["get"], url_path="download-pdf")
    def download_pdf(self, request, pk=None):
        """Generate and return invoice PDF."""
        invoice = self.get_object()
        try:
            from apps.payments.utils import generate_invoice_pdf
            pdf_content = generate_invoice_pdf(invoice)
            from django.http import HttpResponse
            response = HttpResponse(pdf_content, content_type="application/pdf")
            response["Content-Disposition"] = f'attachment; filename="invoice_{invoice.invoice_number}.pdf"'
            return response
        except Exception as e:
            logger.error(f"PDF generation failed for invoice {invoice.invoice_number}: {e}")
            return Response({"error": "PDF generation failed."}, status=500)


# ═══════════════════════════════════════════════════════════════
#  DAMAGE & PENALTY VIEWS
# ═══════════════════════════════════════════════════════════════

class DamageReportViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    """
    Damage report lifecycle management.
    POST /api/v1/damage-reports/                 — create report
    GET  /api/v1/damage-reports/{id}/            — get detail
    PATCH /api/v1/damage-reports/{id}/           — update status/cost
    POST /api/v1/damage-reports/{id}/close/      — close report
    POST /api/v1/damage-reports/{id}/claim-insurance/ — submit insurance claim
    """
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "severity", "vehicle", "is_insurance_claimed"]
    search_fields    = ["report_number", "vehicle__registration_number",
                        "customer__user__email", "damage_type"]
    ordering_fields  = ["reported_at", "estimated_repair_cost", "severity"]
    ordering         = ["-reported_at"]
    permission_classes = [IsAdminOrStaff]

    def get_queryset(self):
        from apps.payments.models import DamageReport
        return scope(DamageReport.objects.select_related("booking", "vehicle", "customer__user", "reported_by"), self.request.user, "vehicle__branch")

    def get_serializer_class(self):
        from apps.payments.serializers import DamageReportSerializer
        return DamageReportSerializer

    def perform_create(self, serializer):
        import random, string
        check_relations(self.request.user, serializer.validated_data)
        report_number = "DMG-" + "".join(random.choices(string.digits, k=6))
        serializer.save(
            reported_by=self.request.user,
            report_number=report_number,
        )

    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        from apps.payments.models import DamageReport
        report = self.get_object()
        report.status = DamageReport.Status.CLOSED
        report.resolution_notes = request.data.get("resolution_notes", "")
        report.actual_repair_cost = request.data.get("actual_repair_cost", report.estimated_repair_cost)
        report.save(update_fields=["status", "resolution_notes", "actual_repair_cost", "updated_at"])
        return Response({"message": "Damage report closed.", "report_number": report.report_number})

    @action(detail=True, methods=["post"], url_path="claim-insurance")
    def claim_insurance(self, request, pk=None):
        from apps.payments.models import DamageReport
        report = self.get_object()
        claim_id = request.data.get("claim_id", "")
        claim_amount = request.data.get("claim_amount", report.estimated_repair_cost)
        report.is_insurance_claimed = True
        report.insurance_claim_id = claim_id
        report.insurance_claim_amount = claim_amount
        report.status = DamageReport.Status.CLAIMED
        report.save()
        return Response({"message": "Insurance claim submitted.", "claim_id": claim_id})


class PenaltyViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    """Penalty management — late fees, damage charges, violations."""
    filter_backends  = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "penalty_type", "customer", "booking"]
    search_fields    = ["booking__booking_number", "customer__user__email"]
    ordering         = ["-created_at"]
    permission_classes = [IsAdminOrStaff]

    def get_queryset(self):
        from apps.payments.models import Penalty
        return scope(Penalty.objects.select_related("booking__vehicle", "customer__user", "waived_by"), self.request.user, "booking__vehicle__branch")

    def get_serializer_class(self):
        from apps.payments.serializers import PenaltySerializer
        return PenaltySerializer

    @action(detail=True, methods=["post"])
    def waive(self, request, pk=None):
        from apps.payments.models import Penalty
        penalty = self.get_object()
        if penalty.status != Penalty.Status.PENDING:
            return Response({"error": "Only pending penalties can be waived."}, status=400)
        reason = request.data.get("reason", "")
        if not reason:
            return Response({"error": "Waiver reason is required."}, status=400)
        penalty.status = Penalty.Status.WAIVED
        penalty.waived_reason = reason
        penalty.waived_by = request.user
        penalty.save(update_fields=["status", "waived_reason", "waived_by"])
        return Response({"message": "Penalty waived.", "penalty_id": str(penalty.id)})


# ═══════════════════════════════════════════════════════════════
#  NOTIFICATION SERVICE
# ═══════════════════════════════════════════════════════════════

from apps.notifications.services import NotificationService


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    """User notification inbox."""
    filter_backends  = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["channel", "status", "type"]
    ordering         = ["-created_at"]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        from apps.notifications.models import NotificationLog
        if not self.request.user.is_authenticated: return NotificationLog.objects.none()
        qs = NotificationLog.objects.filter(user=self.request.user)
        if getattr(self.request.user, 'role', '') in ["admin", "staff", "super_admin"]:
            qs = scope(NotificationLog.objects.all().select_related("user"), self.request.user, "user__branch")
        return qs

    def get_serializer_class(self):
        from apps.notifications.serializers import NotificationLogSerializer
        return NotificationLogSerializer

    @action(detail=True, methods=["post"], url_path="mark-read")
    def mark_read(self, request, pk=None):
        notif = self.get_object()
        notif.status = "read"
        notif.read_at = timezone.now()
        notif.save(update_fields=["status", "read_at"])
        return Response({"message": "Marked as read."})

    @action(detail=False, methods=["post"], url_path="mark-all-read")
    def mark_all_read(self, request):
        from apps.notifications.models import NotificationLog
        NotificationLog.objects.filter(
            user=request.user, status="sent"
        ).update(status="read", read_at=timezone.now())
        return Response({"message": "All notifications marked as read."})

"""
apps/payments/serializers.py
Serializers for Payment, Invoice, DamageReport, Penalty.
"""

from decimal import Decimal
from rest_framework import serializers
from .models import Payment, Invoice, DamageReport, Penalty


class PaymentListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.user.get_full_name", read_only=True)
    booking_number = serializers.CharField(source="booking.booking_number", read_only=True)

    class Meta:
        model = Payment
        fields = [
            "id", "transaction_id", "booking_number", "customer_name",
            "payment_type", "method", "status", "amount", "currency",
            "paid_at", "created_at",
        ]


class PaymentDetailSerializer(serializers.ModelSerializer):
    customer_name  = serializers.CharField(source="customer.user.get_full_name", read_only=True)
    customer_email = serializers.CharField(source="customer.user.email", read_only=True)
    booking_number = serializers.CharField(source="booking.booking_number", read_only=True)
    vehicle_name   = serializers.CharField(source="booking.vehicle.display_name", read_only=True)
    processed_by_name = serializers.SerializerMethodField()
    total_tax      = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = [
            "id", "transaction_id",
            "booking", "booking_number", "vehicle_name",
            "customer", "customer_name", "customer_email",
            "payment_type", "method", "status",
            "amount", "currency",
            "taxable_amount", "cgst", "sgst", "igst", "total_tax",
            "gateway_transaction_id", "gateway_response",
            "notes", "processed_by_name",
            "paid_at", "created_at", "updated_at",
        ]

    def get_processed_by_name(self, obj) -> str | None:
        if obj.processed_by:
            return obj.processed_by.get_full_name()
        return None

    def get_total_tax(self, obj) -> str | None:
        return str(obj.cgst + obj.sgst + obj.igst)


class PaymentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            "booking", "payment_type", "method", "amount",
            "gateway_transaction_id", "notes",
        ]

    def validate_amount(self, value):
        if value <= 0:
            raise serializers.ValidationError("Amount must be positive.")
        return value

    def validate(self, attrs):
        booking = attrs.get("booking")
        amount  = attrs.get("amount", Decimal("0"))
        if booking and amount > booking.balance_due + Decimal("1"):
            # Allow slight over-payment (rounding), but not excessive
            pass
        return attrs


class InvoiceSerializer(serializers.ModelSerializer):
    customer_name  = serializers.CharField(source="customer.user.get_full_name", read_only=True)
    booking_number = serializers.CharField(source="booking.booking_number", read_only=True)
    vehicle_name   = serializers.CharField(source="booking.vehicle.display_name", read_only=True)
    is_overdue     = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            "id", "invoice_number", "booking", "booking_number", "vehicle_name",
            "customer", "customer_name", "status",
            "subtotal", "discount", "taxable_amount",
            "cgst_rate", "sgst_rate", "cgst_amount", "sgst_amount", "total_amount",
            "line_items",
            "issued_date", "due_date", "paid_date",
            "pdf_url", "notes", "is_overdue", "created_at",
        ]

    def get_is_overdue(self, obj) -> bool:
        from django.utils import timezone
        if obj.status in ["issued"] and obj.due_date < timezone.now().date():
            return True
        return False


class DamageReportSerializer(serializers.ModelSerializer):
    vehicle_name     = serializers.CharField(source="vehicle.display_name", read_only=True)
    vehicle_reg      = serializers.CharField(source="vehicle.registration_number", read_only=True)
    customer_name    = serializers.CharField(source="customer.user.get_full_name", read_only=True)
    reported_by_name = serializers.SerializerMethodField()
    booking_number   = serializers.CharField(source="booking.booking_number", read_only=True)

    class Meta:
        model = DamageReport
        fields = [
            "id", "report_number",
            "booking", "booking_number",
            "vehicle", "vehicle_name", "vehicle_reg",
            "customer", "customer_name",
            "reported_by", "reported_by_name",
            "severity", "status",
            "damage_type", "damage_location", "description",
            "estimated_repair_cost", "actual_repair_cost",
            "customer_liability_amount", "insurance_claim_amount",
            "photos",
            "is_insurance_claimed", "insurance_claim_id",
            "repair_start_date", "repair_end_date", "repair_vendor",
            "customer_acknowledged", "resolution_notes",
            "reported_at", "updated_at",
        ]
        read_only_fields = ["report_number", "reported_by", "reported_at", "updated_at"]

    def get_reported_by_name(self, obj) -> str | None:
        if obj.reported_by:
            return obj.reported_by.get_full_name()
        return None


class PenaltySerializer(serializers.ModelSerializer):
    customer_name  = serializers.CharField(source="customer.user.get_full_name", read_only=True)
    booking_number = serializers.CharField(source="booking.booking_number", read_only=True)
    waived_by_name = serializers.SerializerMethodField()

    class Meta:
        model = Penalty
        fields = [
            "id",
            "booking", "booking_number",
            "customer", "customer_name",
            "penalty_type", "status", "amount", "description",
            "waived_reason", "waived_by", "waived_by_name",
            "payment", "created_at", "paid_at",
        ]
        read_only_fields = ["created_at", "paid_at"]

    def get_waived_by_name(self, obj) -> str | None:
        if obj.waived_by:
            return obj.waived_by.get_full_name()
        return None

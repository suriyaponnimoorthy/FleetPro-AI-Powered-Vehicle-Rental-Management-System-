"""
apps/payments/tasks.py — Celery tasks for payments
apps/payments/utils.py — Invoice/transaction number generators
"""

# ── tasks.py ─────────────────────────────────────────────────
from celery import shared_task
import logging

logger = logging.getLogger("apps.payments.tasks")


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def send_payment_receipt(self, payment_id: str):
    """Send payment receipt email after successful transaction."""
    try:
        from apps.payments.models import Payment
        from apps.notifications.views import NotificationService

        payment = Payment.objects.select_related(
            "booking__vehicle", "customer__user"
        ).get(id=payment_id)

        ns = NotificationService()
        ns.send_email(
            user=payment.customer.user,
            subject=f"Payment Receipt — {payment.transaction_id}",
            template="emails/payment_receipt.html",
            context={"payment": payment, "booking": payment.booking},
        )
        logger.info(f"Receipt sent for {payment.transaction_id}")
    except Exception as exc:
        logger.error(f"Receipt failed for payment {payment_id}: {exc}")
        raise self.retry(exc=exc)


@shared_task
def generate_daily_revenue_report():
    """Compile daily revenue and email super admins. Runs 11:59 PM via beat."""
    from apps.payments.models import Payment
    from apps.authentication.models import User
    from apps.notifications.views import NotificationService
    from django.db.models import Sum, Count
    from django.utils import timezone

    today = timezone.now().date()
    stats = Payment.objects.filter(
        status=Payment.Status.SUCCESS,
        paid_at__date=today,
    ).aggregate(total=Sum("amount"), count=Count("id"))

    ns = NotificationService()
    for admin in User.objects.filter(role="super_admin", is_active=True):
        ns.send_email(
            user=admin,
            subject=f"Daily Revenue Report — {today.strftime('%d %b %Y')}",
            template="emails/daily_revenue_report.html",
            context={"date": today, "total": stats["total"] or 0, "count": stats["count"] or 0},
        )


@shared_task
def auto_generate_invoice(booking_id: str):
    """Auto-generate GST invoice when booking payment is marked PAID."""
    try:
        from apps.bookings.models import Booking
        from apps.payments.models import Invoice
        from apps.payments.utils import generate_invoice_number
        from decimal import Decimal
        from django.utils import timezone
        from datetime import timedelta

        booking = Booking.objects.select_related("customer", "vehicle").get(id=booking_id)

        if Invoice.objects.filter(booking=booking).exists():
            return  # Already generated

        subtotal    = booking.base_amount + booking.driver_charges
        discount    = booking.discount_amount
        taxable     = subtotal - discount
        cgst        = taxable * Decimal("0.09")
        sgst        = taxable * Decimal("0.09")
        total       = taxable + cgst + sgst + booking.security_deposit

        Invoice.objects.create(
            invoice_number=generate_invoice_number(),
            booking=booking,
            customer=booking.customer,
            status="issued",
            subtotal=subtotal,
            discount=discount,
            taxable_amount=taxable,
            cgst_amount=cgst,
            sgst_amount=sgst,
            total_amount=total,
            issued_date=timezone.now().date(),
            due_date=timezone.now().date() + timedelta(days=7),
            line_items=[
                {"desc": f"Vehicle rental ({booking.rental_duration_days} days)", "amount": str(booking.base_amount)},
                {"desc": "Driver charges", "amount": str(booking.driver_charges)},
                {"desc": "Security deposit (refundable)", "amount": str(booking.security_deposit)},
                {"desc": "CGST 9%", "amount": str(cgst)},
                {"desc": "SGST 9%", "amount": str(sgst)},
            ],
        )
        logger.info(f"Invoice generated for booking {booking.booking_number}")
    except Exception as e:
        logger.error(f"Invoice generation failed for {booking_id}: {e}")


# ── utils.py ──────────────────────────────────────────────────
import random
import string
from django.utils import timezone


def generate_transaction_id() -> str:
    """Generate unique transaction ID: TXN-YYYYMMDD-XXXXXXXX"""
    date_str = timezone.now().strftime("%Y%m%d")
    suffix   = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    candidate = f"TXN-{date_str}-{suffix}"
    from apps.payments.models import Payment
    if Payment.objects.filter(transaction_id=candidate).exists():
        return generate_transaction_id()
    return candidate


def generate_invoice_number() -> str:
    """Generate unique invoice number: INV-YYMM-XXXXX"""
    now      = timezone.now()
    prefix   = f"INV-{now.strftime('%y%m')}"
    suffix   = "".join(random.choices(string.digits, k=5))
    candidate = f"{prefix}-{suffix}"
    from apps.payments.models import Invoice
    if Invoice.objects.filter(invoice_number=candidate).exists():
        return generate_invoice_number()
    return candidate


def generate_invoice_pdf(invoice) -> bytes:
    """
    Generate a PDF invoice using ReportLab.
    Returns raw PDF bytes.
    """
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import (
            SimpleDocTemplate, Table, TableStyle, Paragraph,
            Spacer, HRFlowable,
        )
        import io

        buffer = io.BytesIO()
        doc    = SimpleDocTemplate(buffer, pagesize=A4,
                                   topMargin=15*mm, bottomMargin=15*mm,
                                   leftMargin=20*mm, rightMargin=20*mm)
        styles = getSampleStyleSheet()
        story  = []

        # Header
        header_style = ParagraphStyle("header", parent=styles["Heading1"],
                                      fontSize=22, textColor=colors.HexColor("#1A1F36"))
        story.append(Paragraph("FleetPro Rentals Pvt. Ltd.", header_style))
        story.append(Paragraph(
            f"<font size='10' color='#6B7280'>GST: 29AABCC1234D1Z5 | Chennai, Tamil Nadu</font>",
            styles["Normal"]
        ))
        story.append(Spacer(1, 6*mm))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#F55D1E")))
        story.append(Spacer(1, 4*mm))

        # Invoice details
        inv_data = [
            ["INVOICE", "", "Bill To:"],
            [f"#{invoice.invoice_number}", "", invoice.customer.user.get_full_name()],
            [f"Date: {invoice.issued_date.strftime('%d %b %Y')}", "",
             invoice.customer.user.email or ""],
            [f"Due: {invoice.due_date.strftime('%d %b %Y')}", "", ""],
            [f"Booking: {invoice.booking.booking_number}", "", ""],
        ]
        t = Table(inv_data, colWidths=[80*mm, 30*mm, 60*mm])
        t.setStyle(TableStyle([
            ("FONTNAME",  (0, 0), (0, 0), "Helvetica-Bold"),
            ("FONTSIZE",  (0, 0), (0, 0), 16),
            ("TEXTCOLOR", (0, 0), (0, 0), colors.HexColor("#F55D1E")),
            ("FONTNAME",  (2, 0), (2, 0), "Helvetica-Bold"),
            ("FONTSIZE",  (2, 0), (2, 0), 9),
        ]))
        story.append(t)
        story.append(Spacer(1, 6*mm))

        # Line items
        headers = [["Description", "Amount (₹)"]]
        rows = [[item.get("desc", ""), item.get("amount", "")] for item in (invoice.line_items or [])]
        divider = [["", ""]]
        totals  = [
            ["Subtotal",    f"₹{invoice.subtotal}"],
            ["Discount",   f"-₹{invoice.discount}"],
            ["Taxable",     f"₹{invoice.taxable_amount}"],
            ["CGST 9%",     f"₹{invoice.cgst_amount}"],
            ["SGST 9%",     f"₹{invoice.sgst_amount}"],
            ["", ""],
            ["TOTAL",       f"₹{invoice.total_amount}"],
        ]
        all_rows = headers + rows + divider + totals
        lt = Table(all_rows, colWidths=[120*mm, 50*mm])
        lt.setStyle(TableStyle([
            ("BACKGROUND",  (0, 0), (-1, 0), colors.HexColor("#1A1F36")),
            ("TEXTCOLOR",   (0, 0), (-1, 0), colors.white),
            ("FONTNAME",    (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",    (0, 0), (-1, -1), 9),
            ("ALIGN",       (1, 0), (1, -1), "RIGHT"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#F7F8FC")]),
            ("FONTNAME",    (0, -1), (-1, -1), "Helvetica-Bold"),
            ("FONTSIZE",    (0, -1), (-1, -1), 12),
            ("TEXTCOLOR",   (0, -1), (-1, -1), colors.HexColor("#F55D1E")),
            ("LINEABOVE",   (0, -1), (-1, -1), 1.5, colors.HexColor("#F55D1E")),
            ("GRID",        (0, 0), (-1, 0), 0.5, colors.white),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ]))
        story.append(lt)

        # Footer
        story.append(Spacer(1, 8*mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#E5E7EB")))
        story.append(Paragraph(
            "<font size='8' color='#9CA3AF'>Thank you for choosing FleetPro! "
            "For support: support@fleetpro.in | +91 44 1234 5678</font>",
            styles["Normal"]
        ))

        doc.build(story)
        return buffer.getvalue()

    except ImportError:
        raise ImportError("ReportLab not installed. Run: pip install reportlab")

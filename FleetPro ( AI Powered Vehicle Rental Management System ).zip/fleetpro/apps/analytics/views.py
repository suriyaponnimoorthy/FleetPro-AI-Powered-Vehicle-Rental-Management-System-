from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
"""Branch-scoped operational aggregates. No shared cross-user response cache."""
from datetime import timedelta
from decimal import Decimal
from django.db.models import Sum, Count, Q, F
from django.db.models.functions import TruncMonth, TruncDay
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from apps.authentication.permissions import IsAdminOrStaff
from apps.core.access import scope
from apps.bookings.models import Booking
from apps.payments.models import Payment, Penalty
from apps.vehicles.models import Vehicle
from apps.customers.models import CustomerProfile
from apps.drivers.models import Driver

class BranchAnalytics(APIView):
    permission_classes = [IsAdminOrStaff]
    def bookings(self): return scope(Booking.objects.all(), self.request.user, 'vehicle__branch')
    def payments(self): return scope(Payment.objects.filter(status='success', payment_type='booking_payment'), self.request.user, 'booking__vehicle__branch')

class DashboardSummaryView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self, request):
        today=timezone.localdate(); month=today.replace(day=1)
        prior=(month-timedelta(days=1)).replace(day=1)
        b=self.bookings();p=self.payments()
        bookings=b.aggregate(total=Count('id'), active=Count('id',filter=Q(status='active')), pending=Count('id',filter=Q(status='pending')),
            today_pickups=Count('id',filter=Q(pickup_datetime__date=today,status__in=['confirmed','active'])),
            today_returns=Count('id',filter=Q(return_datetime__date=today,status='active')),
            this_month=Count('id',filter=Q(created_at__date__gte=month)),
            last_month=Count('id',filter=Q(created_at__date__gte=prior,created_at__date__lt=month)))
        revenue=p.aggregate(total_revenue=Sum('amount'),this_month_revenue=Sum('amount',filter=Q(paid_at__date__gte=month)),
            last_month_revenue=Sum('amount',filter=Q(paid_at__date__gte=prior,paid_at__date__lt=month)),today_revenue=Sum('amount',filter=Q(paid_at__date=today)))
        revenue={k:v or Decimal('0') for k,v in revenue.items()}
        pct=round(float((revenue['this_month_revenue']-revenue['last_month_revenue'])/revenue['last_month_revenue']*100),1) if revenue['last_month_revenue'] else 0
        revenue={**{k:str(v) for k,v in revenue.items()},'mom_change_pct':pct}
        bookings['mom_change_pct']=round((bookings['this_month']-bookings['last_month'])/max(bookings['last_month'],1)*100,1)
        vehicles=scope(Vehicle.objects.filter(is_active=True),request.user).aggregate(total=Count('id'),**{k:Count('id',filter=Q(status=k)) for k in ['available','rented','maintenance','reserved']})
        vehicles['utilization_pct']=round(vehicles['rented']/max(vehicles['total'],1)*100,1)
        customers=scope(CustomerProfile.objects.all(),request.user,'user__branch').aggregate(total=Count('id'),verified=Count('id',filter=Q(kyc_status='verified')),new_this_month=Count('id',filter=Q(created_at__date__gte=month)))
        penalties=scope(Penalty.objects.filter(status='pending'),request.user,'booking__vehicle__branch').aggregate(pending_count=Count('id'),pending_amount=Sum('amount'))
        penalties['pending_amount']=str(penalties['pending_amount'] or 0)
        return Response({'bookings':bookings,'revenue':revenue,'vehicles':vehicles,'customers':customers,'penalties':penalties,
            'overdue_bookings':b.filter(status='active',return_datetime__lt=timezone.now()).count(),'generated_at':timezone.now().isoformat()})

class MonthlyRevenueView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        try: year=int(request.query_params.get('year',timezone.now().year))
        except ValueError:return Response({'error':'Invalid year'},status=400)
        rows=self.payments().filter(paid_at__year=year).annotate(month=TruncMonth('paid_at')).values('month').annotate(revenue=Sum('amount')).order_by('month')
        return Response({'year':year,'monthly_breakdown':[{'month':r['month'].isoformat(),'gross_revenue':str(r['revenue'])} for r in rows]})

class RevenueByBranchView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        rows=self.payments().values(branch=F('booking__vehicle__branch__name')).annotate(revenue=Sum('amount')).order_by('-revenue')
        return Response({'branches':list(rows)})

class BookingTrendView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        rows=self.bookings().filter(created_at__gte=timezone.now()-timedelta(days=30)).annotate(day=TruncDay('created_at')).values('day').annotate(count=Count('id')).order_by('day')
        return Response({'trends':list(rows)})

class TopCustomersView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        rows=scope(CustomerProfile.objects.select_related('user'),request.user,'user__branch').order_by('-total_spend')[:10]
        return Response({'customers':[{'name':c.user.get_full_name(),'total_spend':str(c.total_spend),'total_bookings':c.total_bookings} for c in rows]})

class DriverPerformanceView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        return Response({'drivers':list(scope(Driver.objects.all(),request.user).values('id','user__first_name','user__last_name','total_trips','average_rating','experience_years','availability_status'))})

class VehicleUtilizationView(BranchAnalytics):
    @extend_schema(responses=OpenApiTypes.OBJECT)
    def get(self,request):
        return Response({'vehicles':list(scope(Vehicle.objects.all(),request.user).values('id','make','model','status','total_trips'))})

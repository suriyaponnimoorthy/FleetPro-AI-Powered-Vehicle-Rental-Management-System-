# apps/bookings/apps.py
from django.apps import AppConfig

class BookingsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.bookings"
    verbose_name = "Booking Management"

    def ready(self):
        import apps.bookings.signals  # noqa

# apps/bookings/admin.py
from django.contrib import admin
from apps.bookings.models import Booking, VehicleInspection, BookingReview, BookingCancellation


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display   = ("booking_number", "customer", "vehicle", "status",
                      "payment_status", "pickup_datetime", "return_datetime", "total_amount")
    list_filter    = ("status", "payment_status", "with_driver")
    search_fields  = ("booking_number", "customer__user__email", "vehicle__registration_number")
    readonly_fields = ("booking_number", "created_at", "updated_at",
                       "confirmed_at", "activated_at", "completed_at")
    date_hierarchy  = "pickup_datetime"
    ordering        = ("-created_at",)


@admin.register(VehicleInspection)
class InspectionAdmin(admin.ModelAdmin):
    list_display  = ("booking", "inspection_type", "overall_condition", "damage_noted", "inspected_at")
    list_filter   = ("inspection_type", "overall_condition", "damage_noted")


@admin.register(BookingReview)
class ReviewAdmin(admin.ModelAdmin):
    list_display  = ("booking", "customer", "overall_rating", "vehicle_rating", "is_published", "created_at")
    list_filter   = ("is_published", "overall_rating")


@admin.register(BookingCancellation)
class CancellationAdmin(admin.ModelAdmin):
    list_display  = ("booking", "cancelled_by", "cancellation_fee", "refund_amount", "refund_status", "cancelled_at")
    list_filter   = ("cancelled_by", "refund_status")
    readonly_fields = ("cancelled_at",)

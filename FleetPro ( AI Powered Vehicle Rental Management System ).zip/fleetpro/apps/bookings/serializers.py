"""
apps/bookings/serializers.py  — Booking serializers
apps/vehicles/serializers.py  — Vehicle serializers
All use nested representations and computed fields.
"""

from decimal import Decimal
from rest_framework import serializers
from apps.customers.models import CustomerProfile
from django.utils import timezone

# ──────────────────────────────────────────────────────────────
# VEHICLE SERIALIZERS
# ──────────────────────────────────────────────────────────────

class VehicleCategorySerializer(serializers.ModelSerializer):
    class Meta:
        from apps.vehicles.models import VehicleCategory
        model = VehicleCategory
        fields = [
            "id", "name", "type", "description", "icon",
            "base_price_per_day", "base_price_per_hour",
            "security_deposit", "is_active", "sort_order",
        ]


class BranchSerializer(serializers.ModelSerializer):
    class Meta:
        from apps.vehicles.models import Branch
        model = Branch
        fields = [
            "id", "name", "code", "address", "city", "state",
            "pincode", "phone", "email", "latitude", "longitude",
            "is_active", "opening_time", "closing_time",
        ]


class VehicleImageSerializer(serializers.ModelSerializer):
    class Meta:
        from apps.vehicles.models import VehicleImage
        model = VehicleImage
        fields = ["id", "image", "caption", "is_primary", "sort_order"]


class BookingVehicleListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for vehicle lists & availability checks."""
    category_name = serializers.CharField(source="category.name", read_only=True)
    category_type = serializers.CharField(source="category.type", read_only=True)
    branch_name   = serializers.CharField(source="branch.name", read_only=True)
    branch_city   = serializers.CharField(source="branch.city", read_only=True)
    daily_rate    = serializers.SerializerMethodField()
    primary_image = serializers.SerializerMethodField()

    class Meta:
        from apps.vehicles.models import Vehicle
        model = Vehicle
        fields = [
            "id", "registration_number", "make", "model", "variant",
            "year", "color", "status", "fuel_type", "transmission",
            "seating_capacity", "category_name", "category_type",
            "branch_name", "branch_city", "daily_rate",
            "average_rating", "total_trips", "primary_image",
        ]

    def get_daily_rate(self, obj) -> str | None:
        return str(obj.get_daily_rate())

    def get_primary_image(self, obj) -> str | None:
        img = obj.images.filter(is_primary=True).first()
        if img and img.image:
            request = self.context.get("request")
            if request:
                return request.build_absolute_uri(img.image.url)
        return None


class VehicleDetailSerializer(serializers.ModelSerializer):
    """Full vehicle detail with images, insurance status, features."""
    category        = VehicleCategorySerializer(read_only=True)
    branch          = BranchSerializer(read_only=True)
    images          = VehicleImageSerializer(many=True, read_only=True)
    daily_rate      = serializers.SerializerMethodField()
    security_deposit_amount = serializers.SerializerMethodField()
    insurance_status = serializers.SerializerMethodField()
    upcoming_maintenance = serializers.SerializerMethodField()

    class Meta:
        from apps.vehicles.models import Vehicle
        model = Vehicle
        fields = "__all__"

    def get_daily_rate(self, obj) -> str | None:
        return str(obj.get_daily_rate())

    def get_security_deposit_amount(self, obj) -> str | None:
        return str(obj.get_security_deposit())

    def get_insurance_status(self, obj) -> dict | None:
        policy = obj.insurance_policies.filter(is_active=True).order_by("-end_date").first()
        if not policy:
            return {"status": "no_policy"}
        return {
            "status": "expired" if policy.is_expired else "active",
            "days_to_expiry": policy.days_to_expiry,
            "policy_number": policy.policy_number,
            "insurance_type": policy.insurance_type,
            "end_date": policy.end_date,
        }

    def get_upcoming_maintenance(self, obj) -> dict | None:
        from apps.vehicles.models import MaintenanceSchedule
        sched = obj.maintenance_schedules.filter(
            status=MaintenanceSchedule.Status.SCHEDULED,
        ).order_by("scheduled_date").first()
        if not sched:
            return None
        return {
            "type": sched.maintenance_type,
            "scheduled_date": sched.scheduled_date,
            "estimated_cost": str(sched.estimated_cost),
        }


class VehicleCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        from apps.vehicles.models import Vehicle
        model = Vehicle
        exclude = ["total_trips", "average_rating", "created_at", "updated_at"]

    def validate_registration_number(self, value):
        return value.upper().replace(" ", "")

    def validate(self, attrs):
        if attrs.get("price_per_day") and attrs["price_per_day"] <= 0:
            raise serializers.ValidationError({"price_per_day": "Price must be positive."})
        return attrs


# ──────────────────────────────────────────────────────────────
# BOOKING SERIALIZERS
# ──────────────────────────────────────────────────────────────

class BookingListSerializer(serializers.ModelSerializer):
    """Compact booking list row."""
    customer_name = serializers.SerializerMethodField()
    customer_phone = serializers.SerializerMethodField()
    vehicle_name  = serializers.CharField(source="vehicle.display_name", read_only=True)
    vehicle_reg   = serializers.CharField(source="vehicle.registration_number", read_only=True)
    driver_name   = serializers.SerializerMethodField()
    balance_due   = serializers.SerializerMethodField()
    is_overdue    = serializers.BooleanField(read_only=True)
    overdue_hours = serializers.IntegerField(read_only=True)

    class Meta:
        from apps.bookings.models import Booking
        model = Booking
        fields = [
            "id", "booking_number", "status", "payment_status",
            "customer_name", "customer_phone",
            "vehicle_name", "vehicle_reg",
            "driver_name", "with_driver",
            "pickup_datetime", "return_datetime", "actual_return_datetime",
            "total_amount", "amount_paid", "balance_due",
            "is_overdue", "overdue_hours",
            "created_at",
        ]

    def get_customer_name(self, obj) -> str | None:
        return obj.customer.user.get_full_name()

    def get_customer_phone(self, obj) -> str | None:
        return str(obj.customer.user.phone) if obj.customer.user.phone else ""

    def get_driver_name(self, obj) -> str | None:
        if obj.driver:
            return obj.driver.user.get_full_name()
        return "Self Drive"

    def get_balance_due(self, obj) -> str | None:
        return str(obj.balance_due)


class BookingDetailSerializer(serializers.ModelSerializer):
    """Full booking detail — all related objects nested."""
    customer = serializers.SerializerMethodField()
    vehicle  = BookingVehicleListSerializer(read_only=True)
    driver   = serializers.SerializerMethodField()
    payments = serializers.SerializerMethodField()
    penalties = serializers.SerializerMethodField()
    inspections = serializers.SerializerMethodField()
    balance_due = serializers.SerializerMethodField()
    rental_duration_days = serializers.IntegerField(read_only=True)
    is_overdue = serializers.BooleanField(read_only=True)
    overdue_hours = serializers.IntegerField(read_only=True)
    late_fee = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        from apps.bookings.models import Booking
        model = Booking
        fields = "__all__"

    def get_customer(self, obj) -> dict | None:
        u = obj.customer.user
        return {
            "id": str(u.id),
            "full_name": u.get_full_name(),
            "email": u.email,
            "phone": str(u.phone) if u.phone else "",
            "kyc_status": obj.customer.kyc_status,
            "total_bookings": obj.customer.total_bookings,
        }

    def get_driver(self, obj) -> dict | None:
        if not obj.driver:
            return None
        u = obj.driver.user
        return {
            "id": str(obj.driver.id),
            "full_name": u.get_full_name(),
            "phone": str(u.phone) if u.phone else "",
            "average_rating": str(obj.driver.average_rating),
            "experience_years": obj.driver.experience_years,
        }

    def get_payments(self, obj) -> list:
        from apps.payments.models import Payment
        return obj.payments.values(
            "id", "transaction_id", "payment_type", "method",
            "status", "amount", "paid_at"
        )

    def get_penalties(self, obj) -> list:
        return obj.penalties.values(
            "id", "penalty_type", "status", "amount", "description", "created_at"
        )

    def get_inspections(self, obj) -> list:
        return obj.inspections.values(
            "id", "inspection_type", "overall_condition",
            "damage_noted", "odometer_reading", "fuel_level", "inspected_at"
        )

    def get_balance_due(self, obj) -> str | None:
        return str(obj.balance_due)


class BookingCreateSerializer(serializers.ModelSerializer):
    """Booking creation — validates dates, availability, customer KYC."""

    customer = serializers.PrimaryKeyRelatedField(queryset=CustomerProfile.objects.all(), required=False)

    class Meta:
        from apps.bookings.models import Booking
        model = Booking
        fields = [
            "customer", "vehicle", "driver", "pickup_datetime", "return_datetime",
            "pickup_location", "pickup_branch", "drop_location", "drop_branch",
            "with_driver", "fuel_policy", "special_requests",
        ]

    def validate(self, attrs):
        pickup = attrs["pickup_datetime"]
        return_ = attrs["return_datetime"]
        now = timezone.now()

        if pickup < now:
            raise serializers.ValidationError({"pickup_datetime": "Pickup cannot be in the past."})

        if return_ <= pickup:
            raise serializers.ValidationError({"return_datetime": "Return must be after pickup."})

        from django.conf import settings
        max_days = settings.FLEETPRO.get("MAX_BOOKING_DAYS", 30)
        duration = (return_ - pickup).total_seconds() / 86400
        if duration > max_days:
            raise serializers.ValidationError(
                {"return_datetime": f"Booking cannot exceed {max_days} days."}
            )

        # Customer KYC check
        request = self.context.get("request")
        if request and request.user.role == "customer":
            try:
                from apps.customers.models import CustomerProfile
                profile = CustomerProfile.objects.get(user=request.user)
                if profile.is_blacklisted:
                    raise serializers.ValidationError("Your account is restricted from making bookings.")
                if profile.kyc_status != "verified":
                    raise serializers.ValidationError("KYC verification required before booking.")
                attrs["customer_obj"] = profile
            except CustomerProfile.DoesNotExist:
                raise serializers.ValidationError("Customer profile not found.")

        if request and request.user.role in ['super_admin', 'admin', 'staff']:
            if not attrs.get('customer'):
                raise serializers.ValidationError({'customer': 'Select a verified customer.'})
            profile = attrs['customer']
            if profile.is_blacklisted or profile.kyc_status != 'verified':
                raise serializers.ValidationError({'customer': 'Customer must pass KYC and have no booking restriction.'})
        elif request and request.user.role != 'customer':
            raise serializers.ValidationError('Only customers and rental employees can create bookings.')

        # Driver + with_driver consistency
        if attrs.get("with_driver") and not attrs.get("driver"):
            raise serializers.ValidationError(
                {"driver": "Driver must be specified when 'with_driver' is true."}
            )

        return attrs

    def create(self, validated_data):
        supplied_customer = validated_data.pop('customer', None)
        customer_obj = validated_data.pop("customer_obj", None) or supplied_customer
        request = self.context.get("request")

        if customer_obj is None and request:
            from apps.customers.models import CustomerProfile
            customer_obj = CustomerProfile.objects.get(user=request.user)

        booking = super().create({**validated_data, "customer": customer_obj})
        return booking


class AvailabilityCheckSerializer(serializers.Serializer):
    vehicle_id      = serializers.UUIDField(required=False)
    pickup_datetime = serializers.DateTimeField()
    return_datetime = serializers.DateTimeField()
    category_id     = serializers.UUIDField(required=False)
    branch_id       = serializers.UUIDField(required=False)

    def validate(self, attrs):
        if attrs["return_datetime"] <= attrs["pickup_datetime"]:
            raise serializers.ValidationError("Return must be after pickup.")
        return attrs


class InspectionSerializer(serializers.ModelSerializer):
    class Meta:
        from apps.bookings.models import VehicleInspection
        model = VehicleInspection
        fields = "__all__"
        read_only_fields = ["inspected_by", "inspected_at", "customer_signature"]

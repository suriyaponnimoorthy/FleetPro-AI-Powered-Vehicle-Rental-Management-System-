from apps.core.private_files import private_storage, validate_private_file
import math
"""
apps/bookings/models.py
Booking lifecycle: Booking, BookingItem, Cancellation, Review, Inspection.
Includes conflict detection query methods.
"""

import uuid
from decimal import Decimal
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.db.models import Q
from django.core.exceptions import ValidationError
from django.utils import timezone


class Booking(models.Model):
    """
    Central booking entity. Tracks full lifecycle from request → completion.
    Uses SELECT FOR UPDATE in booking creation to prevent race conditions.
    """

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        PENDING = "pending", "Pending Approval"
        CONFIRMED = "confirmed", "Confirmed"
        ACTIVE = "active", "Active / In Progress"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"
        NO_SHOW = "no_show", "No Show"

    class PaymentStatus(models.TextChoices):
        PENDING = "pending", "Payment Pending"
        PARTIAL = "partial", "Partially Paid"
        PAID = "paid", "Fully Paid"
        REFUNDED = "refunded", "Refunded"
        OVERDUE = "overdue", "Payment Overdue"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking_number = models.CharField(max_length=20, unique=True, db_index=True)

    # Parties
    customer = models.ForeignKey(
        "customers.CustomerProfile", on_delete=models.PROTECT, related_name="bookings"
    )
    vehicle = models.ForeignKey(
        "vehicles.Vehicle", on_delete=models.PROTECT, related_name="bookings"
    )
    driver = models.ForeignKey(
        "drivers.Driver", on_delete=models.SET_NULL, null=True, blank=True, related_name="bookings"
    )
    created_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, related_name="bookings_created"
    )
    approved_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="bookings_approved"
    )

    # Schedule
    pickup_datetime = models.DateTimeField(db_index=True)
    return_datetime = models.DateTimeField(db_index=True)
    actual_return_datetime = models.DateTimeField(null=True, blank=True)

    # Locations
    pickup_location = models.CharField(max_length=500)
    pickup_branch = models.ForeignKey(
        "vehicles.Branch", on_delete=models.PROTECT, related_name="pickup_bookings",
        null=True, blank=True
    )
    drop_location = models.CharField(max_length=500)
    drop_branch = models.ForeignKey(
        "vehicles.Branch", on_delete=models.PROTECT, related_name="drop_bookings",
        null=True, blank=True
    )

    # Status
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING, db_index=True)
    payment_status = models.CharField(max_length=20, choices=PaymentStatus.choices, default=PaymentStatus.PENDING)

    # Pricing (captured at booking time — not affected by future price changes)
    base_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    driver_charges = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    gst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    security_deposit = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))

    # Odometer
    odometer_at_pickup = models.PositiveIntegerField(null=True, blank=True)
    odometer_at_return = models.PositiveIntegerField(null=True, blank=True)
    total_km_driven = models.PositiveIntegerField(null=True, blank=True)

    # Fuel
    fuel_level_at_pickup = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    fuel_level_at_return = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )

    # Options
    with_driver = models.BooleanField(default=False)
    fuel_policy = models.CharField(
        max_length=20,
        choices=[("full_to_full", "Full to Full"), ("prepaid", "Prepaid Fuel")],
        default="full_to_full"
    )
    special_requests = models.TextField(blank=True)
    internal_notes = models.TextField(blank=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    activated_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "bookings"
        indexes = [
            models.Index(fields=["vehicle", "pickup_datetime", "return_datetime"]),
            models.Index(fields=["customer", "status"]),
            models.Index(fields=["status", "payment_status"]),
            models.Index(fields=["pickup_datetime", "status"]),
            models.Index(fields=["driver", "status"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return f"Booking {self.booking_number} — {self.vehicle}"

    # ─── CONFLICT DETECTION ──────────────────────────────────────
    @classmethod
    def check_vehicle_availability(cls, vehicle_id, pickup_dt, return_dt, exclude_booking_id=None):
        """
        Returns True if vehicle is available for the given date range.
        Uses overlap detection: (A.start < B.end) AND (A.end > B.start)
        """
        qs = cls.objects.filter(
            vehicle_id=vehicle_id,
            status__in=[cls.Status.CONFIRMED, cls.Status.ACTIVE, cls.Status.PENDING],
        ).filter(
            Q(pickup_datetime__lt=return_dt) & Q(return_datetime__gt=pickup_dt)
        )
        if exclude_booking_id:
            qs = qs.exclude(id=exclude_booking_id)
        return not qs.exists()

    @classmethod
    def check_driver_availability(cls, driver_id, pickup_dt, return_dt, exclude_booking_id=None):
        """Check driver availability for the given time range."""
        qs = cls.objects.filter(
            driver_id=driver_id,
            status__in=[cls.Status.PENDING, cls.Status.CONFIRMED, cls.Status.ACTIVE],
        ).filter(
            Q(pickup_datetime__lt=return_dt) & Q(return_datetime__gt=pickup_dt)
        )
        if exclude_booking_id:
            qs = qs.exclude(id=exclude_booking_id)
        return not qs.exists()

    # ─── CALCULATIONS ────────────────────────────────────────────
    @property
    def rental_duration_days(self):
        delta = self.return_datetime - self.pickup_datetime
        days = delta.days
        hours = delta.seconds // 3600
        return max(1, math.ceil(delta.total_seconds() / 86400))

    @property
    def is_overdue(self):
        if self.status == self.Status.ACTIVE and timezone.now() > self.return_datetime:
            return True
        return False

    @property
    def overdue_hours(self):
        if self.is_overdue:
            delta = timezone.now() - self.return_datetime
            return int(delta.total_seconds() / 3600)
        return 0

    @property
    def late_fee(self):
        from django.conf import settings
        rate = settings.FLEETPRO.get("LATE_FEE_PER_HOUR", 100)
        return self.overdue_hours * rate

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.total_amount - self.amount_paid)

    def calculate_total(self):
        """Recalculate booking total based on duration and rates."""
        from django.conf import settings
        daily_rate = self.vehicle.get_daily_rate()
        self.base_amount = daily_rate * self.rental_duration_days
        if self.with_driver and self.driver:
            self.driver_charges = self.driver.daily_rate * self.rental_duration_days
        subtotal = self.base_amount + self.driver_charges - self.discount_amount
        gst_rate = Decimal(str(settings.FLEETPRO.get("GST_RATE", 0.18)))
        self.gst_amount = subtotal * gst_rate
        self.security_deposit = self.vehicle.get_security_deposit()
        self.total_amount = subtotal + self.gst_amount + self.security_deposit
        return self.total_amount

    def save(self, *args, **kwargs):
        if not self.booking_number:
            from apps.bookings.utils import generate_booking_number
            self.booking_number = generate_booking_number()
        super().save(*args, **kwargs)


class BookingCancellation(models.Model):
    """Cancellation record with refund tracking."""

    class CancelledBy(models.TextChoices):
        CUSTOMER = "customer", "Customer"
        ADMIN = "admin", "Admin"
        SYSTEM = "system", "System (Auto)"

    class RefundStatus(models.TextChoices):
        NOT_APPLICABLE = "na", "Not Applicable"
        PENDING = "pending", "Pending"
        PROCESSED = "processed", "Processed"
        FAILED = "failed", "Failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="cancellation")
    cancelled_by = models.CharField(max_length=20, choices=CancelledBy.choices)
    cancelled_by_user = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True
    )
    reason = models.TextField()
    cancellation_fee = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    refund_status = models.CharField(max_length=10, choices=RefundStatus.choices, default=RefundStatus.PENDING)
    cancelled_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "booking_cancellations"


class VehicleInspection(models.Model):
    """Pre/post rental vehicle inspection records."""

    class InspectionType(models.TextChoices):
        PRE_RENTAL = "pre_rental", "Pre-Rental Inspection"
        POST_RENTAL = "post_rental", "Post-Rental Inspection"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="inspections")
    inspection_type = models.CharField(max_length=20, choices=InspectionType.choices)
    inspected_by = models.ForeignKey(
        "authentication.User", on_delete=models.SET_NULL, null=True
    )
    odometer_reading = models.PositiveIntegerField()
    fuel_level = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )

    # Condition checklist (JSON: {part: status})
    body_condition = models.JSONField(default=dict)
    interior_condition = models.JSONField(default=dict)
    tyres_condition = models.JSONField(default=dict)
    accessories_checklist = models.JSONField(default=dict)

    overall_condition = models.CharField(
        max_length=20,
        choices=[("excellent", "Excellent"), ("good", "Good"), ("fair", "Fair"), ("poor", "Poor")],
    )
    damage_noted = models.BooleanField(default=False)
    damage_description = models.TextField(blank=True)
    customer_signature = models.ImageField(storage=private_storage, validators=[validate_private_file], upload_to="inspections/signatures/", blank=True)
    photos = models.JSONField(default=list)  # List of photo URLs
    notes = models.TextField(blank=True)
    inspected_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "vehicle_inspections"
        unique_together = [("booking", "inspection_type")]


class BookingReview(models.Model):
    """Customer review for completed bookings."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="review")
    customer = models.ForeignKey("authentication.User", on_delete=models.CASCADE)
    vehicle_rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    driver_rating = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(5)])
    service_rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    overall_rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    review_text = models.TextField(blank=True)
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "booking_reviews"
        ordering = ["-created_at"]

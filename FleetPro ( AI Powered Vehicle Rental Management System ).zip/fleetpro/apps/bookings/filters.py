"""
apps/bookings/filters.py — Django-filter for Booking model
apps/bookings/utils.py   — Booking number generator & helpers
apps/vehicles/filters.py — Vehicle filter
"""

# ─── apps/bookings/filters.py ────────────────────────────────

import django_filters
from django.db.models import Q
from .models import Booking


class BookingFilter(django_filters.FilterSet):
    status          = django_filters.MultipleChoiceFilter(choices=Booking.Status.choices)
    payment_status  = django_filters.MultipleChoiceFilter(choices=Booking.PaymentStatus.choices)
    pickup_date_from = django_filters.DateFilter(field_name="pickup_datetime__date", lookup_expr="gte")
    pickup_date_to   = django_filters.DateFilter(field_name="pickup_datetime__date", lookup_expr="lte")
    return_date_from = django_filters.DateFilter(field_name="return_datetime__date",  lookup_expr="gte")
    return_date_to   = django_filters.DateFilter(field_name="return_datetime__date",  lookup_expr="lte")
    created_from     = django_filters.DateFilter(field_name="created_at__date", lookup_expr="gte")
    created_to       = django_filters.DateFilter(field_name="created_at__date", lookup_expr="lte")
    amount_min       = django_filters.NumberFilter(field_name="total_amount", lookup_expr="gte")
    amount_max       = django_filters.NumberFilter(field_name="total_amount", lookup_expr="lte")
    vehicle          = django_filters.UUIDFilter(field_name="vehicle__id")
    customer         = django_filters.UUIDFilter(field_name="customer__id")
    driver           = django_filters.UUIDFilter(field_name="driver__id")
    branch           = django_filters.UUIDFilter(field_name="pickup_branch__id")
    with_driver      = django_filters.BooleanFilter()
    is_overdue       = django_filters.BooleanFilter(method="filter_overdue")

    class Meta:
        model = Booking
        fields = [
            "status", "payment_status", "vehicle", "customer", "driver",
            "branch", "with_driver",
        ]

    def filter_overdue(self, queryset, name, value):
        from django.utils import timezone
        if value:
            return queryset.filter(
                status=Booking.Status.ACTIVE,
                return_datetime__lt=timezone.now(),
            )
        return queryset


# ─── apps/bookings/utils.py ──────────────────────────────────

import random
import string
from django.utils import timezone


def generate_booking_number() -> str:
    """
    Generate unique booking number: BK-YYYYMM-XXXXX
    e.g. BK-202505-A3K9P
    """
    now    = timezone.now()
    prefix = f"BK-{now.year}{now.month:02d}"
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    candidate = f"{prefix}-{suffix}"

    from apps.bookings.models import Booking
    if Booking.objects.filter(booking_number=candidate).exists():
        return generate_booking_number()  # Retry on collision
    return candidate


def calculate_rental_cost(
    vehicle,
    pickup_datetime,
    return_datetime,
    with_driver: bool = False,
    driver=None,
    discount_amount=0,
):
    """
    Calculate full booking cost breakdown.
    Returns dict with all line items.
    """
    from django.conf import settings
    from decimal import Decimal

    delta   = return_datetime - pickup_datetime
    days    = delta.days
    hours   = delta.seconds // 3600
    # Partial day billed as full day
    rental_days = days + (1 if hours > 0 else 0)

    daily_rate   = vehicle.get_daily_rate()
    base_amount  = daily_rate * rental_days

    driver_charges = Decimal("0")
    if with_driver and driver:
        driver_charges = driver.daily_rate * rental_days

    subtotal     = base_amount + driver_charges - Decimal(str(discount_amount))
    gst_rate     = Decimal(str(settings.FLEETPRO.get("GST_RATE", 0.18)))
    gst_amount   = subtotal * gst_rate
    deposit      = vehicle.get_security_deposit()
    total        = subtotal + gst_amount + deposit

    return {
        "rental_days":      rental_days,
        "daily_rate":       str(daily_rate),
        "base_amount":      str(base_amount),
        "driver_charges":   str(driver_charges),
        "discount_amount":  str(discount_amount),
        "gst_rate":         str(gst_rate * 100) + "%",
        "gst_amount":       str(gst_amount.quantize(Decimal("0.01"))),
        "security_deposit": str(deposit),
        "total_amount":     str(total.quantize(Decimal("0.01"))),
        "line_items": [
            {"description": f"Vehicle rental — {rental_days} day(s) × ₹{daily_rate}", "amount": str(base_amount)},
            *([{"description": f"Driver charges — {rental_days} day(s) × ₹{driver.daily_rate}", "amount": str(driver_charges)}] if driver_charges else []),
            *([{"description": "Discount",           "amount": f"-{discount_amount}"}] if discount_amount else []),
            {"description": f"GST (18%)",             "amount": str(gst_amount.quantize(Decimal("0.01")))},
            {"description": "Refundable security deposit", "amount": str(deposit)},
        ],
    }


# ─── apps/vehicles/filters.py ────────────────────────────────

import django_filters
from apps.vehicles.models import Vehicle


class VehicleFilter(django_filters.FilterSet):
    status        = django_filters.MultipleChoiceFilter(choices=Vehicle.Status.choices)
    fuel_type     = django_filters.MultipleChoiceFilter(choices=Vehicle.FuelType.choices)
    transmission  = django_filters.MultipleChoiceFilter(choices=Vehicle.TransmissionType.choices)
    category_type = django_filters.CharFilter(field_name="category__type", lookup_expr="iexact")
    category      = django_filters.UUIDFilter(field_name="category__id")
    branch        = django_filters.UUIDFilter(field_name="branch__id")
    city          = django_filters.CharFilter(field_name="branch__city", lookup_expr="iexact")
    price_min     = django_filters.NumberFilter(method="filter_price_min")
    price_max     = django_filters.NumberFilter(method="filter_price_max")
    seats_min     = django_filters.NumberFilter(field_name="seating_capacity", lookup_expr="gte")
    year_from     = django_filters.NumberFilter(field_name="year", lookup_expr="gte")
    year_to       = django_filters.NumberFilter(field_name="year", lookup_expr="lte")
    rating_min    = django_filters.NumberFilter(field_name="average_rating", lookup_expr="gte")

    class Meta:
        model = Vehicle
        fields = [
            "status", "fuel_type", "transmission", "category",
            "category_type", "branch", "city",
        ]

    def filter_price_min(self, queryset, name, value):
        from django.db.models import Q, Coalesce, F
        from django.db.models.functions import Coalesce as C
        return queryset.filter(
            Q(price_per_day__gte=value) |
            Q(price_per_day__isnull=True, category__base_price_per_day__gte=value)
        )

    def filter_price_max(self, queryset, name, value):
        from django.db.models import Q
        return queryset.filter(
            Q(price_per_day__lte=value) |
            Q(price_per_day__isnull=True, category__base_price_per_day__lte=value)
        )

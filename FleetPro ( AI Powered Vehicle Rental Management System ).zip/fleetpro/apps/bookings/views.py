from apps.core.access import scope, check_relations
"""
apps/bookings/views.py
Full CRUD + workflow transitions for Booking.
Includes availability check, conflict detection, and status lifecycle.
"""

import logging
from django.db import transaction
from django.utils import timezone
from django.db.models import Q, Sum, Count
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema, OpenApiParameter

from .models import Booking, BookingCancellation, VehicleInspection
from .serializers import (
    BookingCreateSerializer, BookingDetailSerializer,
    BookingListSerializer,
    AvailabilityCheckSerializer, InspectionSerializer,
)
from .filters import BookingFilter
from .tasks import send_booking_confirmation, send_return_reminder
from apps.authentication.permissions import IsAdminOrStaff, IsOwnerOrAdminOrStaff
from apps.vehicles.models import Vehicle
from apps.authentication.models import ActivityLog

logger = logging.getLogger("apps.bookings")


class BookingViewSet(viewsets.ModelViewSet):
    """
    Full booking lifecycle management.

    list:         GET  /api/v1/bookings/
    create:       POST /api/v1/bookings/
    retrieve:     GET  /api/v1/bookings/{id}/
    update:       PUT  /api/v1/bookings/{id}/
    partial_update: PATCH /api/v1/bookings/{id}/
    destroy:      DELETE /api/v1/bookings/{id}/

    Extra actions:
    check_availability: POST /api/v1/bookings/check-availability/
    confirm:            POST /api/v1/bookings/{id}/confirm/
    activate:           POST /api/v1/bookings/{id}/activate/
    complete:           POST /api/v1/bookings/{id}/complete/
    cancel:             POST /api/v1/bookings/{id}/cancel/
    inspection:         POST /api/v1/bookings/{id}/inspection/
    """

    queryset = Booking.objects.select_related(
        "customer__user", "vehicle__category", "vehicle__branch",
        "driver__user", "created_by", "approved_by",
        "pickup_branch", "drop_branch",
    ).prefetch_related("payments", "penalties", "damage_reports")
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = BookingFilter
    search_fields = ["booking_number", "customer__user__first_name",
                     "customer__user__last_name", "vehicle__registration_number"]
    ordering_fields = ["pickup_datetime", "created_at", "total_amount", "status"]
    ordering = ["-created_at"]

    def _locked_booking(self):
        obj = self.get_object()
        return Booking.objects.select_for_update().get(pk=obj.pk)

    def _visible_vehicles(self):
        qs = Vehicle.objects.filter(is_active=True)
        user = self.request.user
        return scope(qs, user) if getattr(user, 'role', '') in ['admin','staff','super_admin'] else qs

    def update(self, request, *args, **kwargs):
        self.get_object()
        return Response({'error': 'Use booking workflow actions; schedule/financial edits are not allowed.'}, status=405)

    def destroy(self, request, *args, **kwargs):
        self.get_object()
        return Response({'error': 'Bookings are retained for audit. Use cancel.'}, status=405)

    def get_serializer_class(self):
        if self.action == "create":
            return BookingCreateSerializer
        elif self.action == "list":
            return BookingListSerializer
        return BookingDetailSerializer

    def get_permissions(self):
        if self.action in ["create"]:
            return [IsAuthenticated()]
        if self.action in ["confirm", "activate", "complete", "update", "partial_update", "inspection"]:
            return [IsAdminOrStaff()]
        if self.action in ["destroy"]:
            return [IsAdminOrStaff()]
        return [IsOwnerOrAdminOrStaff()]

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        # Customers only see their own bookings
        if getattr(user, 'role', '') == "customer":
            qs = qs.filter(customer__user=user)
        # Drivers only see their assigned bookings
        elif getattr(user, 'role', '') == "driver":
            qs = qs.filter(driver__user=user)
        if getattr(user, 'role', '') in ["admin", "staff", "super_admin"]:
            qs = scope(qs, user, "vehicle__branch")
        return qs

    @extend_schema(
        summary="Check vehicle availability",
        request=AvailabilityCheckSerializer,
        tags=["bookings"],
    )
    @action(detail=False, methods=["post"], url_path="check-availability")
    def check_availability(self, request):
        """
        Check if a vehicle is available for a given date range.
        Returns available vehicles if vehicle_id not specified.
        """
        serializer = AvailabilityCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        vehicle_id = serializer.validated_data.get("vehicle_id")
        pickup_dt = serializer.validated_data["pickup_datetime"]
        return_dt = serializer.validated_data["return_datetime"]

        if vehicle_id:
            available = Booking.check_vehicle_availability(vehicle_id, pickup_dt, return_dt)
            vehicle = __import__("django.shortcuts", fromlist=["get_object_or_404"]).get_object_or_404(self._visible_vehicles(), id=vehicle_id)
            return Response({
                "vehicle_id": str(vehicle_id),
                "is_available": available,
                "pickup_datetime": pickup_dt,
                "return_datetime": return_dt,
                "daily_rate": vehicle.get_daily_rate(),
                "message": "Vehicle is available" if available else "Vehicle is not available for the selected dates",
            })

        # Return all available vehicles for the date range
        busy_vehicle_ids = Booking.objects.filter(
            status__in=[Booking.Status.CONFIRMED, Booking.Status.ACTIVE, Booking.Status.PENDING],
        ).filter(
            Q(pickup_datetime__lt=return_dt) & Q(return_datetime__gt=pickup_dt)
        ).values_list("vehicle_id", flat=True)

        available_vehicles = self._visible_vehicles().filter(
            status=Vehicle.Status.AVAILABLE,
            is_active=True,
        ).exclude(id__in=busy_vehicle_ids)

        from apps.vehicles.serializers import VehicleListSerializer
        return Response({
            "available_count": available_vehicles.count(),
            "vehicles": VehicleListSerializer(available_vehicles, many=True).data,
        })

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        """
        Create booking with conflict detection and atomic vehicle lock.
        Uses SELECT FOR UPDATE to prevent double-booking.
        """
        serializer = BookingCreateSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)

        check_relations(request.user, serializer.validated_data)
        vehicle_id = serializer.validated_data["vehicle"].id
        pickup_dt = serializer.validated_data["pickup_datetime"]
        return_dt = serializer.validated_data["return_datetime"]

        # Lock the vehicle row to prevent race conditions
        try:
            vehicle = Vehicle.objects.select_for_update(nowait=True).get(id=vehicle_id)
        except Exception:
            return Response(
                {"error": "Vehicle is currently being booked. Please try again."},
                status=status.HTTP_409_CONFLICT,
            )

        from apps.intelligence.services import eligible_inventory
        if not eligible_inventory({'pickup_datetime': pickup_dt, 'return_datetime': return_dt}).filter(pk=vehicle.pk).exists():
            return Response({'error': 'Vehicle is not available for rental.'}, status=409)

        driver = serializer.validated_data.get('driver')
        if driver:
            from apps.drivers.models import Driver
            from django.db import DatabaseError
            try:
                driver = Driver.objects.select_for_update(nowait=True).get(pk=driver.pk)
            except DatabaseError:
                return Response({'error':'Driver is currently being assigned. Try again.'},status=409)
            if driver.branch_id!=vehicle.branch_id or not Booking.check_driver_availability(driver.pk,pickup_dt,return_dt):
                return Response({'error':'Driver is not available for this branch and time.'},status=409)

        # Double-check availability within the lock
        if not Booking.check_vehicle_availability(vehicle_id, pickup_dt, return_dt):
            return Response(
                {"error": "Vehicle is not available for the selected dates."},
                status=status.HTTP_409_CONFLICT,
            )

        booking = serializer.save(
            created_by=request.user,
            status=Booking.Status.PENDING,
        )
        booking.calculate_total()
        booking.save()

        # Queue confirmation tasks
        transaction.on_commit(lambda: send_booking_confirmation.delay(str(booking.id)))

        logger.info(f"Booking {booking.booking_number} created by {request.user.email}")
        ActivityLog.objects.create(
            user=request.user,
            action=ActivityLog.Action.CREATE,
            model_name="Booking",
            object_id=str(booking.id),
            description=f"Created booking {booking.booking_number}",
            ip_address=request.META.get("REMOTE_ADDR"),
        )

        return Response(
            BookingDetailSerializer(booking).data,
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(summary="Confirm a pending booking", tags=["bookings"])
    @action(detail=True, methods=["post"])
    @transaction.atomic
    def confirm(self, request, pk=None):
        booking = self._locked_booking()
        if booking.status != Booking.Status.PENDING:
            return Response(
                {"error": f"Cannot confirm booking in '{booking.status}' status."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        booking.status = Booking.Status.CONFIRMED
        booking.confirmed_at = timezone.now()
        booking.approved_by = request.user
        booking.save(update_fields=["status", "confirmed_at", "approved_by", "updated_at"])
        return Response({"status": "confirmed", "booking_number": booking.booking_number})

    @extend_schema(summary="Activate booking (vehicle picked up)", tags=["bookings"])
    @action(detail=True, methods=["post"])
    @transaction.atomic
    def activate(self, request, pk=None):
        booking = self._locked_booking()
        if booking.status != Booking.Status.CONFIRMED:
            return Response(
                {"error": f"Cannot activate booking in '{booking.status}' status."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        odometer = request.data.get("odometer_reading")
        fuel_level = request.data.get("fuel_level", 100)

        booking.status = Booking.Status.ACTIVE
        booking.activated_at = timezone.now()
        Vehicle.objects.filter(pk=booking.vehicle_id).update(status=Vehicle.Status.RENTED)
        if odometer:
            booking.odometer_at_pickup = odometer
        booking.fuel_level_at_pickup = fuel_level
        booking.save()

        # Schedule return reminder
        transaction.on_commit(lambda: send_return_reminder.apply_async(
            args=[str(booking.id)],
            eta=max(timezone.now(), booking.return_datetime - timezone.timedelta(hours=24)),
        ))
        return Response({"status": "active", "booking_number": booking.booking_number})

    @extend_schema(summary="Complete booking (vehicle returned)", tags=["bookings"])
    @action(detail=True, methods=["post"])
    @transaction.atomic
    def complete(self, request, pk=None):
        booking = self._locked_booking()
        if booking.status != Booking.Status.ACTIVE:
            return Response(
                {"error": "Only active bookings can be completed."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        odometer = request.data.get("odometer_reading")
        fuel_level = request.data.get("fuel_level")
        actual_return = request.data.get("actual_return_datetime") or timezone.now()

        booking.status = Booking.Status.COMPLETED
        booking.completed_at = timezone.now()
        Vehicle.objects.filter(pk=booking.vehicle_id).update(status=Vehicle.Status.AVAILABLE)
        booking.actual_return_datetime = actual_return
        if odometer:
            booking.odometer_at_return = odometer
            if booking.odometer_at_pickup:
                booking.total_km_driven = odometer - booking.odometer_at_pickup
        if fuel_level is not None:
            booking.fuel_level_at_return = fuel_level
        booking.save()

        return Response({"status": "completed", "booking_number": booking.booking_number})

    @extend_schema(summary="Cancel a booking", tags=["bookings"])
    @action(detail=True, methods=["post"])
    @transaction.atomic
    def cancel(self, request, pk=None):
        booking = self._locked_booking()
        if booking.status not in [Booking.Status.PENDING, Booking.Status.CONFIRMED]:
            return Response(
                {"error": f"Cannot cancel booking in '{booking.status}' status."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        reason = request.data.get("reason", "Customer request")

        # Calculate cancellation fee
        hours_to_pickup = (
            booking.pickup_datetime - timezone.now()
        ).total_seconds() / 3600
        cancel_fee = Decimal("0.00") if hours_to_pickup >= 24 else (booking.total_amount * Decimal("0.1")).quantize(Decimal("0.01"))
        refund_amount = booking.amount_paid - cancel_fee

        booking.status = Booking.Status.CANCELLED
        booking.save(update_fields=["status", "updated_at"])

        cancellation = BookingCancellation.objects.create(
            booking=booking,
            cancelled_by=BookingCancellation.CancelledBy.CUSTOMER
                if getattr(request.user, 'role', '') == "customer"
                else BookingCancellation.CancelledBy.ADMIN,
            cancelled_by_user=request.user,
            reason=reason,
            cancellation_fee=cancel_fee,
            refund_amount=max(Decimal("0.00"), refund_amount),
        )
        from apps.commerce.services import queue_cancellation_refund

        queue_cancellation_refund(booking)
        cancellation.refresh_from_db()
        return Response({
            "status": "cancelled",
            "cancellation_fee": str(cancel_fee),
            "refund_amount": str(cancellation.refund_amount),
        })

    @action(detail=True, methods=["post"])
    @transaction.atomic
    def inspection(self, request, pk=None):
        """Record pre or post rental inspection."""
        booking = self._locked_booking()
        serializer = InspectionSerializer(data={**request.data, "booking": booking.id})
        serializer.is_valid(raise_exception=True)
        inspection = serializer.save(inspected_by=request.user)
        return Response(InspectionSerializer(inspection).data, status=status.HTTP_201_CREATED)


from decimal import Decimal  # ensure import at top in production

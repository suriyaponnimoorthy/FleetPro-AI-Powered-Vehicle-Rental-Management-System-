"""
apps/bookings/tasks.py  &  apps/notifications/tasks.py
Celery async tasks: confirmations, reminders, penalty enforcement,
maintenance alerts, revenue reports.
"""

import logging
from celery import shared_task
from django.utils import timezone
from django.db.models import Q
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string

logger = logging.getLogger("apps.tasks")


# ═══════════════════════════════════════════════════════════════
#  BOOKING TASKS
# ═══════════════════════════════════════════════════════════════

@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_booking_confirmation(self, booking_id: str):
    """
    Send booking confirmation email + SMS to customer.
    Retries up to 3 times with 60s delay on failure.
    """
    try:
        from apps.bookings.models import Booking
        from apps.notifications.services import NotificationService

        booking = Booking.objects.select_related(
            "customer__user", "vehicle", "driver__user"
        ).get(id=booking_id)

        ns = NotificationService()

        # Email
        ns.send_email(
            user=booking.customer.user,
            subject=f"Booking {booking.status.title()} — {booking.booking_number}",
            template="emails/booking_confirmation.html",
            context={
                "booking": booking,
                "vehicle": booking.vehicle,
                "company": settings.FLEETPRO,
            },
        )

        # SMS
        ns.send_sms(
            user=booking.customer.user,
            message=(
                f"FleetPro: Your booking {booking.booking_number} status is {booking.status}. "
                f"Pickup: {booking.pickup_datetime.strftime('%d %b %Y, %I:%M %p')}. "
                f"Vehicle: {booking.vehicle.make} {booking.vehicle.model}."
            ),
        )

        logger.info(f"Booking confirmation sent for {booking.booking_number}")

    except Exception as exc:
        logger.error(f"Failed to send confirmation for booking {booking_id}: {exc}")
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=2)
def send_return_reminder(self, booking_id: str):
    """Send return reminder 24 hours before due return."""
    try:
        from apps.bookings.models import Booking
        from apps.notifications.services import NotificationService

        booking = Booking.objects.select_related("customer__user", "vehicle").get(
            id=booking_id, status=Booking.Status.ACTIVE
        )

        ns = NotificationService()
        ns.send_email(
            user=booking.customer.user,
            subject=f"Return Reminder — {booking.booking_number}",
            template="emails/return_reminder.html",
            context={"booking": booking},
        )
        ns.send_sms(
            user=booking.customer.user,
            message=(
                f"FleetPro Reminder: Your rental {booking.booking_number} is due for return "
                f"tomorrow at {booking.return_datetime.strftime('%I:%M %p')}. "
                f"Late return: ₹100/hr."
            ),
        )

    except Exception as exc:
        logger.warning(f"Return reminder failed for {booking_id}: {exc}")
        raise self.retry(exc=exc)


@shared_task
def process_overdue_bookings():
    """
    Periodic task (every 30 min): find overdue bookings, calculate penalties,
    send alerts. Scheduled via django-celery-beat.
    """
    from apps.bookings.models import Booking
    from apps.payments.models import Penalty
    from apps.notifications.services import NotificationService

    now = timezone.now()
    overdue_bookings = Booking.objects.filter(
        status=Booking.Status.ACTIVE,
        return_datetime__lt=now,
    ).select_related("customer__user", "vehicle")

    ns = NotificationService()
    processed = 0

    for booking in overdue_bookings:
        overdue_hours = int((now - booking.return_datetime).total_seconds() / 3600)
        if overdue_hours < 1:
            continue

        late_fee = overdue_hours * 100  # ₹100/hour

        # Create/update penalty record (upsert)
        penalty, created = Penalty.objects.update_or_create(
            booking=booking,
            penalty_type=Penalty.PenaltyType.LATE_RETURN,
            status=Penalty.Status.PENDING,
            defaults={
                "customer": booking.customer,
                "amount": late_fee,
                "description": f"Late return: {overdue_hours} hour(s) overdue. ₹100/hr",
            },
        )

        # Alert every 2 hours
        if overdue_hours % 2 == 0:
            ns.send_sms(
                user=booking.customer.user,
                message=(
                    f"OVERDUE: Booking {booking.booking_number} is {overdue_hours}h overdue. "
                    f"Current fine: ₹{late_fee}. Please return the vehicle ASAP."
                ),
            )

        processed += 1

    logger.info(f"Processed {processed} overdue bookings")
    return f"Processed {processed} overdue bookings"


@shared_task
def auto_complete_bookings():
    """
    Auto-complete bookings that are 48h past return date (system cleanup).
    Runs daily.
    """
    from apps.bookings.models import Booking

    cutoff = timezone.now() - timezone.timedelta(hours=48)
    stale = Booking.objects.filter(
        status=Booking.Status.ACTIVE,
        return_datetime__lt=cutoff,
    )
    count = stale.update(
        status=Booking.Status.COMPLETED,
        completed_at=timezone.now(),
        internal_notes="Auto-completed by system after 48h overdue.",
    )
    logger.info(f"Auto-completed {count} stale bookings")
    return count


# ═══════════════════════════════════════════════════════════════
#  VEHICLE / MAINTENANCE TASKS
# ═══════════════════════════════════════════════════════════════

@shared_task
def send_maintenance_alerts():
    """
    Daily task: alert admins about vehicles due for service within 7 days
    or documents expiring within 30 days.
    """
    from apps.vehicles.models import Vehicle, MaintenanceSchedule, VehicleInsurance
    from apps.notifications.services import NotificationService
    from apps.authentication.models import User

    ns = NotificationService()
    today = timezone.now().date()
    alert_7_days = today + timezone.timedelta(days=7)
    alert_30_days = today + timezone.timedelta(days=30)

    # Maintenance due soon
    due_maintenance = MaintenanceSchedule.objects.filter(
        status=MaintenanceSchedule.Status.SCHEDULED,
        scheduled_date__lte=alert_7_days,
    ).select_related("vehicle")

    # Insurance expiring soon
    expiring_insurance = VehicleInsurance.objects.filter(
        is_active=True,
        end_date__lte=alert_30_days,
    ).select_related("vehicle")

    # Documents expiring (pollution, fitness, permit)
    doc_expiring = Vehicle.objects.filter(
        is_active=True,
    ).filter(
        Q(pollution_expiry_date__lte=alert_30_days) |
        Q(fitness_expiry_date__lte=alert_30_days) |
        Q(permit_expiry_date__lte=alert_30_days)
    )

    # Notify all admin users
    admins = User.objects.filter(role__in=["admin", "super_admin"], is_active=True)

    for admin in admins:
        ns.create_in_app_notification(
            user=admin,
            notification_type="maintenance_alert",
            title="Vehicle Maintenance Alerts",
            body=(
                f"{due_maintenance.count()} vehicles due for service | "
                f"{expiring_insurance.count()} insurance expiring | "
                f"{doc_expiring.count()} documents expiring"
            ),
            metadata={
                "maintenance_count": due_maintenance.count(),
                "insurance_count": expiring_insurance.count(),
                "docs_count": doc_expiring.count(),
            },
        )


# ═══════════════════════════════════════════════════════════════
#  PAYMENT TASKS
# ═══════════════════════════════════════════════════════════════

@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def send_payment_receipt(self, payment_id: str):
    """Send payment receipt email after successful transaction."""
    try:
        from apps.payments.models import Payment
        from apps.notifications.services import NotificationService

        payment = Payment.objects.select_related(
            "booking__vehicle", "customer__user"
        ).get(id=payment_id)

        ns = NotificationService()
        ns.send_email(
            user=payment.customer.user,
            subject=f"Payment Receipt — {payment.transaction_id}",
            template="emails/payment_receipt.html",
            context={"payment": payment, "booking": payment.booking},
        )

    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def generate_daily_revenue_report():
    """
    Daily task: compile revenue report and email to super admins.
    Runs at 11:59 PM via django-celery-beat.
    """
    from apps.payments.models import Payment
    from apps.authentication.models import User
    from django.db.models import Sum, Count
    from django.utils import timezone

    today = timezone.now().date()
    today_payments = Payment.objects.filter(
        status=Payment.Status.SUCCESS,
        paid_at__date=today,
    ).aggregate(
        total_revenue=Sum("amount"),
        transaction_count=Count("id"),
    )

    super_admins = User.objects.filter(role="super_admin", is_active=True)
    from apps.notifications.services import NotificationService
    ns = NotificationService()

    for admin in super_admins:
        ns.send_email(
            user=admin,
            subject=f"Daily Revenue Report — {today.strftime('%d %b %Y')}",
            template="emails/daily_revenue_report.html",
            context={
                "date": today,
                "total_revenue": today_payments.get("total_revenue") or 0,
                "transaction_count": today_payments.get("transaction_count") or 0,
            },
        )


# ═══════════════════════════════════════════════════════════════
#  CELERY BEAT SCHEDULE (add to settings.py)
# ═══════════════════════════════════════════════════════════════
# from celery.schedules import crontab
# CELERY_BEAT_SCHEDULE = {
#     "process-overdue-bookings": {
#         "task": "apps.bookings.tasks.process_overdue_bookings",
#         "schedule": crontab(minute="*/30"),  # Every 30 minutes
#     },
#     "auto-complete-bookings": {
#         "task": "apps.bookings.tasks.auto_complete_bookings",
#         "schedule": crontab(hour=2, minute=0),  # Daily at 2 AM
#     },
#     "send-maintenance-alerts": {
#         "task": "apps.bookings.tasks.send_maintenance_alerts",
#         "schedule": crontab(hour=8, minute=0),  # Daily at 8 AM
#     },
#     "daily-revenue-report": {
#         "task": "apps.payments.tasks.generate_daily_revenue_report",
#         "schedule": crontab(hour=23, minute=59),  # Daily at 11:59 PM
#     },
# }

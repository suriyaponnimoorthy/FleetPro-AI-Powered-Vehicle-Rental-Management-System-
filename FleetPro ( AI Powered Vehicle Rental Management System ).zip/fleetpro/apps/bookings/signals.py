"""Booking notifications are queued by BookingViewSet after transaction commit."""

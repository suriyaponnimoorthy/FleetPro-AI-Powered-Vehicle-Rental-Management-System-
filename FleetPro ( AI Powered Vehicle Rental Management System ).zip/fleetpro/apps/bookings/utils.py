import math
# apps/bookings/utils.py
import random
import string
from decimal import Decimal
from django.utils import timezone


def generate_booking_number() -> str:
    """
    Unique booking number: BK-YYYYMM-XXXXX
    Example: BK-202505-A3K9P
    """
    now      = timezone.now()
    prefix   = f"BK-{now.year}{now.month:02d}"
    suffix   = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    candidate = f"{prefix}-{suffix}"

    from apps.bookings.models import Booking
    if Booking.objects.filter(booking_number=candidate).exists():
        return generate_booking_number()
    return candidate


def calculate_rental_cost(vehicle, pickup_datetime, return_datetime,
                           with_driver=False, driver=None, discount_amount=0):
    """Full cost breakdown for a rental."""
    from django.conf import settings

    delta       = return_datetime - pickup_datetime
    days        = delta.days
    hours       = delta.seconds // 3600
    rental_days = max(1, math.ceil(delta.total_seconds() / 86400))

    daily_rate     = vehicle.get_daily_rate()
    base_amount    = daily_rate * rental_days
    driver_charges = Decimal("0")

    if with_driver and driver:
        driver_charges = driver.daily_rate * rental_days

    subtotal   = base_amount + driver_charges - Decimal(str(discount_amount))
    gst_rate   = Decimal(str(settings.FLEETPRO.get("GST_RATE", 0.18)))
    gst_amount = (subtotal * gst_rate).quantize(Decimal("0.01"))
    deposit    = vehicle.get_security_deposit()
    total      = (subtotal + gst_amount + deposit).quantize(Decimal("0.01"))

    return {
        "rental_days":      rental_days,
        "daily_rate":       str(daily_rate),
        "base_amount":      str(base_amount),
        "driver_charges":   str(driver_charges),
        "discount_amount":  str(discount_amount),
        "gst_rate":         f"{gst_rate * 100:.0f}%",
        "gst_amount":       str(gst_amount),
        "security_deposit": str(deposit),
        "total_amount":     str(total),
        "line_items": [
            {"description": f"Vehicle rental — {rental_days} day(s) × ₹{daily_rate}", "amount": str(base_amount)},
            *([ {"description": f"Driver — {rental_days} day(s) × ₹{driver.daily_rate}", "amount": str(driver_charges)} ] if driver_charges else []),
            *([ {"description": "Discount", "amount": f"-{discount_amount}"} ] if discount_amount else []),
            {"description": "GST (18%)",                       "amount": str(gst_amount)},
            {"description": "Refundable security deposit",     "amount": str(deposit)},
        ],
    }

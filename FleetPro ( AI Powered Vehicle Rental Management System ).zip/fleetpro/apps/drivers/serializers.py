"""
apps/drivers/serializers.py   — Driver serializers
apps/customers/serializers.py — Customer serializers
"""

from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from apps.vehicles.models import Branch
from apps.drivers.models import Driver, DriverAttendance
from apps.customers.models import CustomerProfile


# ══════════════════════════════════════════════════════════════
# DRIVER SERIALIZERS
# ══════════════════════════════════════════════════════════════

class DriverListSerializer(serializers.ModelSerializer):
    full_name          = serializers.CharField(source="user.get_full_name", read_only=True)
    email              = serializers.EmailField(source="user.email", read_only=True)
    phone              = serializers.CharField(source="user.phone", read_only=True)
    branch_name        = serializers.CharField(source="branch.name", read_only=True)
    branch_city        = serializers.CharField(source="branch.city", read_only=True)
    is_license_valid   = serializers.BooleanField(read_only=True)

    class Meta:
        model  = Driver
        fields = [
            "id", "full_name", "email", "phone",
            "employee_id", "availability_status",
            "branch_name", "branch_city",
            "experience_years", "average_rating", "total_trips",
            "daily_rate", "is_license_valid",
        ]


class DriverDetailSerializer(serializers.ModelSerializer):
    full_name          = serializers.CharField(source="user.get_full_name", read_only=True)
    email              = serializers.EmailField(source="user.email", read_only=True)
    phone              = serializers.CharField(source="user.phone", read_only=True)
    profile_photo      = serializers.ImageField(source="user.profile_photo", read_only=True)
    branch_name        = serializers.CharField(source="branch.name", read_only=True)
    is_license_valid   = serializers.BooleanField(read_only=True)
    active_booking     = serializers.SerializerMethodField()

    class Meta:
        model  = Driver
        fields = [
            "id", "user", "full_name", "email", "phone", "profile_photo",
            "branch", "branch_name", "employee_id",
            "date_of_birth", "address", "city",
            "dl_number", "dl_expiry_date", "dl_categories",
            "experience_years", "availability_status",
            "daily_rate", "monthly_salary", "joining_date",
            "total_trips", "average_rating", "total_violations",
            "is_license_valid", "active_booking",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "user", "total_trips", "average_rating", "created_at", "updated_at"]

    def get_active_booking(self, obj) -> dict | None:
        from apps.bookings.models import Booking
        bk = obj.bookings.filter(status=Booking.Status.ACTIVE).select_related("vehicle", "customer__user").first()
        if not bk:
            return None
        return {
            "booking_number": bk.booking_number,
            "vehicle":        bk.vehicle.display_name,
            "customer":       bk.customer.user.get_full_name(),
            "return_datetime": bk.return_datetime,
        }


class DriverSelfUpdateSerializer(DriverDetailSerializer):
    class Meta(DriverDetailSerializer.Meta):
        read_only_fields = [field for field in DriverDetailSerializer.Meta.fields if field not in {
            "address", "city", "availability_status",
        }]

    def to_internal_value(self, data):
        forbidden = set(data) - {"address", "city", "availability_status"}
        if forbidden:
            raise serializers.ValidationError({field: "This field cannot be changed." for field in forbidden})
        return super().to_internal_value(data)


class DriverCreateSerializer(serializers.Serializer):
    """Create user + driver profile atomically."""
    email            = serializers.EmailField()
    first_name       = serializers.CharField(max_length=100)
    last_name        = serializers.CharField(max_length=100)
    phone            = serializers.CharField(max_length=20)
    password         = serializers.CharField(write_only=True, trim_whitespace=False, validators=[validate_password])
    branch           = serializers.PrimaryKeyRelatedField(queryset=Branch.objects.all())
    employee_id      = serializers.CharField(max_length=20)
    dl_number        = serializers.CharField(max_length=50)
    dl_expiry_date   = serializers.DateField()
    dl_categories    = serializers.ListField(child=serializers.CharField(), default=["LMV"])
    experience_years = serializers.IntegerField(default=0)
    monthly_salary   = serializers.DecimalField(max_digits=12, decimal_places=2, default=20000)
    daily_rate       = serializers.DecimalField(max_digits=10, decimal_places=2, default=500)

    def validate_email(self, value):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        return value.lower()

    def validate_employee_id(self, value):
        if Driver.objects.filter(employee_id=value).exists():
            raise serializers.ValidationError("Employee ID already in use.")
        return value

    def to_representation(self, instance):
        return DriverDetailSerializer(instance, context=self.context).data

    @transaction.atomic
    def create(self, validated_data):
        from django.contrib.auth import get_user_model
        User = get_user_model()

        branch = validated_data.pop("branch")
        password = validated_data.pop("password")
        driver_fields = {
            "employee_id":      validated_data.pop("employee_id"),
            "dl_number":        validated_data.pop("dl_number"),
            "dl_expiry_date":   validated_data.pop("dl_expiry_date"),
            "dl_categories":    validated_data.pop("dl_categories"),
            "experience_years": validated_data.pop("experience_years"),
            "monthly_salary":   validated_data.pop("monthly_salary"),
            "daily_rate":       validated_data.pop("daily_rate"),
        }

        user = User.objects.create_user(
            role=User.Role.DRIVER,
            branch=branch,
            password=password,
            **validated_data
        )

        driver = Driver.objects.create(user=user, branch=branch, **driver_fields)
        return driver


class DriverAttendanceSerializer(serializers.ModelSerializer):
    driver_name  = serializers.CharField(source="driver.user.get_full_name", read_only=True)
    hours_worked = serializers.FloatField(read_only=True)

    class Meta:
        model  = DriverAttendance
        fields = [
            "id", "driver", "driver_name", "date",
            "check_in", "check_out", "status",
            "hours_worked", "notes", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


# ══════════════════════════════════════════════════════════════
# CUSTOMER SERIALIZERS
# ══════════════════════════════════════════════════════════════

class CustomerListSerializer(serializers.ModelSerializer):
    full_name   = serializers.CharField(source="user.get_full_name", read_only=True)
    email       = serializers.EmailField(source="user.email", read_only=True)
    phone       = serializers.CharField(source="user.phone", read_only=True)
    tier        = serializers.CharField(read_only=True)

    class Meta:
        model  = CustomerProfile
        fields = [
            "id", "full_name", "email", "phone",
            "city", "kyc_status", "is_blacklisted",
            "total_bookings", "total_spend",
            "loyalty_points", "tier", "created_at",
        ]


class CustomerDetailSerializer(serializers.ModelSerializer):
    full_name          = serializers.CharField(source="user.get_full_name", read_only=True)
    email              = serializers.EmailField(source="user.email", read_only=True)
    phone              = serializers.CharField(source="user.phone", read_only=True)
    profile_photo      = serializers.ImageField(source="user.profile_photo", read_only=True)
    is_email_verified  = serializers.BooleanField(source="user.is_email_verified", read_only=True)
    is_phone_verified  = serializers.BooleanField(source="user.is_phone_verified", read_only=True)
    kyc_verified_by_name = serializers.SerializerMethodField()
    aadhar_number = serializers.CharField(max_length=20, write_only=True, required=False, allow_blank=True)
    pan_number = serializers.CharField(max_length=10, write_only=True, required=False, allow_blank=True)
    dl_number = serializers.CharField(max_length=50, write_only=True, required=False, allow_blank=True)
    tier               = serializers.CharField(read_only=True)
    is_dl_valid        = serializers.BooleanField(read_only=True)

    class Meta:
        model  = CustomerProfile
        fields = [
            "id", "user",
            "full_name", "email", "phone", "profile_photo",
            "is_email_verified", "is_phone_verified",
            "date_of_birth", "gender", "address", "city", "state", "pincode",
            "emergency_contact_name", "emergency_contact_phone",
            "dl_number", "dl_expiry_date", "is_dl_valid",
            "aadhar_number", "pan_number",
            "kyc_status", "kyc_verified_at", "kyc_verified_by_name",
            "kyc_rejection_reason",
            "total_bookings", "total_spend", "loyalty_points", "tier",
            "is_blacklisted", "blacklist_reason",
            "preferred_vehicle_type", "notes",
            "created_at", "updated_at",
        ]
        read_only_fields = [
            "id", "user", "total_bookings", "total_spend", "loyalty_points",
            "kyc_status", "kyc_verified_at", "kyc_rejection_reason", "is_blacklisted", "created_at", "updated_at",
        ]

    def get_kyc_verified_by_name(self, obj) -> str | None:
        if obj.kyc_verified_by:
            return obj.kyc_verified_by.get_full_name()
        return None

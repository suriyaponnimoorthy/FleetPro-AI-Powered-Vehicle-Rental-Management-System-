# apps/drivers/filters.py
import django_filters
from apps.drivers.models import Driver, DriverAttendance


class DriverFilter(django_filters.FilterSet):
    availability_status = django_filters.MultipleChoiceFilter(choices=Driver.AvailabilityStatus.choices)
    branch              = django_filters.UUIDFilter(field_name="branch__id")
    city                = django_filters.CharFilter(field_name="branch__city", lookup_expr="iexact")
    rating_min          = django_filters.NumberFilter(field_name="average_rating", lookup_expr="gte")
    experience_min      = django_filters.NumberFilter(field_name="experience_years", lookup_expr="gte")

    class Meta:
        model  = Driver
        fields = ["availability_status", "branch"]


class DriverAttendanceFilter(django_filters.FilterSet):
    date_from = django_filters.DateFilter(field_name="date", lookup_expr="gte")
    date_to   = django_filters.DateFilter(field_name="date", lookup_expr="lte")
    status    = django_filters.MultipleChoiceFilter(choices=DriverAttendance.AttendanceStatus.choices)

    class Meta:
        model  = DriverAttendance
        fields = ["driver", "status"]

from apps.core.private_files import private_storage, validate_private_file
# apps/drivers/models.py
# Driver and DriverAttendance models — full source
import uuid
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Driver(models.Model):
    class AvailabilityStatus(models.TextChoices):
        AVAILABLE = "available", "Available"
        ON_DUTY   = "on_duty",   "On Duty"
        ON_LEAVE  = "on_leave",  "On Leave"
        INACTIVE  = "inactive",  "Inactive"

    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user                = models.OneToOneField("authentication.User", on_delete=models.CASCADE, related_name="driver_profile")
    branch              = models.ForeignKey("vehicles.Branch", on_delete=models.SET_NULL, null=True, related_name="drivers")
    employee_id         = models.CharField(max_length=20, unique=True)
    date_of_birth       = models.DateField(null=True, blank=True)
    address             = models.TextField(blank=True)
    city                = models.CharField(max_length=100, blank=True)
    dl_number           = models.CharField(max_length=50, unique=True)
    dl_expiry_date      = models.DateField()
    dl_categories       = models.JSONField(default=list)
    dl_document         = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="drivers/licenses/", blank=True)
    aadhar_number       = models.CharField(max_length=20, blank=True)
    aadhar_document     = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="drivers/aadhar/", blank=True)
    police_verification = models.FileField(storage=private_storage, validators=[validate_private_file], upload_to="drivers/police/", blank=True)
    experience_years    = models.PositiveSmallIntegerField(default=0)
    availability_status = models.CharField(max_length=20, choices=AvailabilityStatus.choices, default=AvailabilityStatus.AVAILABLE, db_index=True)
    daily_rate          = models.DecimalField(max_digits=10, decimal_places=2, default=500)
    monthly_salary      = models.DecimalField(max_digits=12, decimal_places=2, default=20000)
    joining_date        = models.DateField(auto_now_add=True)
    total_trips         = models.PositiveIntegerField(default=0)
    average_rating      = models.DecimalField(max_digits=3, decimal_places=2, default=0.00)
    total_violations    = models.PositiveSmallIntegerField(default=0)
    created_at          = models.DateTimeField(auto_now_add=True)
    updated_at          = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "driver_profiles"
        indexes  = [
            models.Index(fields=["branch", "availability_status"]),
            models.Index(fields=["dl_number"]),
        ]
        ordering = ["user__first_name"]

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.employee_id})"

    @property
    def is_license_valid(self):
        from django.utils import timezone
        return self.dl_expiry_date >= timezone.now().date()


class DriverAttendance(models.Model):
    class AttendanceStatus(models.TextChoices):
        PRESENT  = "present",  "Present"
        ABSENT   = "absent",   "Absent"
        HALF_DAY = "half_day", "Half Day"
        LEAVE    = "leave",    "On Leave"
        HOLIDAY  = "holiday",  "Holiday"

    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    driver     = models.ForeignKey(Driver, on_delete=models.CASCADE, related_name="attendance")
    date       = models.DateField(db_index=True)
    check_in   = models.DateTimeField(null=True, blank=True)
    check_out  = models.DateTimeField(null=True, blank=True)
    status     = models.CharField(max_length=20, choices=AttendanceStatus.choices, default=AttendanceStatus.PRESENT)
    notes      = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "driver_attendance"
        unique_together = [("driver", "date")]
        ordering = ["-date"]

    @property
    def hours_worked(self):
        if self.check_in and self.check_out:
            delta = self.check_out - self.check_in
            return round(delta.total_seconds() / 3600, 2)
        return 0

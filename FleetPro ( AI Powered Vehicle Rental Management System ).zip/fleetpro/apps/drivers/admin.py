# apps/drivers/admin.py
from django.contrib import admin
from apps.drivers.models import Driver, DriverAttendance


@admin.register(Driver)
class DriverAdmin(admin.ModelAdmin):
    list_display  = ("user", "employee_id", "branch", "availability_status",
                     "experience_years", "average_rating", "total_trips")
    list_filter   = ("availability_status", "branch")
    search_fields = ("user__email", "employee_id", "dl_number")
    readonly_fields = ("total_trips", "average_rating", "created_at", "updated_at")


@admin.register(DriverAttendance)
class DriverAttendanceAdmin(admin.ModelAdmin):
    list_display  = ("driver", "date", "status", "check_in", "check_out")
    list_filter   = ("status",)
    date_hierarchy = "date"

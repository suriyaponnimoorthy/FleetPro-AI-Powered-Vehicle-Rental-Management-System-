# apps/drivers/apps.py
from django.apps import AppConfig

class DriversConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.drivers"
    verbose_name = "Driver Management"

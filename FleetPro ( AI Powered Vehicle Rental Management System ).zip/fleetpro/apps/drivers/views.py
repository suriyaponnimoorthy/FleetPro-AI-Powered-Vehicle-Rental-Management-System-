from apps.core.access import scope, check_relations, BranchWriteMixin
"""
apps/drivers/views.py  — Driver management viewset
apps/customers/views.py — Customer management viewset
"""

import logging
from django.db import transaction
from django.db.models import Q, Count, Avg
from django.utils import timezone
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import BasePermission, IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from apps.authentication.permissions import IsAdminOrStaff, IsOwnerOrAdminOrStaff

logger = logging.getLogger("apps.drivers")


# ═══════════════════════════════════════════════════════════════
#  DRIVER VIEWS
# ═══════════════════════════════════════════════════════════════

class IsDriverOrEmployee(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in {"driver", "staff", "admin", "super_admin"}


class DriverViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    """
    Driver profile management.

    GET  /api/v1/drivers/              — list all drivers
    POST /api/v1/drivers/              — create driver profile
    GET  /api/v1/drivers/{id}/         — driver detail
    PATCH /api/v1/drivers/{id}/        — update profile
    GET  /api/v1/drivers/available/    — available drivers for a time slot
    POST /api/v1/drivers/{id}/toggle-availability/ — change status
    GET  /api/v1/drivers/{id}/bookings/ — driver booking history
    """
    from apps.drivers.models import Driver
    filter_backends  = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["availability_status", "branch"]
    search_fields    = ["user__first_name", "user__last_name", "user__email",
                        "employee_id", "dl_number"]
    ordering_fields  = ["average_rating", "total_trips", "experience_years", "monthly_salary"]
    ordering         = ["-average_rating"]

    def get_queryset(self):
        from apps.drivers.models import Driver
        qs = Driver.objects.select_related("user", "branch")
        # Drivers can only see their own profile
        if getattr(self.request.user, 'role', '') == "driver":
            qs = qs.filter(user=self.request.user)
        return scope(qs, self.request.user) if getattr(self.request.user, 'role', '') in ["admin","staff","super_admin"] else qs

    def get_serializer_class(self):
        from apps.drivers.serializers import (
            DriverListSerializer, DriverDetailSerializer, DriverCreateSerializer, DriverSelfUpdateSerializer
        )
        if self.action == "list":
            return DriverListSerializer
        if self.action == "create":
            return DriverCreateSerializer
        if getattr(self.request.user, "role", None) == "driver":
            return DriverSelfUpdateSerializer
        return DriverDetailSerializer

    def get_permissions(self):
        if self.action in ["list", "retrieve", "available"]:
            return [IsAdminOrStaff()]
        if self.action in ["update", "partial_update"]:
            return [IsDriverOrEmployee(), IsOwnerOrAdminOrStaff()]
        return [IsAdminOrStaff()]

    @action(detail=False, methods=["get"])
    def available(self, request):
        """Return drivers available for a given time slot."""
        from apps.drivers.models import Driver
        from apps.bookings.models import Booking

        pickup  = request.query_params.get("pickup_datetime")
        return_ = request.query_params.get("return_datetime")

        if not pickup or not return_:
            return Response(
                {"error": "pickup_datetime and return_datetime are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        from django.utils.dateparse import parse_datetime
        pickup_dt  = parse_datetime(pickup)
        return_dt  = parse_datetime(return_)

        busy_driver_ids = Booking.objects.filter(
            status__in=[Booking.Status.CONFIRMED, Booking.Status.ACTIVE],
        ).filter(
            Q(pickup_datetime__lt=return_dt) & Q(return_datetime__gt=pickup_dt)
        ).values_list("driver_id", flat=True)

        available_drivers = self.get_queryset().filter(
            availability_status=Driver.AvailabilityStatus.AVAILABLE,
            user__is_active=True,
        ).exclude(id__in=busy_driver_ids).select_related("user", "branch")

        from apps.drivers.serializers import DriverListSerializer
        return Response({
            "count": available_drivers.count(),
            "drivers": DriverListSerializer(available_drivers, many=True).data,
        })

    @action(detail=True, methods=["post"], url_path="toggle-availability")
    def toggle_availability(self, request, pk=None):
        from apps.drivers.models import Driver
        driver = self.get_object()
        new_status = request.data.get("status")
        valid = [s.value for s in Driver.AvailabilityStatus]
        if new_status not in valid:
            return Response(
                {"error": f"Invalid status. Choose from: {valid}"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        driver.availability_status = new_status
        driver.save(update_fields=["availability_status", "updated_at"])
        return Response({"message": f"Driver status updated to '{new_status}'."})

    @action(detail=True, methods=["get"])
    def bookings(self, request, pk=None):
        driver = self.get_object()
        from apps.bookings.models import Booking
        from apps.bookings.serializers import BookingListSerializer
        bookings = Booking.objects.filter(driver=driver).order_by("-created_at")[:50]
        return Response(BookingListSerializer(bookings, many=True).data)

    @action(detail=True, methods=["get"])
    def performance(self, request, pk=None):
        driver = self.get_object()
        from apps.bookings.models import Booking
        from django.db.models import Sum, Coalesce
        from decimal import Decimal

        month_start = timezone.now().date().replace(day=1)
        stats = Booking.objects.filter(driver=driver).aggregate(
            total_trips          = Count("id", filter=Q(status="completed")),
            trips_this_month     = Count("id", filter=Q(status="completed", completed_at__date__gte=month_start)),
            avg_rating_from_bookings = Avg("review__driver_rating", filter=Q(review__is_published=True)),
            earnings_this_month  = Coalesce(
                Sum("driver_charges", filter=Q(status="completed", completed_at__date__gte=month_start)),
                Decimal("0")
            ),
        )
        return Response({
            "driver_id": str(driver.id),
            "employee_id": driver.employee_id,
            "overall_rating": str(driver.average_rating),
            "total_trips": driver.total_trips,
            "total_violations": driver.total_violations,
            **stats,
        })


class DriverAttendanceViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    """Driver attendance tracking."""
    filter_backends  = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["driver", "status", "date"]
    ordering         = ["-date"]
    permission_classes = [IsAdminOrStaff]

    def get_queryset(self):
        from apps.drivers.models import DriverAttendance
        return scope(DriverAttendance.objects.select_related("driver__user"), self.request.user, "driver__branch")

    def get_serializer_class(self):
        from apps.drivers.serializers import DriverAttendanceSerializer
        return DriverAttendanceSerializer


# ═══════════════════════════════════════════════════════════════
#  CUSTOMER VIEWS
# ═══════════════════════════════════════════════════════════════

class CustomerViewSet(BranchWriteMixin, viewsets.ModelViewSet):
    """
    Customer profile management.

    GET  /api/v1/customers/             — list customers (admin)
    GET  /api/v1/customers/{id}/        — customer detail
    PATCH /api/v1/customers/{id}/       — update profile
    POST /api/v1/customers/{id}/verify-kyc/ — approve KYC (admin)
    POST /api/v1/customers/{id}/reject-kyc/ — reject KYC (admin)
    POST /api/v1/customers/{id}/blacklist/  — blacklist customer (admin)
    GET  /api/v1/customers/{id}/bookings/   — booking history
    """
    filter_backends  = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["kyc_status", "is_blacklisted", "city"]
    search_fields    = ["user__email", "user__first_name", "user__last_name",
                        "user__phone"]
    ordering_fields  = ["created_at", "total_spend", "total_bookings"]
    ordering         = ["-created_at"]

    def get_queryset(self):
        from apps.customers.models import CustomerProfile
        qs = CustomerProfile.objects.select_related("user", "kyc_verified_by")
        if getattr(self.request.user, 'role', '') == "customer":
            qs = qs.filter(user=self.request.user)
        return scope(qs, self.request.user, "user__branch") if getattr(self.request.user, 'role', '') in ["admin","staff","super_admin"] else qs

    def get_serializer_class(self):
        from apps.customers.serializers import (
            CustomerListSerializer, CustomerDetailSerializer
        )
        if self.action == "list":
            return CustomerListSerializer
        return CustomerDetailSerializer

    def get_permissions(self):
        if self.action in ["list", "verify_kyc", "reject_kyc", "blacklist", "unblacklist", "create", "update", "partial_update", "destroy"]:
            return [IsAdminOrStaff()]
        return [IsOwnerOrAdminOrStaff()]

    @action(detail=True, methods=["post"], url_path="verify-kyc")
    @transaction.atomic
    def verify_kyc(self, request, pk=None):
        customer = self.get_queryset().select_for_update(of=("self",)).get(pk=self.get_object().pk)
        if customer.kyc_status == "verified":
            return Response({"error": "KYC already verified."}, status=400)
        customer.kyc_status      = "verified"
        customer.kyc_verified_at = timezone.now()
        customer.kyc_verified_by = request.user
        customer.save(update_fields=["kyc_status", "kyc_verified_at", "kyc_verified_by", "updated_at"])

        # Update user's KYC flag
        customer.user.is_kyc_verified = True
        customer.user.save(update_fields=["is_kyc_verified"])

        # Notify customer
        from apps.notifications.services import NotificationService
        transaction.on_commit(lambda: NotificationService().send_sms(
            customer.user,
            "FleetPro: Your KYC has been verified! You can now book vehicles."
        ), robust=True)
        return Response({"message": "KYC verified successfully.", "customer": str(customer.user.email)})

    @action(detail=True, methods=["post"], url_path="reject-kyc")
    @transaction.atomic
    def reject_kyc(self, request, pk=None):
        customer = self.get_queryset().select_for_update(of=("self",)).get(pk=self.get_object().pk)
        reason = request.data.get("reason", "Documents insufficient or unclear.")
        customer.kyc_status = "rejected"
        customer.kyc_rejection_reason = reason
        customer.kyc_verified_at = None
        customer.kyc_verified_by = None
        customer.save(update_fields=["kyc_status", "kyc_rejection_reason", "kyc_verified_at", "kyc_verified_by", "updated_at"])
        customer.user.is_kyc_verified = False
        customer.user.save(update_fields=["is_kyc_verified"])
        return Response({"message": "KYC rejected.", "reason": reason})

    @action(detail=True, methods=["post"])
    def blacklist(self, request, pk=None):
        customer = self.get_object()
        reason = request.data.get("reason", "")
        if not reason:
            return Response({"error": "Blacklist reason is required."}, status=400)
        customer.is_blacklisted  = True
        customer.blacklist_reason = reason
        customer.blacklisted_by  = request.user
        customer.blacklisted_at  = timezone.now()
        customer.save(update_fields=[
            "is_blacklisted", "blacklist_reason", "blacklisted_by", "blacklisted_at", "updated_at"
        ])
        return Response({"message": f"Customer {customer.user.email} blacklisted."})

    @action(detail=True, methods=["post"])
    def unblacklist(self, request, pk=None):
        customer = self.get_object()
        customer.is_blacklisted  = False
        customer.blacklist_reason = ""
        customer.save(update_fields=["is_blacklisted", "blacklist_reason", "updated_at"])
        return Response({"message": "Customer removed from blacklist."})

    @action(detail=True, methods=["get"])
    def bookings(self, request, pk=None):
        customer = self.get_object()
        from apps.bookings.models import Booking
        from apps.bookings.serializers import BookingListSerializer
        bookings = Booking.objects.filter(customer=customer).order_by("-created_at")[:50]
        return Response(BookingListSerializer(bookings, many=True).data)

    @action(detail=True, methods=["get"])
    def stats(self, request, pk=None):
        customer = self.get_object()
        from apps.bookings.models import Booking
        from django.db.models import Sum, Avg, Count
        stats = Booking.objects.filter(customer=customer).aggregate(
            total    = Count("id"),
            completed = Count("id", filter=Q(status="completed")),
            cancelled = Count("id", filter=Q(status="cancelled")),
            total_spend = Sum("total_amount", filter=Q(status="completed")),
            avg_value = Avg("total_amount", filter=Q(status="completed")),
        )
        return Response({
            "tier": customer.tier,
            "loyalty_points": customer.loyalty_points,
            **stats,
        })

# apps/damage/admin.py
# Admin registrations live in apps/payments/admin.py

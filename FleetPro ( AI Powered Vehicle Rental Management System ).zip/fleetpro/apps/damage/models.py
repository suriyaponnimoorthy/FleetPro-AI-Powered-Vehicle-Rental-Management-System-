# apps/damage/models.py
# DamageReport and Penalty models live in apps/payments/models.py
# This module re-exports them for convenience
from apps.payments.models import DamageReport, Penalty  # noqa
__all__ = ["DamageReport", "Penalty"]

"""
apps/damage/views.py  — re-export from payments/views.py
apps/damage/models.py — DamageReport and Penalty live in payments/models.py
"""
from apps.payments.views import DamageReportViewSet, PenaltyViewSet  # noqa

__all__ = ["DamageReportViewSet", "PenaltyViewSet"]

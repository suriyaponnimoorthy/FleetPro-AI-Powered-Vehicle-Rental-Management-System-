import json,hashlib,hmac,uuid
from datetime import timedelta
from decimal import Decimal
from unittest.mock import patch
import pytest
from django.core.cache import cache
from django.utils import timezone
from django.db import transaction
from rest_framework.test import APIClient
from rest_framework.exceptions import ValidationError
from apps.authentication.models import User
from apps.vehicles.models import Branch,VehicleCategory,Vehicle
from apps.bookings.models import Booking
from apps.commerce.models import CheckoutOrder,RefundRequest,LedgerEntry,GatewayEvent
from apps.commerce.services import new_order,new_refund,ingest,reconcile_order
from apps.commerce.gateway import GatewayUnavailable

pytestmark=pytest.mark.django_db
@pytest.fixture
def commerce(settings):
    cache.clear();settings.RAZORPAY_KEY_ID='rzp_test_fixture';settings.RAZORPAY_KEY_SECRET='fixture-secret';settings.RAZORPAY_WEBHOOK_SECRET='fixture-webhook'
    branch=Branch.objects.create(name='One',code='ONE',city='Chennai',address='Test',state='TN',pincode='600001',phone='123')
    cat=VehicleCategory.objects.create(name='Tourer',type='car',base_price_per_day=100,base_price_per_hour=10)
    car=Vehicle.objects.create(branch=branch,category=cat,registration_number='ONE',make='Test',model='Tourer',year=2025,color='Green',fuel_type='petrol')
    guest=User.objects.create_user(email='guest@example.invalid',password='Testing@123',role='customer',branch=branch)
    staff=User.objects.create_user(email='staff@example.invalid',password='Testing@123',role='staff',branch=branch)
    now=timezone.now()+timedelta(days=1)
    booking=Booking.objects.create(customer=guest.customer_profile,vehicle=car,pickup_datetime=now,return_datetime=now+timedelta(days=1),status='confirmed',base_amount=Decimal('100'),gst_amount=Decimal('18'),security_deposit=Decimal('50'),total_amount=Decimal('168'))
    return booking,guest,staff

def make_order(commerce):
    b,guest,staff=commerce
    return CheckoutOrder.objects.create(booking=b,requested_by=guest,idempotency_key=uuid.uuid4(),amount_paise=16800,rental_paise=11800,deposit_paise=5000,provider_order_id='order_fixture',status='created')

def capture(order,**overrides):
    return {'id':'pay_fixture','order_id':order.provider_order_id,'status':'captured','currency':'INR','amount':16800,'method':'upi',**overrides}

def send_event(client,settings,kind,entity,id_='event1'):
    raw=json.dumps({'event':kind,'payload':{'refund' if kind.startswith('refund') else 'payment':{'entity':entity}}}).encode()
    sig=hmac.new(settings.RAZORPAY_WEBHOOK_SECRET.encode(),raw,hashlib.sha256).hexdigest()
    return client.post('/api/v1/checkout/webhook/',raw,content_type='application/json',HTTP_X_RAZORPAY_SIGNATURE=sig,HTTP_X_RAZORPAY_EVENT_ID=id_)

def test_order_idempotency_and_no_client_amount(commerce):
    b,g,s=commerce;key=uuid.uuid4()
    with patch('apps.commerce.gateway.call',return_value={'id':'order_new','amount':16800,'currency':'INR'}) as provider:
        a=new_order(g,b.pk,key);again=new_order(g,b.pk,key)
    assert a.pk==again.pk and provider.call_count==1
    b.refresh_from_db();assert b.amount_paid==0 and a.status=='created'

def test_ambiguous_order_blocks_new_charge(commerce):
    b,g,s=commerce
    with patch('apps.commerce.gateway.call',side_effect=GatewayUnavailable()):
        with pytest.raises(GatewayUnavailable):new_order(g,b.pk,uuid.uuid4())
    assert CheckoutOrder.objects.get().status=='unknown'
    with pytest.raises(ValidationError):new_order(g,b.pk,uuid.uuid4())

def test_capture_signature_and_duplicate_events(commerce,settings):
    order=make_order(commerce);client=APIClient()
    bad=client.post('/api/v1/checkout/webhook/',b'{}',content_type='application/json',HTTP_X_RAZORPAY_SIGNATURE='invalid')
    assert bad.status_code==403 and not LedgerEntry.objects.exists()
    assert send_event(client,settings,'payment.captured',capture(order)).status_code==200
    assert send_event(client,settings,'payment.captured',capture(order)).data['status']=='duplicate'
    assert send_event(client,settings,'payment.captured',capture(order),'different-event').status_code==200
    assert LedgerEntry.objects.count()==2
    b,g,s=commerce;b.refresh_from_db();assert b.amount_paid==Decimal('168') and b.payment_status=='paid'

@pytest.mark.parametrize('change',[{'amount':16799},{'currency':'USD'},{'status':'authorized'}])
def test_invalid_capture_does_not_settle(commerce,settings,change):
    order=make_order(commerce)
    assert send_event(APIClient(),settings,'payment.captured',capture(order,**change)).status_code==400
    assert not LedgerEntry.objects.exists()
    order.refresh_from_db();assert order.status=='created'

def test_refunds_wait_for_processing_and_bound_partial_total(commerce,settings):
    order=make_order(commerce);client=APIClient();send_event(client,settings,'payment.captured',capture(order))
    order.refresh_from_db();b,g,s=commerce;key=uuid.uuid4()
    with patch('apps.commerce.gateway.call',return_value={'id':'rfnd_fixture','payment_id':'pay_fixture','amount':6000}) as remote:
        r=new_refund(s,order.pk,6000,key,'Partial refund');again=new_refund(s,order.pk,6000,key,'Partial refund')
    assert r.pk==again.pk and remote.call_count==1 and r.status=='pending'
    b.refresh_from_db();assert b.amount_paid==168
    with pytest.raises(ValidationError):new_refund(s,order.pk,11000,uuid.uuid4(),'Too much')
    data={'id':'rfnd_fixture','payment_id':'pay_fixture','amount':6000,'currency':'INR','status':'processed'}
    assert send_event(client,settings,'refund.processed',data,'refund-event').status_code==200
    assert send_event(client,settings,'refund.processed',data,'refund-event2').status_code==200
    b.refresh_from_db();assert b.amount_paid==108 and b.payment_status=='partial'
    assert LedgerEntry.objects.filter(kind='refund_deposit').get().amount_paise==5000
    assert LedgerEntry.objects.filter(kind='refund_rental').get().amount_paise==1000

def test_refund_timeout_keeps_reservation(commerce,settings):
    order=make_order(commerce);send_event(APIClient(),settings,'payment.captured',capture(order));order.refresh_from_db()
    b,g,s=commerce
    with patch('apps.commerce.gateway.call',side_effect=GatewayUnavailable()):
        with pytest.raises(GatewayUnavailable):new_refund(s,order.pk,10000,uuid.uuid4(),'Pending verification')
    assert RefundRequest.objects.get().status=='unknown'
    with pytest.raises(ValidationError):new_refund(s,order.pk,10000,uuid.uuid4(),'Would over-refund')

def test_failed_refund_releases_reservation_without_ledger_debit(commerce,settings):
    order=make_order(commerce);client=APIClient();send_event(client,settings,'payment.captured',capture(order));order.refresh_from_db();b,g,s=commerce
    with patch('apps.commerce.gateway.call',return_value={'id':'rfnd_fixture','payment_id':'pay_fixture','amount':16800}):r=new_refund(s,order.pk,16800,uuid.uuid4(),'Refund')
    response=send_event(client,settings,'refund.failed',{'id':'rfnd_fixture','payment_id':'pay_fixture','amount':16800,'currency':'INR','status':'failed'},'failed')
    assert response.status_code==200
    r.refresh_from_db();assert r.status=='failed' and not LedgerEntry.objects.filter(kind__startswith='refund').exists()

def test_fetch_reconciles_missing_capture(commerce):
    order=make_order(commerce)
    with patch('apps.commerce.gateway.collect',return_value=iter([capture(order)])):
        reconcile_order(order)
    assert LedgerEntry.objects.count()==2

def test_unknown_event_retried_after_mapping_exists(commerce,settings):
    order=make_order(commerce);order.provider_order_id=None;order.save()
    entity={'id':'pay_fixture','order_id':'order_later','amount':16800,'currency':'INR','status':'captured'}
    assert send_event(APIClient(),settings,'payment.captured',entity).status_code==503
    order.provider_order_id='order_later';order.save()
    assert send_event(APIClient(),settings,'payment.captured',entity).status_code==200
    assert GatewayEvent.objects.get().status=='processed'

def test_customer_cannot_request_refund_or_forge_payment(commerce,settings):
    order=make_order(commerce);client=APIClient();client.force_authenticate(commerce[1])
    assert client.post('/api/v1/checkout/refunds/',{'order':str(order.pk),'amount_paise':100,'reason':'x'},format='json',HTTP_IDEMPOTENCY_KEY=str(uuid.uuid4())).status_code==403
    employee=APIClient();employee.force_authenticate(commerce[2])
    assert employee.post('/api/v1/payments/',{},format='json').status_code==405

def test_ledger_updates_rejected(commerce,settings):
    order=make_order(commerce);send_event(APIClient(),settings,'payment.captured',capture(order))
    row=LedgerEntry.objects.first()
    with pytest.raises(ValueError):row.save()
    with pytest.raises(ValueError):LedgerEntry.objects.filter(pk=row.pk).update(amount_paise=1)


@pytest.mark.parametrize("capture_first", [True, False])
def test_cancelled_booking_refund_is_queued_for_either_event_order(commerce, settings, capture_first):
    from apps.commerce.tasks import dispatch_cancellation_refunds

    booking, guest, _ = commerce
    order = make_order(commerce)
    webhook = APIClient()
    client = APIClient()
    client.force_authenticate(guest)
    if capture_first:
        assert send_event(webhook, settings, "payment.captured", capture(order)).status_code == 200
    response = client.post(f"/api/v1/bookings/{booking.pk}/cancel/", {}, format="json")
    assert response.status_code == 200, response.data
    with pytest.raises(ValidationError):
        new_order(guest, booking.pk, order.idempotency_key)
    if not capture_first:
        assert send_event(webhook, settings, "payment.captured", capture(order)).status_code == 200
    assert send_event(webhook, settings, "payment.captured", capture(order), "capture-repeat").status_code == 200
    refund = RefundRequest.objects.get(order=order)
    assert refund.status == "queued"
    assert refund.amount_paise == 15120
    result = {"id": "rfnd_cancellation", "payment_id": "pay_fixture", "amount": refund.amount_paise}
    with patch("apps.commerce.gateway.call", return_value=result) as provider:
        dispatch_cancellation_refunds()
        dispatch_cancellation_refunds()
        assert provider.call_count == 1
    booking.refresh_from_db()
    assert booking.cancellation.refund_status == "pending"
    result.update(currency="INR", status="processed")
    assert send_event(webhook, settings, "refund.processed", result, "cancel-refund").status_code == 200
    booking.refresh_from_db()
    assert booking.cancellation.refund_status == "processed"
    assert booking.amount_paid == Decimal("16.80")

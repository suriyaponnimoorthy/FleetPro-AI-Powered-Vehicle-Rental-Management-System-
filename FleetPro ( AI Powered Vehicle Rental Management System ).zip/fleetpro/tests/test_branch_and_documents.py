from io import BytesIO
from datetime import timedelta
from unittest.mock import patch
import pytest
from django.utils import timezone
from django.core.cache import cache
from django.core.files.uploadedfile import SimpleUploadedFile
from PIL import Image
from rest_framework.test import APIClient
from apps.authentication.models import User
from apps.vehicles.models import Branch,Vehicle,VehicleCategory
from apps.bookings.models import Booking

pytestmark=pytest.mark.django_db
@pytest.fixture
def branches(settings,tmp_path):
    cache.clear();settings.PRIVATE_MEDIA_ROOT=tmp_path/'private';settings.PRIVATE_UPLOAD_SCAN_REQUIRED=False
    a=Branch.objects.create(name='One',code='ONE',city='Chennai',address='Test',state='TN',pincode='600001',phone='1')
    b=Branch.objects.create(name='Two',code='TWO',city='Mumbai',address='Test',state='MH',pincode='400001',phone='2')
    staff=User.objects.create_user(email='staff@test.invalid',password='Testing@123',role='staff',branch=a)
    other=User.objects.create_user(email='other@test.invalid',password='Testing@123',role='staff',branch=b)
    owner=User.objects.create_user(email='guest@test.invalid',password='Testing@123',role='customer',branch=a)
    cat=VehicleCategory.objects.create(name='Tourer',type='car',base_price_per_day=100,base_price_per_hour=10)
    cars=[Vehicle.objects.create(branch=x,category=cat,registration_number=x.code,make='Test',model=x.name,year=2025,color='Green',fuel_type='petrol') for x in [a,b]]
    client=APIClient();client.force_authenticate(staff)
    return client,staff,other,owner,cars

def image_file():
    buf=BytesIO();Image.new('RGB',(8,8),'green').save(buf,format='PNG');return SimpleUploadedFile('identity.png',buf.getvalue(),content_type='image/png')

def test_staff_list_detail_write_and_analytics_scope(branches):
    c,staff,other,owner,cars=branches
    assert c.get('/api/v1/vehicles/').data['count']==1
    assert c.get(f'/api/v1/vehicles/{cars[1].pk}/').status_code==404
    assert c.patch(f'/api/v1/vehicles/{cars[0].pk}/',{'branch':str(cars[1].branch_id)},format='json').status_code==403
    assert c.get('/api/v1/analytics/dashboard/').data['vehicles']['total']==1
    assert c.get('/api/v1/users/').data['count']==2
    assert c.patch(f'/api/v1/users/{staff.pk}/',{'role':'super_admin'},format='json').status_code==403

def test_unassigned_employee_sees_nothing(branches):
    c,staff,*_=branches;staff.branch=None;staff.save()
    assert c.get('/api/v1/vehicles/').data['count']==0
    assert c.get('/api/v1/analytics/dashboard/').data['vehicles']['total']==0

def test_employee_catalog_for_ai_is_branch_scoped(branches):
    c,staff,other,owner,cars=branches
    r=c.post('/api/v1/intelligence/recommendations/',{},format='json')
    assert [v['id'] for v in r.data['results']]==[str(cars[0].pk)]

def test_kyc_upload_and_download_requires_owner_or_same_branch(branches):
    c,staff,other,owner,cars=branches;c.force_authenticate(owner)
    path=f'/api/v1/private-documents/customer/{owner.customer_profile.pk}/dl_document/'
    result=c.post(path,{'file':image_file()},format='multipart');assert result.status_code==201,result.data
    owner.customer_profile.refresh_from_db();file=owner.customer_profile.dl_document
    assert 'private' in file.path and 'media/' not in file.path
    url=result.data['url']
    response=c.get(url);assert response.status_code==200 and response['Cache-Control'].startswith('private, no-store')
    assert b"".join(response.streaming_content);c.force_authenticate(other);assert c.get(url).status_code==403
    c.force_authenticate(staff);response=c.get(url);assert response.status_code==200;assert b"".join(response.streaming_content)
    c.force_authenticate(None);assert c.get(url).status_code==401

def test_fake_file_and_unavailable_scanner_block_upload(branches,settings):
    c,staff,other,owner,cars=branches;c.force_authenticate(owner)
    path=f'/api/v1/private-documents/customer/{owner.customer_profile.pk}/dl_document/'
    assert c.post(path,{'file':SimpleUploadedFile('fake.pdf',b'<script>bad</script>')},format='multipart').status_code==400
    settings.PRIVATE_UPLOAD_SCAN_REQUIRED=True
    with patch('socket.create_connection',side_effect=OSError('scanner down')):
        assert c.post(path,{'file':image_file()},format='multipart').status_code==400

def test_public_vehicle_details_exclude_sensitive_fields(branches):
    c,staff,other,owner,cars=branches;c.force_authenticate(owner)
    data=c.get(f'/api/v1/vehicles/{cars[0].pk}/').data
    assert not any(x in data for x in ['notes','gps_device_id','active_booking','insurance_status'])


def test_driver_creation_and_self_update_respect_branch_and_role(branches):
    from apps.drivers.models import Driver

    client, staff, other, owner, cars = branches
    payload = {
        "email": "driver@test.invalid", "first_name": "Sample", "last_name": "Driver",
        "phone": "+919876543210", "branch": str(staff.branch_id), "employee_id": "D001",
        "dl_number": "TN000001", "dl_expiry_date": "2030-12-31",
    }
    assert client.post("/api/v1/drivers/", payload, format="json").status_code == 400
    payload["password"] = "Strong-fixture-driver-pass-823!"
    assert client.post("/api/v1/drivers/", {**payload, "branch": str(other.branch_id)}, format="json").status_code == 403
    created = client.post("/api/v1/drivers/", payload, format="json")
    assert created.status_code == 201, created.data
    driver = Driver.objects.get(user__email=payload["email"])
    assert driver.user.check_password(payload["password"])
    client.force_authenticate(driver.user)
    url = f"/api/v1/drivers/{driver.pk}/"
    for field, value in {
        "monthly_salary": "999999", "daily_rate": "99999", "user": str(owner.pk), "branch": str(other.branch_id)
    }.items():
        assert client.patch(url, {field: value}, format="json").status_code == 400
    assert client.patch(url, {"city": "Chennai"}, format="json").status_code == 200


def test_kyc_identifiers_are_omitted_and_rejection_revokes_verification(branches):
    client, _, _, owner, _ = branches
    profile = owner.customer_profile
    profile.aadhar_number = "123456789012"
    profile.pan_number = "ABCDE1234F"
    profile.dl_number = "TN1234"
    profile.kyc_status = "verified"
    profile.save()
    owner.is_kyc_verified = True
    owner.save(update_fields=["is_kyc_verified"])
    url = f"/api/v1/customers/{profile.pk}/"
    response = client.get(url)
    assert response.status_code == 200
    assert not {"aadhar_number", "pan_number", "dl_number"}.intersection(response.data)
    assert client.post(url + "reject-kyc/", {}, format="json").status_code == 200
    owner.refresh_from_db()
    assert not owner.is_kyc_verified


def test_signature_can_be_added_once_and_cannot_be_added_after_close(branches):
    from apps.bookings.models import VehicleInspection

    client, _, _, owner, cars = branches
    start = timezone.now()
    booking = Booking.objects.create(customer=owner.customer_profile, vehicle=cars[0],
                                     pickup_datetime=start, return_datetime=start + timedelta(days=1),
                                     status="active")
    client.force_authenticate(owner)
    for kind, status, expected in [("pre_rental", "active", 201), ("post_rental", "completed", 400)]:
        booking.status = status
        booking.save(update_fields=["status"])
        inspection = VehicleInspection.objects.create(
            booking=booking, inspection_type=kind, odometer_reading=30, fuel_level=70, overall_condition="good"
        )
        url = f"/api/v1/private-documents/inspection/{inspection.pk}/customer_signature/"
        assert client.post(url, {"file": image_file()}, format="multipart").status_code == expected
        assert client.post(url, {"file": image_file()}, format="multipart").status_code == 400

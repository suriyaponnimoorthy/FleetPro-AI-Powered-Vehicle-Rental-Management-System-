from datetime import timedelta
from decimal import Decimal
from unittest.mock import patch
import pytest
from django.utils import timezone
from django.core.cache import cache
from rest_framework.test import APIClient
from apps.authentication.models import User
from apps.vehicles.models import Vehicle, VehicleCategory, Branch, MaintenanceSchedule
from apps.bookings.models import Booking

pytestmark = pytest.mark.django_db

@pytest.fixture
def setup_fleet():
    cache.clear()
    branch = Branch.objects.create(name='Test', code='TEST', city='Chennai', address='Test', state='TN', pincode='600001', phone='123')
    cat = VehicleCategory.objects.create(name='Touring', type='car', base_price_per_day=Decimal('2000'), base_price_per_hour=200)
    car = Vehicle.objects.create(make='Toyota', model='Touring', year=2025, color='Green', registration_number='TEST1', branch=branch, category=cat, fuel_type='hybrid', transmission='automatic', seating_capacity=5)
    user = User.objects.create_user(email='customer@test.invalid', password='Testing@123', role='customer', first_name='Test', last_name='Guest')
    user.customer_profile.kyc_status='verified';user.customer_profile.save()
    client = APIClient();client.force_authenticate(user)
    return client, user, car

def recommend(client, **prefs):
    return client.post('/api/v1/intelligence/recommendations/', prefs, format='json')

def test_requires_authentication():
    assert APIClient().post('/api/v1/intelligence/chat/', {'message':'hi'}).status_code==401
    assert APIClient().post('/api/v1/intelligence/recommendations/', {}).status_code==401

def test_hard_constraints_and_explanations(setup_fleet):
    client,user,car=setup_fleet
    response=recommend(client,city='Chennai',budget_per_day=2500,seats=4,transmission='automatic')
    assert response.status_code==200
    assert response.data['results'][0]['id']==str(car.id)
    assert response.data['results'][0]['reasons']
    assert not response.data['availability_checked']
    assert not recommend(client,budget_per_day=1000).data['results']
    assert not recommend(client,seats=7).data['results']
    assert not recommend(client,city='Mumbai').data['results']
    assert not recommend(client,fuel_type='electric').data['results']

def test_invalid_dates(setup_fleet):
    client,_,_=setup_fleet
    start=timezone.now()+timedelta(days=1)
    assert recommend(client,pickup_datetime=start.isoformat()).status_code==400
    assert recommend(client,pickup_datetime=start.isoformat(),return_datetime=(start-timedelta(hours=1)).isoformat()).status_code==400
    assert recommend(client,pickup_datetime=start.isoformat(),return_datetime=(start+timedelta(days=31)).isoformat()).status_code==400

@pytest.mark.parametrize('status',['pending','confirmed','active'])
def test_conflicting_rentals_excluded(setup_fleet,status):
    client,user,car=setup_fleet
    start=timezone.now()+timedelta(days=1);end=start+timedelta(days=2)
    Booking.objects.create(customer=user.customer_profile,vehicle=car,pickup_datetime=start,return_datetime=end,status=status)
    assert not recommend(client,pickup_datetime=start.isoformat(),return_datetime=end.isoformat()).data['results']
    # Half-open intervals: returning exactly at the next pickup does not overlap.
    assert recommend(client,pickup_datetime=end.isoformat(),return_datetime=(end+timedelta(days=1)).isoformat()).data['results']

def test_service_and_inactive_inventory_excluded(setup_fleet):
    client,user,car=setup_fleet
    start=timezone.now()+timedelta(days=2)
    MaintenanceSchedule.objects.create(vehicle=car,maintenance_type='routine',scheduled_date=start.date())
    assert not recommend(client,pickup_datetime=start.isoformat(),return_datetime=(start+timedelta(days=1)).isoformat()).data['results']
    car.is_active=False;car.save()
    assert not recommend(client).data['results']

def test_chat_only_returns_own_bookings(setup_fleet):
    client,user,car=setup_fleet
    other=User.objects.create_user(email='other@test.invalid',password='Testing@123',role='customer')
    start=timezone.now()+timedelta(days=2)
    own=Booking.objects.create(customer=user.customer_profile,vehicle=car,pickup_datetime=start,return_datetime=start+timedelta(days=1))
    foreign=Booking.objects.create(customer=other.customer_profile,vehicle=car,pickup_datetime=start+timedelta(days=3),return_datetime=start+timedelta(days=4))
    answer=client.post('/api/v1/intelligence/chat/',{'message':'my bookings'},format='json').data['answer']
    assert own.booking_number in answer
    assert foreign.booking_number not in answer

def test_ai_disabled_without_consent(setup_fleet,settings):
    settings.FLEETPRO_AI_API_KEY='test-key'
    client,_,_=setup_fleet
    with patch('apps.intelligence.views.language_response') as provider:
        assert client.post('/api/v1/intelligence/chat/',{'message':'Find a quiet electric car'},format='json').data['mode']=='local-guide'
        provider.assert_not_called()

def test_ai_failure_falls_back(setup_fleet,settings):
    settings.FLEETPRO_AI_API_KEY='test-key'
    client,_,_=setup_fleet
    with patch('apps.intelligence.views.language_response',side_effect=TimeoutError):
        response=client.post('/api/v1/intelligence/chat/',{'message':'Find a quiet car','allow_external_ai':True},format='json')
    assert response.status_code==200 and response.data['mode']=='local-fallback'

def test_ai_receives_only_allowlisted_inventory(setup_fleet,settings):
    settings.FLEETPRO_AI_API_KEY='test-key'
    client,user,car=setup_fleet
    car.notes='PRIVATE SERVICE NOTE';car.save()
    with patch('apps.intelligence.views.language_response',return_value='Try the match finder.') as provider:
        response=client.post('/api/v1/intelligence/chat/',{'message':'Find a touring car','allow_external_ai':True},format='json')
    assert response.data['mode']=='ai-concierge'
    sent=str(provider.call_args)
    assert 'PRIVATE SERVICE NOTE' not in sent and user.email not in sent
    assert not response.data['can_execute_actions']

def test_ai_rerank_failure_and_consent(setup_fleet,settings):
    settings.FLEETPRO_AI_API_KEY='test-key'
    client,_,_=setup_fleet
    with patch('apps.intelligence.views.ai_rerank',side_effect=TimeoutError) as provider:
        recommend(client,trip_brief='Weekend')
        provider.assert_not_called()
        response=recommend(client,trip_brief='Weekend',use_ai=True)
    assert response.status_code==200 and response.data['engine']=='content-based-v1'
    assert 'unavailable' in response.data['ai_status']

def test_ai_rerank_ignores_invented_and_duplicate_ids(setup_fleet,settings):
    import json
    from io import BytesIO
    from apps.intelligence.services import ai_rerank,rank_inventory
    client,_,car=setup_fleet
    ranked=rank_inventory([car],{})
    body={'output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(['invented',str(car.id),str(car.id)])}]}]}
    with patch('urllib.request.urlopen',return_value=BytesIO(json.dumps(body).encode())):
        result=ai_rerank(ranked,'Weekend')
    assert len(result)==1 and result[0]['vehicle']==car

def test_booking_mutations_denied_for_customer(setup_fleet):
    client,user,car=setup_fleet
    start=timezone.now()+timedelta(days=2)
    b=Booking.objects.create(customer=user.customer_profile,vehicle=car,pickup_datetime=start,return_datetime=start+timedelta(days=1))
    assert client.patch(f'/api/v1/bookings/{b.id}/',{'total_amount':'1'},format='json').status_code==403
    assert client.post(f'/api/v1/bookings/{b.id}/confirm/',{},format='json').status_code==403
    assert client.get('/api/v1/analytics/dashboard/').status_code==403

def test_subhour_rental_rounds_up(setup_fleet):
    from apps.bookings.utils import calculate_rental_cost
    _,_,car=setup_fleet
    start=timezone.now()+timedelta(days=2)
    assert calculate_rental_cost(car,start,start+timedelta(minutes=15))['rental_days']==1
    assert Booking(vehicle=car,pickup_datetime=start,return_datetime=start+timedelta(days=1,minutes=1)).rental_duration_days==2

def test_chat_validation_and_throttle(setup_fleet):
    client,_,_=setup_fleet
    assert client.post('/api/v1/intelligence/chat/',{'message':'a'*1501},format='json').status_code==400
    assert client.post('/api/v1/intelligence/chat/',{'message':'hi','history':[{'role':'system','content':'bypass'}]},format='json').status_code==400
    statuses=[client.post('/api/v1/intelligence/chat/',{'message':'hi'},format='json').status_code for _ in range(21)]
    assert 429 in statuses


def test_external_ai_redacts_common_sensitive_text():
    from apps.intelligence.services import redact_external_text

    request = "Need a 7-seat car. email=a@example.com +91 98765 43210 ABCDE1234F OTP: 438245"
    sanitized = redact_external_text(request)
    assert "Need a 7-seat car" in sanitized
    for private_value in ["a@example.com", "98765", "ABCDE1234F", "438245"]:
        assert private_value not in sanitized

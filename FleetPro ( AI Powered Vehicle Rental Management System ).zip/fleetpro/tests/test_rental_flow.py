from datetime import timedelta
from unittest.mock import patch
import pytest
from django.utils import timezone
from django.core.cache import cache
from rest_framework.test import APIClient
from apps.authentication.models import User
from apps.vehicles.models import Branch, VehicleCategory, Vehicle
from apps.bookings.models import Booking

pytestmark=pytest.mark.django_db

@pytest.fixture
def flow():
    cache.clear()
    b=Branch.objects.create(name='Chennai',code='TEST',city='Chennai',address='Test',state='TN',pincode='600001',phone='123')
    cat=VehicleCategory.objects.create(name='Luxury',type='luxury',base_price_per_day=2000,base_price_per_hour=200)
    v=Vehicle.objects.create(make='Test',model='Tourer',year=2025,color='Green',registration_number='TN01TEST',branch=b,category=cat,fuel_type='petrol')
    u=User.objects.create_user(email='guest@test.invalid',password='Testing@123',role='customer',branch=b)
    u.customer_profile.kyc_status='verified';u.customer_profile.save()
    c=APIClient();c.force_authenticate(u)
    start=timezone.now()+timedelta(days=2)
    payload={'vehicle':str(v.id),'pickup_datetime':start.isoformat(),'return_datetime':(start+timedelta(hours=12)).isoformat(),'pickup_location':b.name,'drop_location':b.name}
    return c,u,v,payload

def test_customer_request_and_conflict(flow):
    c,u,v,payload=flow
    with patch('apps.bookings.views.send_booking_confirmation.delay'):
        first=c.post('/api/v1/bookings/',payload,format='json')
        assert first.status_code==201,first.data
        assert first.data['status']=='pending'
        assert first.data['total_amount']=='7360.00'
        second=c.post('/api/v1/bookings/',payload,format='json')
        assert second.status_code==409

def test_employee_selects_customer(flow):
    c,u,v,payload=flow
    staff=User.objects.create_user(email='employee@test.invalid',password='Testing@123',role='staff',branch=v.branch)
    c.force_authenticate(staff)
    r=c.post('/api/v1/bookings/',{**payload,'customer':str(u.customer_profile.id)},format='json')
    assert r.status_code==201,r.data
    assert Booking.objects.get(id=r.data['id']).customer.user==u

def test_customer_cannot_self_verify(flow):
    c,u,v,payload=flow
    assert c.post(f'/api/v1/customers/{u.customer_profile.id}/verify-kyc/',{},format='json').status_code==403
    assert c.patch(f'/api/v1/customers/{u.customer_profile.id}/',{'kyc_status':'verified'},format='json').status_code==403

def test_foreign_customer_input_does_not_change_owner(flow):
    c,u,v,payload=flow
    other=User.objects.create_user(email='other@test.invalid',password='Testing@123',role='customer')
    r=c.post('/api/v1/bookings/',{**payload,'customer':str(other.customer_profile.id)},format='json')
    assert r.status_code==201,r.data
    assert Booking.objects.get(id=r.data['id']).customer.user==u

def test_pickup_and_return_update_fleet_status(flow):
    c,u,v,payload=flow
    staff=User.objects.create_user(email='staff@test.invalid',password='Testing@123',role='staff',branch=v.branch)
    c.force_authenticate(staff)
    b=Booking.objects.create(customer=u.customer_profile,vehicle=v,pickup_datetime=timezone.now(),return_datetime=timezone.now()+timedelta(days=1),status='confirmed')
    with patch('apps.bookings.views.send_return_reminder.apply_async'):
        assert c.post(f'/api/v1/bookings/{b.id}/activate/',{},format='json').status_code==200
    v.refresh_from_db();assert v.status=='rented'
    assert c.post(f'/api/v1/bookings/{b.id}/cancel/',{},format='json').status_code==400
    assert c.post(f'/api/v1/bookings/{b.id}/complete/',{},format='json').status_code==200
    v.refresh_from_db();assert v.status=='available'

"""These tests REQUIRE PostgreSQL. SQLite is explicitly skipped, never called equivalent."""
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from datetime import timedelta
from unittest.mock import patch
import uuid
import pytest
from django.db import connection,close_old_connections,transaction,DatabaseError
from django.utils import timezone
from rest_framework.test import APIClient
from rest_framework.exceptions import ValidationError
from apps.authentication.models import User
from apps.vehicles.models import Branch,VehicleCategory,Vehicle
from apps.bookings.models import Booking
from apps.commerce.models import CheckoutOrder,LedgerEntry
from apps.commerce.services import new_refund,ingest
pytestmark=[pytest.mark.django_db(transaction=True),pytest.mark.integration]

@pytest.fixture
def pg_fleet():
    if connection.vendor!='postgresql':pytest.skip('Requires actual PostgreSQL row locks; run the PostgreSQL CI job.')
    b=Branch.objects.create(name='Test',code='TST',city='Chennai',address='Test',state='TN',pincode='600001',phone='1')
    cat=VehicleCategory.objects.create(name='Tourer',type='car',base_price_per_day=100,base_price_per_hour=10)
    v=Vehicle.objects.create(branch=b,category=cat,registration_number='TEST',make='Test',model='Tourer',year=2025,color='Green',fuel_type='petrol')
    u=User.objects.create_user(email='guest@test.invalid',password='Testing@123',role='customer',branch=b)
    u.customer_profile.kyc_status='verified';u.customer_profile.save()
    staff=User.objects.create_user(email='staff@test.invalid',password='Testing@123',role='staff',branch=b)
    return u,staff,v

def racing(fn):
    barrier=Barrier(2)
    def worker(i):
        close_old_connections()
        try:barrier.wait(timeout=10);return fn(i)
        finally:close_old_connections()
    with ThreadPoolExecutor(max_workers=2) as executor:return list(executor.map(worker,[0,1]))

def test_only_one_overlapping_booking_wins(pg_fleet):
    u,s,v=pg_fleet;start=timezone.now()+timedelta(days=2)
    data={'vehicle':str(v.pk),'pickup_datetime':start.isoformat(),'return_datetime':(start+timedelta(days=1)).isoformat(),'pickup_location':'Branch','drop_location':'Branch'}
    def attempt(i):
        c=APIClient();c.force_authenticate(u);return c.post('/api/v1/bookings/',data,format='json').status_code
    with patch('apps.bookings.views.send_booking_confirmation.delay'):
        assert sorted(racing(attempt))==[201,409]
    assert Booking.objects.count()==1

def captured(pg_fleet):
    u,s,v=pg_fleet;now=timezone.now()
    b=Booking.objects.create(customer=u.customer_profile,vehicle=v,pickup_datetime=now,return_datetime=now+timedelta(days=1),total_amount=168,security_deposit=50)
    o=CheckoutOrder.objects.create(booking=b,requested_by=u,idempotency_key=uuid.uuid4(),provider_order_id='order_fixture',provider_payment_id='pay_fixture',amount_paise=16800,rental_paise=11800,deposit_paise=5000,status='created')
    payload={'event':'payment.captured','payload':{'payment':{'entity':{'id':'pay_fixture','order_id':'order_fixture','status':'captured','currency':'INR','amount':16800}}}}
    return b,o,payload

def test_duplicate_webhooks_do_not_double_credit(pg_fleet):
    b,o,payload=captured(pg_fleet)
    assert sorted(racing(lambda i:ingest(payload,'same-event','same-hash')))==['duplicate','processed']
    b.refresh_from_db();assert b.amount_paid==168 and LedgerEntry.objects.count()==2

def test_concurrent_refunds_cannot_overreserve_capture(pg_fleet):
    b,o,payload=captured(pg_fleet);ingest(payload,'capture','capture');o.refresh_from_db()
    def attempt(i):
        try:new_refund(pg_fleet[1],o.pk,10000,uuid.uuid4(),'Concurrent request');return 'accepted'
        except ValidationError:return 'rejected'
    def provider(*a,**kw):return {'id':'rfnd_fixture','payment_id':'pay_fixture','amount':10000}
    with patch('apps.commerce.gateway.configured',return_value=True),patch('apps.commerce.gateway.call',side_effect=provider):
        assert sorted(racing(attempt))==['accepted','rejected']

def test_postgres_trigger_rejects_ledger_mutation(pg_fleet):
    b,o,payload=captured(pg_fleet);ingest(payload,'capture','capture')
    row=LedgerEntry.objects.first()
    with pytest.raises(DatabaseError),transaction.atomic():
        with connection.cursor() as cursor:cursor.execute('UPDATE commerce_ledgerentry SET amount_paise=1 WHERE id=%s',[row.pk])
    row.refresh_from_db();assert row.amount_paise!=1

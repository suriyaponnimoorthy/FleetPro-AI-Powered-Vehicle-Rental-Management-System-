from io import StringIO
from unittest.mock import patch,MagicMock
import pytest
from django.core.management import call_command,CommandError
from django.core.cache import cache
from django.contrib.admin import site
from django.test import RequestFactory
from apps.authentication.models import User
from apps.notifications.services import NotificationService
from apps.notifications.models import NotificationLog
pytestmark=pytest.mark.django_db

def test_missing_sms_config_is_not_recorded_as_delivered(settings):
    settings.TWILIO_ACCOUNT_SID='';settings.TWILIO_AUTH_TOKEN=''
    u=User.objects.create_user(email='guest@test.invalid',password='Testing@123',phone='+919876543210')
    assert NotificationService().send_sms(u,'Test') is False
    assert NotificationLog.objects.get().status=='failed'

def test_email_failure_is_visible_and_retryable():
    u=User.objects.create_user(email='guest@test.invalid',password='Testing@123')
    with patch('django.template.loader.render_to_string',return_value='<p>Test</p>'),patch('django.core.mail.EmailMultiAlternatives.send',side_effect=OSError('SMTP unavailable')):
        with pytest.raises(OSError):NotificationService().send_email(u,'Test','unused',{})
    assert NotificationLog.objects.get().status=='failed'

def test_branch_employee_cannot_enter_unscoped_admin():
    u=User.objects.create_user(email='admin@test.invalid',password='Testing@123',role='admin',is_staff=True)
    r=RequestFactory().get('/admin/');r.user=u
    assert not site.has_permission(r)

def test_integration_report_does_not_claim_unconfigured_ai(settings):
    settings.FLEETPRO_AI_API_KEY='';out=StringIO();call_command('check_integrations',stdout=out)
    assert 'not_configured' in out.getvalue()
    assert 'configured_not_live_tested' in out.getvalue()

def test_health_does_not_leak_connection_secrets(client):
    with patch('apps.core.health_urls.connection.cursor',side_effect=OSError('password=secret')):
        r=client.get('/health/ready/')
    assert r.status_code==503 and b'secret' not in r.content

def test_metrics_require_dedicated_token(client,settings):
    settings.METRICS_TOKEN='test-metrics-token'
    assert client.get('/internal/metrics').status_code==404
    r=client.get('/internal/metrics',HTTP_AUTHORIZATION='Bearer test-metrics-token')
    assert r.status_code==200 and b'fleetpro_webhooks_unmatched' in r.content

def test_sms_acceptance_stays_pending_until_delivery(settings):
    settings.TWILIO_ACCOUNT_SID='fixture-sid';settings.TWILIO_AUTH_TOKEN='fixture-token';settings.TWILIO_PHONE_NUMBER='+15005550006'
    u=User.objects.create_user(email='guest@test.invalid',password='Testing@123',phone='+919876543210')
    provider=MagicMock();provider.messages.create.return_value=MagicMock(sid='SMfixture',status='queued')
    provider.messages.return_value.fetch.return_value=MagicMock(status='delivered')
    with patch('twilio.rest.Client',return_value=provider):
        assert NotificationService().send_sms(u,'Test') is True
        row=NotificationLog.objects.get();assert row.status=='pending'
        call_command('reconcile_sms',stdout=StringIO())
    row.refresh_from_db();assert row.status=='sent'

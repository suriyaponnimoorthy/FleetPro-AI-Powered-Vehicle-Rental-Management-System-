from datetime import timedelta
from unittest.mock import patch

import pytest
from django.core.cache import cache
from django.utils import timezone
from rest_framework.test import APIClient

from apps.authentication.browser import COOKIE
from apps.authentication.models import OTPVerification, User
from apps.authentication.utils import otp_digest
from apps.authentication.tasks import send_otp_task

pytestmark = pytest.mark.django_db
PASSWORD = "Fixture-password-473!"


@pytest.fixture
def user():
    cache.clear()
    return User.objects.create_user(email="security@example.invalid", password=PASSWORD,
                                    phone="+919876543210", is_phone_verified=True)


def issue(user, purpose, code="246810"):
    destination = str(user.phone) if purpose == "phone_verify" else user.email
    return OTPVerification.objects.create(
        user=user, otp_type=purpose, destination=destination,
        code=otp_digest(user.pk, purpose, destination, code),
        expires_at=timezone.now() + timedelta(minutes=10),
    )


def test_reset_limits_guesses_and_revokes_sessions(user):
    client = APIClient()
    login = client.post("/api/v1/auth/login/", {"email": user.email, "password": PASSWORD}, format="json")
    assert login.status_code == 200
    password = "New-fixture-password-928!"
    body = {"email": user.email, "new_password": password, "confirm_password": password}
    endpoint = "/api/v1/auth/reset-password/"
    record = issue(user, "password_reset")
    for _ in range(3):
        assert client.post(endpoint, {**body, "otp": "111111"}, format="json").status_code == 400
    record.refresh_from_db()
    assert record.attempts == 3 and record.is_used
    assert client.post(endpoint, {**body, "otp": "246810"}, format="json").status_code == 400
    issue(user, "password_reset")
    assert client.post(endpoint, {**body, "otp": "246810"}, format="json").status_code == 200
    assert client.post(endpoint, {**body, "otp": "246810"}, format="json").status_code == 400
    assert client.get("/api/v1/auth/profile/", HTTP_AUTHORIZATION=f"Bearer {login.data['access']}").status_code == 401
    assert client.post("/api/v1/auth/token/refresh/", {"refresh": login.data["refresh"]}, format="json").status_code == 401


def test_phone_change_invalidates_challenge_and_verification(user):
    client = APIClient()
    client.force_authenticate(user)
    issue(user, "phone_verify")
    result = client.patch("/api/v1/auth/profile/", {"phone": "+919876543211"}, format="json")
    assert result.status_code == 200 and not result.data["is_phone_verified"]
    body = {"otp_type": "phone_verify", "code": "246810"}
    assert client.post("/api/v1/auth/verify-otp/", body, format="json").status_code == 400
    user.refresh_from_db()
    with patch("apps.authentication.tasks.generate_otp", return_value="135790"), patch(
        "apps.notifications.services.NotificationService.send_sms", return_value=True
    ) as sms:
        send_otp_task(str(user.pk), "phone_verify")
        assert str(sms.call_args.args[0].phone) == "+919876543211"
    record = user.otps.get(is_used=False)
    assert record.code != "135790"
    assert client.post("/api/v1/auth/verify-otp/", {**body, "code": "135790"}, format="json").status_code == 200


def test_browser_refresh_cookie_requires_csrf_and_rotates(user):
    client = APIClient(enforce_csrf_checks=True)
    browser = {"HTTP_X_FLEETPRO_BROWSER": "1"}
    payload = {"email": user.email, "password": PASSWORD}
    login_url = "/api/v1/auth/login/"
    refresh_url = "/api/v1/auth/token/refresh/"
    assert client.post(login_url, payload, format="json", **browser).status_code == 403
    csrf = client.get("/api/v1/auth/csrf/").json()["csrfToken"]
    headers = {**browser, "HTTP_X_CSRFTOKEN": csrf}
    login = client.post(login_url, payload, format="json", **headers)
    assert login.status_code == 200 and "refresh" not in login.data
    original = login.cookies[COOKIE]
    assert original["httponly"] and original["samesite"] == "Strict"
    assert client.post(refresh_url, {}, format="json", **browser).status_code == 403
    rotated = client.post(refresh_url, {}, format="json", **headers)
    assert rotated.status_code == 200 and "refresh" not in rotated.data
    assert rotated.cookies[COOKIE].value != original.value
    logout = client.post("/api/v1/auth/logout/", {}, format="json", **headers)
    assert logout.status_code == 200 and logout.cookies[COOKIE]["max-age"] == 0
    client.cookies[COOKIE] = rotated.cookies[COOKIE].value
    assert client.post(refresh_url, {}, format="json", **headers).status_code == 401

// frontend/src/hooks/useAuth.jsx
// Authentication context with JWT token management

import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { authAPI, refreshSession, setAccessToken } from "../utils/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let active = true;
    for (const key of ["access_token", "refresh_token", "user"]) localStorage.removeItem(key);
    refreshSession()
      .then(() => authAPI.getProfile())
      .then(({ data }) => { if (active) setUser(data); })
      .catch(() => {})
      .finally(() => { if (active) setIsLoading(false); });
    return () => { active = false; };
  }, []);

  const login = useCallback(async (email, password) => {
    const { data } = await authAPI.login({ email, password });
    setAccessToken(data.access);
    setUser(data.user);
    return data.user;
  }, []);

  const logout = useCallback(async () => {
    await authAPI.logout();
    setAccessToken(null);
    queryClient.clear();
    setUser(null);
  }, [queryClient]);

  const updateUser = useCallback((updates) => {
    setUser(current => ({ ...current, ...updates }));
  }, []);

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    updateUser,
    isAdmin:      ["super_admin", "admin"].includes(user?.role),
    isStaff:      ["super_admin", "admin", "staff"].includes(user?.role),
    isSuperAdmin: user?.role === "super_admin",
    isCustomer:   user?.role === "customer",
    isDriver:     user?.role === "driver",
  };

  if (isLoading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh" }}>
        <div style={{ fontSize: 14, color: "#6B7280" }}>Loading FleetPro...</div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}


import PrivateDocuments from "../components/PrivateDocuments";
import { useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { authAPI } from "../utils/api";
export default function SettingsPage() {
  const { user, updateUser, isCustomer } = useAuth();
  const [profile, setProfile] = useState({
      first_name: user?.full_name?.split(" ")[0] || "",
      last_name: user?.full_name?.split(" ").slice(1).join(" ") || "",
    }),
    [password, setPassword] = useState({
      current_password: "",
      new_password: "",
      confirm_password: "",
    }),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  async function save(e, kind) {
    e.preventDefault();
    setBusy(true);
    setNotice("");
    try {
      if (kind === "profile") {
        const { data } = await authAPI.updateProfile(profile);
        updateUser(data);
        setNotice("Profile saved.");
      } else {
        await authAPI.changePassword(password);
        setPassword({
          current_password: "",
          new_password: "",
          confirm_password: "",
        });
        setNotice("Password updated.");
      }
    } catch (e) {
      setNotice(
        JSON.stringify(e.response?.data || "Unable to save. Try again."),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className={isCustomer ? "collection-section" : ""}>
      <div className="page-heading">
        <p className="eyebrow">YOUR FLEETPRO ACCOUNT</p>
        <h1>A few personal details.</h1>
        <p>Keep your account information up to date.</p>
      </div>
      {notice && (
        <p role="status" className="receipt">
          {notice}
        </p>
      )}
      <div className="account-grid">
        <form
          className="panel account-form"
          onSubmit={(e) => save(e, "profile")}
        >
          <h2>Profile</h2>
          {["first_name", "last_name"].map((key) => (
            <label key={key}>
              {key.replace("_", " ")}
              <input
                required
                maxLength={100}
                value={profile[key]}
                onChange={(e) =>
                  setProfile({ ...profile, [key]: e.target.value })
                }
              />
            </label>
          ))}
          <label>
            Email address
            <input value={user?.email || ""} readOnly />
          </label>
          <button className="button" disabled={busy}>
            Save profile
          </button>
        </form>
        <form
          className="panel account-form"
          onSubmit={(e) => save(e, "password")}
        >
          <h2>Change password</h2>
          {["current_password", "new_password", "confirm_password"].map(
            (key) => (
              <label key={key}>
                {key.replaceAll("_", " ")}
                <input
                  type="password"
                  autoComplete={
                    key === "current_password"
                      ? "current-password"
                      : "new-password"
                  }
                  required
                  value={password[key]}
                  onChange={(e) =>
                    setPassword({ ...password, [key]: e.target.value })
                  }
                />
              </label>
            ),
          )}
          <button className="button" disabled={busy}>
            Update password
          </button>
        </form>
      </div>
      {isCustomer && <PrivateDocuments />}
    </section>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { customerAPI } from "../utils/api";
import { StatusBadge, Card, Button, Modal } from "../components/ui/index";
import toast from "react-hot-toast";

export default function CustomersPage() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ["customers", filter],
    queryFn: () => customerAPI.list(filter !== "all" ? { kyc_status: filter } : {}).then(r => r.data),
  });

  const kycMutation = useMutation({
    mutationFn: (id) => customerAPI.verifyKYC(id),
    onSuccess: () => { qc.invalidateQueries({queryKey: ["customers"]}); toast.success("KYC verified!"); setSelected(null); },
    onError:   () => toast.error("Failed to verify KYC"),
  });

  const blacklistMutation = useMutation({
    mutationFn: ({id,reason}) => customerAPI.blacklist(id,{reason}),
    onSuccess: () => { qc.invalidateQueries({queryKey: ["customers"]}); toast.success("Customer blacklisted"); setSelected(null); },
  });

  const TIER_COLOR = { Platinum:"#7C3AED", Gold:"#F59E0B", Silver:"#667864", Bronze:"#CD7F32" };

  const customers = (data?.results||[]).filter(c =>
    !search || `${c.full_name} ${c.email} ${c.city||""}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Customer Management</h1>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search name, email…"
          style={{ padding:"7px 14px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", width:220 }} />
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {["all","pending","submitted","verified","rejected"].map(s => (
          <button key={s} onClick={()=>setFilter(s)} style={{
            padding:"5px 14px", borderRadius:20, border:"1px solid",
            fontSize:12, fontWeight:500, cursor:"pointer", textTransform:"capitalize",
            background:filter===s?"#28543e":"white", borderColor:filter===s?"#28543e":"#dce3d5",
            color:filter===s?"white":"#667864",
          }}>{s === "all" ? "All Customers" : s+" KYC"}</button>
        ))}
      </div>

      <div style={{ background:"white", borderRadius:12, border:"1px solid #dce3d5", overflow:"hidden" }}>
        {isLoading ? (
          <div style={{ padding:48, textAlign:"center", color:"#667864" }}>Loading customers…</div>
        ) : (
          <div className="table-scroll"><table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:"#f4f6ef" }}>
                {["Customer","City","KYC Status","Bookings","Total Spend","Tier","Actions"].map(h => (
                  <th key={h} style={{ padding:"10px 16px", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", textAlign:"left", borderBottom:"1px solid #dce3d5" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {customers.map(c => (
                <tr key={c.id} style={{ borderBottom:"1px solid #F3F4F6" }}>
                  <td style={{ padding:"12px 16px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <div style={{ width:32, height:32, borderRadius:"50%", background:"linear-gradient(135deg,#28543e,#527f73)", display:"flex", alignItems:"center", justifyContent:"center", color:"white", fontSize:12, fontWeight:700, flexShrink:0 }}>
                        {(c.full_name||"").split(" ").map(n=>n[0]).join("").toUpperCase().slice(0,2)}
                      </div>
                      <div>
                        <div style={{ fontSize:13, fontWeight:500 }}>{c.full_name}</div>
                        <div style={{ fontSize:11, color:"#667864" }}>{c.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding:"12px 16px", fontSize:13, color:"#667864" }}>{c.city||"—"}</td>
                  <td style={{ padding:"12px 16px" }}><StatusBadge status={c.kyc_status} /></td>
                  <td style={{ padding:"12px 16px", fontSize:13 }}>{c.total_bookings}</td>
                  <td style={{ padding:"12px 16px", fontSize:13, fontWeight:600 }}>₹{Number(c.total_spend||0).toLocaleString()}</td>
                  <td style={{ padding:"12px 16px" }}>
                    <span style={{ fontSize:11, fontWeight:700, color:TIER_COLOR[c.tier]||"#667864" }}>{c.tier||"Bronze"}</span>
                  </td>
                  <td style={{ padding:"12px 16px" }}>
                    <button onClick={()=>setSelected(c)} style={{ padding:"4px 12px", border:"1px solid #dce3d5", borderRadius:6, background:"none", cursor:"pointer", fontSize:12, color:"#667864" }}>View</button>
                  </td>
                </tr>
              ))}
              {customers.length === 0 && (
                <tr><td colSpan={7} style={{ padding:48, textAlign:"center", color:"#667864", fontSize:13 }}>No customers found.</td></tr>
              )}
            </tbody>
          </table></div>
        )}
      </div>

      <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?.full_name||""}
        footer={
          <div style={{ display:"flex", gap:8 }}>
            <Button variant="ghost" onClick={()=>setSelected(null)}>Close</Button>
            {selected?.kyc_status !== "verified" && (
              <Button onClick={()=>kycMutation.mutate(selected.id)} variant="primary">✓ Verify KYC</Button>
            )}
            {!selected?.is_blacklisted && (
              <Button variant="danger" onClick={()=>{ const r=prompt("Reason for blacklisting:"); if(r) blacklistMutation.mutate({id:selected.id,reason:r}); }}>Blacklist</Button>
            )}
          </div>
        }>
        {selected && (
          <div style={{ fontSize:13 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {[
                ["Email",       selected.email],
                ["Phone",       selected.phone||"—"],
                ["City",        selected.city||"—"],
                ["KYC Status",  selected.kyc_status],
                ["Total Bookings", selected.total_bookings],
                ["Total Spend", `₹${Number(selected.total_spend||0).toLocaleString()}`],
                ["Loyalty Points", selected.loyalty_points||0],
                ["Tier",        selected.tier||"Bronze"],
                ["Blacklisted", selected.is_blacklisted ? "Yes ⚠️" : "No"],
              ].map(([l,v]) => (
                <div key={l} style={{ background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
                  <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{l}</div>
                  <div style={{ fontWeight:600, textTransform:"capitalize" }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

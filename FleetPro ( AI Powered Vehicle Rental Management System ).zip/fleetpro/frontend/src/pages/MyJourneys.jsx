import CheckoutButton from "../components/CheckoutButton";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { bookingAPI } from "../utils/api";
import { money } from "./DashboardPage";
export default function MyJourneys() {
  const [page, setPage] = useState(1),
    [message, setMessage] = useState("");
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["bookings", "mine", page],
    queryFn: () => bookingAPI.list({ page }).then((r) => r.data),
  });
  const cancel = useMutation({
    mutationFn: (id) =>
      bookingAPI.cancel(id, {
        reason: "Customer requested cancellation in My journeys",
      }),
    onSuccess: ({ data }) => {
      setMessage(
        `Cancelled. Cancellation fee: ${money(data.cancellation_fee)}. Refund amount for staff processing: ${money(data.refund_amount)}.`,
      );
      qc.invalidateQueries({ queryKey: ["bookings"] });
      qc.invalidateQueries({ queryKey: ["matches"] });
    },
    onError: () =>
      setMessage("Unable to cancel. Please contact your rental branch."),
  });
  return (
    <section className="collection-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">YOUR FLEETPRO COLLECTION</p>
          <h2>
            Journeys to <em>look forward to.</em>
          </h2>
        </div>
        <Link className="button" to="/">
          Find your next drive <ArrowRight size={16} />
        </Link>
      </div>
      {message && (
        <p role="status" className="receipt">
          {message}
        </p>
      )}
      {q.isLoading ? (
        <p role="status">Loading your journeys…</p>
      ) : q.isError ? (
        <div role="alert">
          Unable to load bookings.{" "}
          <button onClick={() => q.refetch()}>Retry</button>
        </div>
      ) : (
        <>
          <div className="vehicle-grid">
            {q.data?.results.map((b) => (
              <article className="collection-card" key={b.id}>
                <div className="vehicle-info">
                  <span className={`pill ${b.status}`}>{b.status}</span>
                  <h3 style={{ marginTop: 20 }}>{b.vehicle_name}</h3>
                  <p>{b.booking_number}</p>
                  <p className="vehicle-spec">
                    Pickup:{" "}
                    {new Date(b.pickup_datetime).toLocaleString("en-IN")}
                  </p>
                  <p className="vehicle-spec">
                    Return:{" "}
                    {new Date(b.return_datetime).toLocaleString("en-IN")}
                  </p>
                  <div className="vehicle-price">
                    <strong>{money(b.total_amount)}</strong>
                    <small>Balance: {money(b.balance_due)}</small>
                  </div>
                  {["pending", "confirmed"].includes(b.status) &&
                    Number(b.amount_paid) === 0 && (
                      <CheckoutButton booking={b} />
                    )}
                  {["pending", "confirmed"].includes(b.status) && (
                    <details style={{ marginTop: 14 }}>
                      <summary>Cancel this reservation</summary>
                      <p>
                        Cancellation within 24 hours of pickup incurs a fee
                        under the current booking policy. Staff process any
                        refund separately.
                      </p>
                      <button
                        className="button"
                        disabled={cancel.isPending}
                        onClick={() => cancel.mutate(b.id)}
                      >
                        Confirm cancellation
                      </button>
                    </details>
                  )}
                </div>
              </article>
            ))}
          </div>
          {!q.data?.results.length && (
            <div className="empty-state">
              No journeys yet. Your next drive is waiting in the collection.
            </div>
          )}
          <div
            style={{
              display: "flex",
              gap: 15,
              marginTop: 25,
              alignItems: "center",
            }}
          >
            <button
              className="button small"
              disabled={page === 1}
              onClick={() => setPage(page - 1)}
            >
              Previous
            </button>
            <span>Page {page}</span>
            <button
              className="button small"
              disabled={!q.data?.next}
              onClick={() => setPage(page + 1)}
            >
              Next
            </button>
          </div>
        </>
      )}
    </section>
  );
}

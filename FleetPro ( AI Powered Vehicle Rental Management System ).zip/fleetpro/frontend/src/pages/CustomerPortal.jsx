import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  ArrowRight,
  Sparkles,
  Users,
  Check,
  X,
  ShieldCheck,
  SlidersHorizontal,
} from "lucide-react";
import api, { bookingAPI } from "../utils/api";
import { useAuth } from "../hooks/useAuth";
import { money } from "./DashboardPage";
const base = {
  city: "",
  budget_per_day: "10000",
  seats: 2,
  category: "",
  fuel_type: "",
  transmission: "",
  pickup_datetime: "",
  return_datetime: "",
  use_history: false,
  use_ai: false,
  trip_brief: "",
};
export default function CustomerPortal() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [form, setForm] = useState(base),
    [applied, setApplied] = useState({ seats: 2 }),
    [selected, setSelected] = useState(null),
    [error, setError] = useState(""),
    [receipt, setReceipt] = useState(null);
  const results = useRef(null),
    closeRef = useRef(null),
    opener = useRef(null);
  const query = useQuery({
    queryKey: ["matches", applied],
    queryFn: () =>
      api.post("/intelligence/recommendations/", applied).then((r) => r.data),
  });
  const reserve = useMutation({
    mutationFn: () =>
      bookingAPI.create({
        vehicle: selected.id,
        pickup_datetime: applied.pickup_datetime,
        return_datetime: applied.return_datetime,
        with_driver: false,
        pickup_location: selected.branch_name,
        drop_location: selected.branch_name,
      }),
    onSuccess: ({ data }) => {
      setReceipt(data);
      setSelected(null);
      qc.invalidateQueries({ queryKey: ["matches"] });
      qc.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: (e) =>
      setError(
        typeof e.response?.data?.error === "string"
          ? e.response.data.error
          : JSON.stringify(
              e.response?.data ||
                "Unable to request this booking. Please try again.",
            ),
      ),
  });
  function find(e) {
    e.preventDefault();
    setError("");
    const prefs = Object.fromEntries(
      Object.entries(form).filter(([, v]) => v !== ""),
    );
    if (!!form.pickup_datetime !== !!form.return_datetime) {
      setError("Choose both a pickup and return time.");
      return;
    }
    if (form.pickup_datetime) {
      if (
        new Date(form.pickup_datetime) <= new Date() ||
        new Date(form.return_datetime) <= new Date(form.pickup_datetime)
      ) {
        setError("Choose a future pickup and a later return.");
        return;
      }
      prefs.pickup_datetime = new Date(form.pickup_datetime).toISOString();
      prefs.return_datetime = new Date(form.return_datetime).toISOString();
    }
    setApplied(prefs);
    results.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  function select(e, v) {
    opener.current = e.currentTarget;
    setSelected(v);
    setReceipt(null);
    setError("");
    setTimeout(() => closeRef.current?.focus(), 0);
  }
  function close() {
    setSelected(null);
    setError("");
    opener.current?.focus();
  }
  const input = (key, label, type = "text", extra = {}) => (
    <label>
      {label}
      <input
        type={type}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        {...extra}
      />
    </label>
  );
  const days = applied.pickup_datetime
    ? Math.max(
        1,
        Math.ceil(
          (new Date(applied.return_datetime) -
            new Date(applied.pickup_datetime)) /
            86400000,
        ),
      )
    : 0;
  const rent = Number(selected?.daily_rate || 0) * days,
    deposit = Number(selected?.security_deposit_amount || 0);
  return (
    <>
      <section className="collection-hero">
        <div className="hero-art" />
        <div className="hero-overlay" />
        <div className="hero-copy">
          <p className="eyebrow">THE ART OF A BETTER JOURNEY</p>
          <h1>
            Go somewhere
            <br />
            <em>extraordinary.</em>
          </h1>
          <p>
            A city escape. A grand arrival. A road worth taking.
            <br />
            Find the drive that feels like you.
          </p>
          <a href="#collection" className="button gold">
            Explore the collection <ArrowUpRight size={18} />
          </a>
        </div>
        <div className="hero-caption">
          <span>THE FLEETPRO COLLECTION</span>
          <span>Illustrated grand touring series — vehicle details vary</span>
        </div>
      </section>
      <section className="match-section" aria-labelledby="match-title">
        <div className="match-intro">
          <div>
            <p className="eyebrow">
              <Sparkles size={14} /> THOUGHTFULLY MATCHED
            </p>
            <h2 id="match-title">Your journey. Your perfect drive.</h2>
          </div>
          <span>Curated around the way you travel.</span>
        </div>
        <form className="match-form" onSubmit={find}>
          {input("city", "Pickup city", "text", {
            placeholder: "Any city",
            maxLength: 100,
          })}
          {input("budget_per_day", "Daily budget · ₹", "number", {
            min: 1,
            max: 99999999,
            required: true,
          })}
          {input("seats", "Passengers", "number", {
            min: 1,
            max: 50,
            required: true,
          })}
          <label>
            Collection
            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            >
              <option value="">All collections</option>
              {["car", "luxury", "electric", "bike", "commercial"].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          {input("pickup_datetime", "Pickup date & time", "datetime-local")}
          {input("return_datetime", "Return date & time", "datetime-local")}
          <label>
            Transmission
            <select
              value={form.transmission}
              onChange={(e) =>
                setForm({ ...form, transmission: e.target.value })
              }
            >
              <option value="">Any transmission</option>
              <option value="automatic">Automatic</option>
              <option value="manual">Manual</option>
              <option value="cvt">CVT</option>
            </select>
          </label>
          <label>
            Fuel preference
            <select
              value={form.fuel_type}
              onChange={(e) => setForm({ ...form, fuel_type: e.target.value })}
            >
              <option value="">Any fuel</option>
              {["electric", "hybrid", "petrol", "diesel", "cng"].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          <label style={{ gridColumn: "span 2" }}>
            Describe your ideal journey (optional)
            <input
              maxLength={1000}
              placeholder="A quiet electric drive for a weekend escape"
              value={form.trip_brief}
              onChange={(e) => setForm({ ...form, trip_brief: e.target.value })}
            />
          </label>
          <label className="history-check">
            <input
              type="checkbox"
              checked={form.use_ai}
              onChange={(e) => setForm({ ...form, use_ai: e.target.checked })}
            />
            Use AI to order matches. Sends this description and eligible vehicle
            facts to OpenAI when configured. Avoid personal details.
          </label>
          <label className="history-check">
            <input
              type="checkbox"
              checked={form.use_history}
              onChange={(e) =>
                setForm({ ...form, use_history: e.target.checked })
              }
            />
            Personalize with my completed rentals
          </label>
          <button className="button" type="submit">
            <SlidersHorizontal size={16} />
            Find my match <ArrowRight size={17} />
          </button>
        </form>
        {error && !selected && (
          <p role="alert" className="error-banner">
            {error}
          </p>
        )}
      </section>
      {receipt && (
        <div className="receipt" role="status">
          <Check />
          Booking request {receipt.booking_number} received. Status:{" "}
          {receipt.status}. <Link to="/bookings">View my journeys</Link>
        </div>
      )}
      <section id="collection" ref={results} className="collection-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">A DRIVE FOR EVERY OCCASION</p>
            <h2>
              The collection, <em>chosen for you.</em>
            </h2>
          </div>
          <p>
            {query.data?.results?.length || 0} matches ·{" "}
            {query.data?.engine === "ai-reranked-v1"
              ? "AI ordered recommendations"
              : "Content-based recommendations"}
            <br />
            <small>
              {query.data?.availability_checked
                ? "Selected travel dates checked"
                : "Add travel dates to check availability"}{" "}
              · Scores reflect preference fit
            </small>
            {applied.use_ai && (
              <small style={{ display: "block" }}>
                AI: {query.data?.ai_status}
              </small>
            )}
          </p>
        </div>
        {query.isLoading ? (
          <p className="empty-state" role="status">
            Finding your next drive…
          </p>
        ) : query.isError ? (
          <div className="empty-state" role="alert">
            Unable to load recommendations.{" "}
            <button onClick={() => query.refetch()}>Try again</button>
          </div>
        ) : (
          <div className="vehicle-grid">
            {query.data?.results.map((v, i) => (
              <article key={v.id} className="collection-card">
                <div className="vehicle-art">
                  <img
                    src={
                      v.primary_image ||
                      (v.category_type === "bike"
                        ? "/images/two-wheels.svg"
                        : "/images/grand-tour.svg")
                    }
                    alt={
                      v.primary_image
                        ? `${v.make} ${v.model}`
                        : "Collection illustration; actual vehicle may differ"
                    }
                    loading="lazy"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src =
                        v.category_type === "bike"
                          ? "/images/two-wheels.svg"
                          : "/images/grand-tour.svg";
                    }}
                  />
                  <span className="match-badge">
                    <Sparkles size={12} />
                    {v.match_score} fit score
                  </span>
                  <span className="category-tag">{v.category_name}</span>
                </div>
                <div className="vehicle-info">
                  <p className="eyebrow">
                    {v.branch_city} / {v.fuel_type}
                  </p>
                  <h3>
                    {v.make} {v.model}
                  </h3>
                  <p className="vehicle-spec">
                    <Users size={14} />
                    {v.seating_capacity} seats <span>·</span>
                    {v.transmission}
                    <span>·</span>
                    {v.year}
                  </p>
                  <details>
                    <summary>Why this is a match</summary>
                    <ul>
                      {v.reasons.map((reason) => (
                        <li key={reason}>{reason}</li>
                      ))}
                    </ul>
                  </details>
                  <div className="vehicle-price">
                    <div>
                      <strong>{money(v.daily_rate)}</strong>
                      <small>/ day · tax & deposit extra</small>
                    </div>
                    <button
                      aria-label={`Explore ${v.make} ${v.model}`}
                      className="round-button"
                      onClick={(e) => select(e, v)}
                    >
                      <ArrowUpRight size={20} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
        {!query.isLoading && !query.isError && !query.data?.results.length && (
          <div className="empty-state">
            <h3>No matching drives yet.</h3>
            <p>Try another city, fewer passengers, or a higher budget.</p>
          </div>
        )}
      </section>
      <section className="assurance-strip">
        {[
          [
            ShieldCheck,
            "Confidence, from the start",
            "Clear daily rates, itemized tax and deposit.",
          ],
          [
            Sparkles,
            "A more personal collection",
            "Recommendations with reasons you can understand.",
          ],
          [
            Users,
            "A little help, whenever you need",
            "Open Concierge for rental guidance.",
          ],
        ].map(([Icon, title, body]) => (
          <article key={title}>
            <Icon size={23} />
            <div>
              <h3>{title}</h3>
              <p>{body}</p>
            </div>
          </article>
        ))}
      </section>
      {selected && (
        <div
          className="modal-backdrop"
          onClick={(e) => {
            if (e.target === e.currentTarget && !reserve.isPending) close();
          }}
        >
          <section
            className="booking-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="booking-title"
            onKeyDown={(e) => {
              if (e.key === "Escape" && !reserve.isPending) close();
              if (e.key === "Tab") {
                const nodes = [
                  ...e.currentTarget.querySelectorAll(
                    "button:not(:disabled),a[href]",
                  ),
                ];
                if (e.shiftKey && document.activeElement === nodes[0]) {
                  e.preventDefault();
                  nodes.at(-1)?.focus();
                } else if (
                  !e.shiftKey &&
                  document.activeElement === nodes.at(-1)
                ) {
                  e.preventDefault();
                  nodes[0]?.focus();
                }
              }
            }}
          >
            <button
              ref={closeRef}
              className="icon-btn dialog-close"
              disabled={reserve.isPending}
              onClick={close}
              aria-label="Close vehicle details"
            >
              <X />
            </button>
            <p className="eyebrow">YOUR NEXT JOURNEY</p>
            <h2 id="booking-title">
              {selected.make} {selected.model}
            </h2>
            <p>
              {selected.branch_name} · {selected.branch_city} ·{" "}
              {selected.seating_capacity} seats
            </p>
            {days ? (
              <>
                <p>
                  {new Date(applied.pickup_datetime).toLocaleString("en-IN")} →{" "}
                  {new Date(applied.return_datetime).toLocaleString("en-IN")}
                </p>
                <dl className="quote">
                  <div>
                    <dt>Rental · {days} day(s)</dt>
                    <dd>{money(rent)}</dd>
                  </div>
                  <div>
                    <dt>GST · 18%</dt>
                    <dd>{money(rent * 0.18)}</dd>
                  </div>
                  <div>
                    <dt>Refundable security deposit</dt>
                    <dd>{money(deposit)}</dd>
                  </div>
                  <div>
                    <dt>Estimated total</dt>
                    <dd>{money(rent * 1.18 + deposit)}</dd>
                  </div>
                </dl>
                <small>
                  Server calculates the final total and rechecks availability.
                  This requests a reservation; payment and confirmation follow
                  separately.
                </small>
                <p>
                  {!user?.is_kyc_verified &&
                    "Your customer profile must pass KYC verification before booking."}
                </p>
                {error && (
                  <p role="alert" className="error-banner">
                    {error}
                  </p>
                )}
                <button
                  className="button"
                  disabled={reserve.isPending}
                  onClick={() => reserve.mutate()}
                >
                  {reserve.isPending ? "Requesting…" : "Request reservation"}
                  <ArrowRight size={17} />
                </button>
              </>
            ) : (
              <>
                <p>
                  Select pickup and return times in Find my match, then apply
                  your preferences to check this vehicle.
                </p>
                <button
                  className="button"
                  onClick={() => {
                    close();
                    document
                      .getElementById("match-title")
                      ?.scrollIntoView({ behavior: "smooth" });
                  }}
                >
                  Choose travel dates <ArrowRight size={17} />
                </button>
              </>
            )}
          </section>
        </div>
      )}
    </>
  );
}

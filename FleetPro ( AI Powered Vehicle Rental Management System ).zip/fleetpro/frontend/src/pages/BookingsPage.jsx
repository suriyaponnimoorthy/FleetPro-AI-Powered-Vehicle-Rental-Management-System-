import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { bookingAPI } from "../utils/api";
import { StatusBadge, Button, Modal, StatCard, Card, CardHeader } from "../components/ui/index";
import StaffBookingForm from "../components/StaffBookingForm";
import toast from "react-hot-toast";

export default function BookingsPage() {
  const qc = useQueryClient();
  const [status, setStatus] = useState("all");
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey:["bookings",status],
    queryFn:()=>bookingAPI.list(status!=="all"?{status}:{}).then(r=>r.data),
  });

  const actionMutation = useMutation({
    mutationFn:({action,id,payload})=>{
      if(action==="confirm")  return bookingAPI.confirm(id);
      if(action==="activate") return bookingAPI.activate(id,payload||{});
      if(action==="complete") return bookingAPI.complete(id,payload||{});
      if(action==="cancel")   return bookingAPI.cancel(id,payload||{});
    },
    onSuccess:(_,vars)=>{ qc.invalidateQueries({queryKey: ["bookings"]}); toast.success(`Booking ${vars.action}ed!`); setSelected(null); },
    onError:(e)=>toast.error(e.response?.data?.error||"Action failed"),
  });

  const STATUS_TABS = ["all","pending","confirmed","active","completed","cancelled"];

  const stats = {
    total:   data?.count||0,
    active:  (data?.results||[]).filter(b=>b.status==="active").length,
    pending: (data?.results||[]).filter(b=>b.status==="pending").length,
    overdue: (data?.results||[]).filter(b=>b.is_overdue).length,
  };

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Booking Management</h1>
        <Button onClick={()=>setShowNew(true)}>+ New Booking</Button>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:14, marginBottom:22 }}>
        <StatCard label="Total Bookings"   value={stats.total}   icon="📅" color="#28543e" />
        <StatCard label="Active Rentals"   value={stats.active}  icon="🚗" color="#10B981" />
        <StatCard label="Pending Approval" value={stats.pending} icon="⏳" color="#F59E0B" />
        <StatCard label="Overdue Returns"  value={stats.overdue} icon="⚠️" color="#EF4444" changeDir="down" change={stats.overdue>0?`${stats.overdue} need attention`:""} />
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {STATUS_TABS.map(s=>(
          <button key={s} onClick={()=>setStatus(s)} style={{
            padding:"5px 14px", borderRadius:20, border:"1px solid",
            fontSize:12, fontWeight:500, cursor:"pointer", textTransform:"capitalize",
            background:status===s?"#28543e":"white", borderColor:status===s?"#28543e":"#dce3d5",
            color:status===s?"white":"#667864",
          }}>{s==="all"?"All Bookings":s}</button>
        ))}
      </div>

      <div style={{ background:"white", borderRadius:12, border:"1px solid #dce3d5", overflow:"hidden" }}>
        {isLoading ? (
          <div style={{ padding:48, textAlign:"center", color:"#667864" }}>Loading bookings…</div>
        ) : (
          <div className="table-scroll"><table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:"#f4f6ef" }}>
                {["Booking #","Customer","Vehicle","Pickup","Return","Amount","Status","Actions"].map(h=>(
                  <th key={h} style={{ padding:"10px 16px", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", textAlign:"left", borderBottom:"1px solid #dce3d5" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(data?.results||[]).map(b=>(
                <tr key={b.id} style={{ borderBottom:"1px solid #F3F4F6" }}>
                  <td style={{ padding:"12px 16px" }}>
                    <div style={{ fontSize:12, fontWeight:600, color:"#173c32" }}>{b.booking_number}</div>
                    {b.is_overdue && <div style={{ fontSize:10, color:"#EF4444", marginTop:2 }}>⚠️ Overdue {b.overdue_hours}h</div>}
                  </td>
                  <td style={{ padding:"12px 16px" }}>
                    <div style={{ fontSize:13, fontWeight:500 }}>{b.customer_name}</div>
                    <div style={{ fontSize:11, color:"#667864" }}>{b.customer_phone}</div>
                  </td>
                  <td style={{ padding:"12px 16px", fontSize:13 }}>{b.vehicle_name}</td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>{b.pickup_datetime?new Date(b.pickup_datetime).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"2-digit",hour:"2-digit",minute:"2-digit"}):""}</td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>{b.return_datetime?new Date(b.return_datetime).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"2-digit",hour:"2-digit",minute:"2-digit"}):""}</td>
                  <td style={{ padding:"12px 16px", fontSize:13, fontWeight:700 }}>₹{Number(b.total_amount||0).toLocaleString()}</td>
                  <td style={{ padding:"12px 16px" }}><StatusBadge status={b.status} /></td>
                  <td style={{ padding:"12px 16px" }}>
                    <button onClick={()=>setSelected(b)} style={{ padding:"4px 12px", border:"1px solid #dce3d5", borderRadius:6, background:"none", cursor:"pointer", fontSize:12, color:"#667864" }}>Manage</button>
                  </td>
                </tr>
              ))}
              {!(data?.results||[]).length && (
                <tr><td colSpan={8} style={{ padding:48, textAlign:"center", color:"#667864", fontSize:13 }}>No bookings found.</td></tr>
              )}
            </tbody>
          </table></div>
        )}
      </div>

      {/* Booking detail + actions modal */}
      <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?`Booking ${selected.booking_number}`:""}
        footer={
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            <Button variant="ghost" onClick={()=>setSelected(null)}>Close</Button>
            {selected?.status==="pending"   && <Button onClick={()=>actionMutation.mutate({action:"confirm",  id:selected.id})}>Confirm</Button>}
            {selected?.status==="confirmed" && <Button onClick={()=>actionMutation.mutate({action:"activate", id:selected.id})}>Activate (Pickup)</Button>}
            {selected?.status==="active"    && <Button onClick={()=>actionMutation.mutate({action:"complete", id:selected.id})}>Complete (Return)</Button>}
            {["pending","confirmed"].includes(selected?.status) && <Button variant="danger" onClick={()=>{ const r=prompt("Cancellation reason:"); if(r) actionMutation.mutate({action:"cancel",id:selected.id,payload:{reason:r}}); }}>Cancel</Button>}
          </div>
        }>
        {selected && (
          <div style={{ fontSize:13 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
              {[
                ["Customer",      selected.customer_name],
                ["Vehicle",       selected.vehicle_name],
                ["Driver",        selected.driver_name||"Self Drive"],
                ["Status",        selected.status],
                ["Pickup",        selected.pickup_datetime?new Date(selected.pickup_datetime).toLocaleString("en-IN"):""],
                ["Return Due",    selected.return_datetime?new Date(selected.return_datetime).toLocaleString("en-IN"):""],
                ["Total Amount",  `₹${Number(selected.total_amount||0).toLocaleString()}`],
                ["Amount Paid",   `₹${Number(selected.amount_paid||0).toLocaleString()}`],
                ["Balance Due",   `₹${Number(selected.balance_due||0).toLocaleString()}`],
                ["Payment",       selected.payment_status],
              ].map(([l,v])=>(
                <div key={l} style={{ background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
                  <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{l}</div>
                  <div style={{ fontWeight:600, textTransform:"capitalize" }}>{v}</div>
                </div>
              ))}
            </div>
            {selected.is_overdue && (
              <div style={{ background:"#FEF2F2", border:"1px solid #FECACA", borderRadius:8, padding:"12px 14px", fontSize:13, color:"#991B1B" }}>
                ⚠️ <strong>Overdue by {selected.overdue_hours} hours.</strong> Late fee: ₹{(selected.overdue_hours||0)*100}
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* New booking modal */}
      <Modal open={showNew} onClose={()=>setShowNew(false)} title="Check Availability & Book">
        <StaffBookingForm onDone={()=>{toast.success("Booking request created.");setShowNew(false);}} />
      </Modal>
    </div>
  );
}

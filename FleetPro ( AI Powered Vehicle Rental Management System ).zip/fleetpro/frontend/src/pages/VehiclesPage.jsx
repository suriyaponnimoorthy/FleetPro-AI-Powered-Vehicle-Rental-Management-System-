import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { vehicleAPI } from "../utils/api";
import { StatusBadge, Card, CardHeader, Button, Modal, Input, Select } from "../components/ui/index";
import toast from "react-hot-toast";

const FUEL_COLORS = { petrol:"#527f73", diesel:"#173c32", electric:"#10B981", hybrid:"#7C3AED", cng:"#F59E0B" };

function VehicleCard({ v, onView }) {
  return (
    <div onClick={() => onView(v)} style={{
      background:"white", borderRadius:12, border:"1px solid #dce3d5",
      overflow:"hidden", cursor:"pointer", transition:"all .15s",
    }}
    onMouseEnter={e=>e.currentTarget.style.borderColor="#28543e"}
    onMouseLeave={e=>e.currentTarget.style.borderColor="#dce3d5"}>
      <div style={{ height:100, background:"linear-gradient(135deg,#f4f6ef,#E9EBF0)", display:"flex", alignItems:"center", justifyContent:"center", position:"relative", fontSize:40 }}>
        🚗
        <div style={{ position:"absolute", top:8, right:8 }}><StatusBadge status={v.status} /></div>
      </div>
      <div style={{ padding:"12px 14px" }}>
        <div style={{ fontSize:13, fontWeight:600, marginBottom:2 }}>{v.make} {v.model}</div>
        <div style={{ fontSize:11, color:"#667864", marginBottom:8 }}>{v.category_name} · {v.registration_number}</div>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:15, fontWeight:700 }}>
            ₹{Number(v.daily_rate).toLocaleString()} <span style={{ fontSize:11, fontWeight:400, color:"#667864" }}>/day</span>
          </div>
          <div style={{ fontSize:11, padding:"2px 8px", borderRadius:12, background: FUEL_COLORS[v.fuel_type]+"22", color: FUEL_COLORS[v.fuel_type], fontWeight:600, textTransform:"capitalize" }}>{v.fuel_type}</div>
        </div>
        <div style={{ display:"flex", gap:12, marginTop:8, fontSize:11, color:"#667864" }}>
          <span>⭐ {v.average_rating}</span>
          <span>🚗 {v.total_trips} trips</span>
          <span>💺 {v.seating_capacity} seats</span>
        </div>
      </div>
    </div>
  );
}

export default function VehiclesPage() {
  const qc = useQueryClient();
  const [filter, setFilter]    = useState("all");
  const [selected, setSelected] = useState(null);
  const [showAdd, setShowAdd]  = useState(false);
  const [search, setSearch]    = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["vehicles", filter],
    queryFn: () => vehicleAPI.list(filter !== "all" ? { status: filter } : {}).then(r => r.data),
  });

  const { data: cats }     = useQuery({ queryKey:["categories"], queryFn:()=>vehicleAPI.categories().then(r=>r.data) });
  const { data: branches } = useQuery({ queryKey:["branches"],   queryFn:()=>vehicleAPI.branches().then(r=>r.data) });

  const createMutation = useMutation({
    mutationFn: (d) => vehicleAPI.create(d).then(r=>r.data),
    onSuccess: () => { qc.invalidateQueries({queryKey: ["vehicles"]}); setShowAdd(false); toast.success("Vehicle added!"); },
    onError:   (e) => toast.error(e.response?.data?.error || "Failed to add vehicle"),
  });

  const vehicles = (data?.results || []).filter(v =>
    !search || `${v.make} ${v.model} ${v.registration_number}`.toLowerCase().includes(search.toLowerCase())
  );

  const FILTERS = ["all","available","rented","maintenance","reserved"];

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Fleet Management</h1>
        <Button onClick={() => setShowAdd(true)}>+ Add Vehicle</Button>
      </div>

      {/* Filters + Search */}
      <div style={{ display:"flex", gap:8, marginBottom:20, alignItems:"center", flexWrap:"wrap" }}>
        {FILTERS.map(f => (
          <button key={f} onClick={()=>setFilter(f)} style={{
            padding:"5px 14px", borderRadius:20, border:"1px solid",
            fontSize:12, fontWeight:500, cursor:"pointer", textTransform:"capitalize",
            background: filter===f ? "#28543e" : "white",
            borderColor: filter===f ? "#28543e" : "#dce3d5",
            color: filter===f ? "white" : "#667864",
          }}>{f}</button>
        ))}
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search make, model, reg…"
          style={{ marginLeft:"auto", padding:"6px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", width:220 }} />
      </div>

      {isLoading ? (
        <div style={{ textAlign:"center", padding:48, color:"#667864" }}>Loading fleet…</div>
      ) : (
        <>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))", gap:14 }}>
            {vehicles.map(v => <VehicleCard key={v.id} v={v} onView={setSelected} />)}
          </div>
          {vehicles.length === 0 && (
            <div style={{ textAlign:"center", padding:48, color:"#667864", fontSize:14 }}>
              No vehicles found{search ? ` for "${search}"` : ""}.
            </div>
          )}
        </>
      )}

      {/* Vehicle detail modal */}
      <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected ? `${selected.make} ${selected.model}` : ""}>
        {selected && (
          <div style={{ fontSize:13 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:16 }}>
              {[
                ["Registration", selected.registration_number],
                ["Status",       selected.status],
                ["Category",     selected.category_name],
                ["Branch",       selected.branch_name],
                ["Fuel Type",    selected.fuel_type],
                ["Transmission", selected.transmission],
                ["Seating",      `${selected.seating_capacity} seats`],
                ["Year",         selected.year],
                ["Daily Rate",   `₹${Number(selected.daily_rate).toLocaleString()}`],
                ["Deposit",      `₹${Number(selected.security_deposit_amount||0).toLocaleString()}`],
                ["Total Trips",  selected.total_trips],
                ["Rating",       `⭐ ${selected.average_rating}`],
              ].map(([l,v]) => (
                <div key={l} style={{ background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
                  <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{l}</div>
                  <div style={{ fontWeight:600, textTransform:"capitalize" }}>{v}</div>
                </div>
              ))}
            </div>
            {selected.features?.length > 0 && (
              <div>
                <div style={{ fontSize:12, fontWeight:600, color:"#667864", marginBottom:8 }}>FEATURES</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {selected.features.map(f => (
                    <span key={f} style={{ background:"#f4f6ef", border:"1px solid #dce3d5", borderRadius:6, padding:"3px 10px", fontSize:11 }}>{f}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Add vehicle modal */}
      <Modal open={showAdd} onClose={()=>setShowAdd(false)} title="Add New Vehicle"
        footer={<><Button variant="ghost" onClick={()=>setShowAdd(false)}>Cancel</Button><Button onClick={()=>{ const f=document.getElementById("addVehicleForm"); createMutation.mutate(Object.fromEntries(new FormData(f))); }}>Add Vehicle</Button></>}>
        <form id="addVehicleForm">
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            {[["registration_number","Registration No.","text"],["make","Make","text"],["model","Model","text"],["year","Year","number"],["color","Color","text"],["seating_capacity","Seats","number"]].map(([n,l,t]) => (
              <div key={n}>
                <label style={{ display:"block", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:5 }}>{l}</label>
                <input name={n} type={t} required style={{ width:"100%", padding:"8px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none" }} />
              </div>
            ))}
            <div>
              <label style={{ display:"block", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:5 }}>Category</label>
              <select name="category" required style={{ width:"100%", padding:"8px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", background:"white" }}>
                <option value="">Select…</option>
                {(cats?.results||cats||[]).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display:"block", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:5 }}>Branch</label>
              <select name="branch" required style={{ width:"100%", padding:"8px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", background:"white" }}>
                <option value="">Select…</option>
                {(branches?.results||branches||[]).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display:"block", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:5 }}>Fuel Type</label>
              <select name="fuel_type" required style={{ width:"100%", padding:"8px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", background:"white" }}>
                {["petrol","diesel","electric","hybrid","cng"].map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display:"block", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:5 }}>Transmission</label>
              <select name="transmission" style={{ width:"100%", padding:"8px 12px", border:"1px solid #dce3d5", borderRadius:8, fontSize:13, outline:"none", background:"white" }}>
                {["manual","automatic","cvt"].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
}

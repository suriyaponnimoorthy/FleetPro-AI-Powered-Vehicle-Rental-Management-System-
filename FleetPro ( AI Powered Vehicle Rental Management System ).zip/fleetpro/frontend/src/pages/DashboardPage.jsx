import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  CarFront,
  CalendarDays,
  IndianRupee,
  AlertTriangle,
  ArrowRight,
  Activity,
} from "lucide-react";
import { analyticsAPI, bookingAPI } from "../utils/api";
import { useAuth } from "../hooks/useAuth";
import CustomerPortal from "./CustomerPortal";
export const money = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(n || 0));
export default function DashboardPage() {
  const { isCustomer, isStaff } = useAuth();
  return isCustomer ? (
    <CustomerPortal />
  ) : isStaff ? (
    <Operations />
  ) : (
    <div className="page-heading">
      <p className="eyebrow">DRIVER WORKSPACE</p>
      <h1>Your next journey.</h1>
      <p>View your assigned journeys and return times.</p>
      <Link className="button" to="/bookings">
        Assigned bookings <ArrowRight size={18} />
      </Link>
    </div>
  );
}
function Operations() {
  const summary = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => analyticsAPI.dashboard().then((r) => r.data),
    refetchInterval: 60000,
  });
  const bookings = useQuery({
    queryKey: ["operations-recent"],
    queryFn: () =>
      bookingAPI
        .list({ ordering: "-created_at", page_size: 8 })
        .then((r) => r.data),
    refetchInterval: 60000,
  });
  const d = summary.data;
  if (summary.isLoading) return <p role="status">Connecting to your fleet…</p>;
  if (summary.isError)
    return (
      <div className="empty-state" role="alert">
        <h2>We couldn’t load the overview.</h2>
        <p>Check the API connection and try again.</p>
        <button className="button" onClick={() => summary.refetch()}>
          Retry
        </button>
      </div>
    );
  const stats = [
    [
      "Monthly revenue",
      money(d.revenue.this_month_revenue),
      IndianRupee,
      `${d.revenue.mom_change_pct}% vs previous month`,
    ],
    ["Active rentals", d.bookings.active, CarFront, "Currently on the road"],
    [
      "Pickups today",
      d.bookings.today_pickups,
      CalendarDays,
      `${d.bookings.today_returns} returns expected`,
    ],
    [
      "Overdue returns",
      d.overdue_bookings,
      AlertTriangle,
      "Review return times",
    ],
  ];
  const fleet = d.vehicles,
    total = fleet.total || 1;
  return (
    <>
      <div className="page-heading heading-row">
        <div>
          <p className="eyebrow">FLEET INTELLIGENCE / OVERVIEW</p>
          <h1>Everything in motion.</h1>
          <p>Your operation, at a glance.</p>
        </div>
        <div className="date-stamp">
          {new Date(d.generated_at).toLocaleDateString("en-IN", {
            weekday: "short",
            day: "numeric",
            month: "long",
          })}
          <small>
            Updated{" "}
            {new Date(d.generated_at).toLocaleTimeString("en-IN", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </small>
        </div>
      </div>
      <div className="metrics">
        {stats.map(([title, value, Icon, note]) => (
          <article key={title} className="metric">
            <div>
              <span>{title}</span>
              <Icon size={18} />
            </div>
            <strong>{value}</strong>
            <small>{note}</small>
          </article>
        ))}
      </div>
      <div className="operations-grid">
        <section className="panel fleet-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">FLEET PERFORMANCE</p>
              <h2>Ready for the road.</h2>
            </div>
            <Link to="/vehicles" className="text-link">
              View fleet <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="fleet-summary">
            <div
              className="utilization"
              style={{ "--util": `${fleet.utilization_pct}%` }}
            >
              <div>
                <strong>{fleet.utilization_pct}%</strong>
                <small>UTILIZATION</small>
              </div>
            </div>
            <div className="fleet-bars">
              {[
                ["available", "Available"],
                ["rented", "On the road"],
                ["reserved", "Reserved"],
                ["maintenance", "In service"],
              ].map(([key, label]) => (
                <div key={key}>
                  <div>
                    <span>{label}</span>
                    <strong>{fleet[key]}</strong>
                  </div>
                  <progress aria-label={label} max={total} value={fleet[key]} />
                </div>
              ))}
            </div>
          </div>
          <div className="panel-bottom">
            <span>{fleet.total} vehicles in the fleet</span>
            <span>{d.customers.verified} verified customers</span>
          </div>
        </section>
        <section className="intelligence-panel">
          <span className="mini-icon">
            <Activity size={21} />
          </span>
          <p className="eyebrow">OPERATIONS BRIEF</p>
          <h2>
            Focus on what
            <br />
            moves you forward.
          </h2>
          <p>
            {d.overdue_bookings
              ? `${d.overdue_bookings} overdue return(s) need review.`
              : "No overdue returns in the current snapshot."}
          </p>
          <p>
            {d.bookings.pending} booking requests await confirmation.{" "}
            {d.penalties.pending_count} penalties remain pending.
          </p>
          <Link className="button" to="/bookings">
            Review bookings <ArrowRight size={16} />
          </Link>
          <small>Derived from operational data · refreshed every minute</small>
        </section>
      </div>
      <section className="panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">JOURNEY MONITOR</p>
            <h2>Latest reservations</h2>
          </div>
          <Link to="/bookings" className="text-link">
            All bookings <ArrowUpRight size={16} />
          </Link>
        </div>
        <div className="table-scroll">
          {bookings.isError ? (
            <p role="alert">
              Reservations unavailable.{" "}
              <button onClick={() => bookings.refetch()}>Retry</button>
            </p>
          ) : (
            <table className="premium-table">
              <thead>
                <tr>
                  {[
                    "Reservation",
                    "Guest",
                    "Vehicle",
                    "Pickup",
                    "Amount",
                    "Status",
                  ].map((x) => (
                    <th key={x}>{x}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(bookings.data?.results || []).slice(0, 8).map((b) => (
                  <tr key={b.id}>
                    <td>
                      <Link to="/bookings">{b.booking_number}</Link>
                    </td>
                    <td>{b.customer_name}</td>
                    <td>{b.vehicle_name}</td>
                    <td>
                      {new Date(b.pickup_datetime).toLocaleDateString("en-IN")}
                    </td>
                    <td>{money(b.total_amount)}</td>
                    <td>
                      <span className={`pill ${b.status}`}>{b.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {!bookings.isLoading &&
            !bookings.isError &&
            !bookings.data?.results?.length && (
              <p className="empty-state">
                No reservations yet. Your latest journeys will appear here.
              </p>
            )}
        </div>
      </section>
    </>
  );
}

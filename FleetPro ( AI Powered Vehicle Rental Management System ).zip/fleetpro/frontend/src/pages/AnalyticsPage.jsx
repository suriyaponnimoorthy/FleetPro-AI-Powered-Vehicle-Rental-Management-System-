import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { analyticsAPI } from "../utils/api";
import { money } from "./DashboardPage";
export default function AnalyticsPage() {
  const [year, setYear] = useState(new Date().getFullYear());
  const q = useQuery({
      queryKey: ["revenue", year],
      queryFn: () => analyticsAPI.revenue(year).then((r) => r.data),
    }),
    branches = useQuery({
      queryKey: ["revenue-by-branch"],
      queryFn: () => analyticsAPI.byBranch().then((r) => r.data),
    });
  const rows = q.data?.monthly_breakdown || [],
    max = Math.max(1, ...rows.map((x) => Number(x.gross_revenue)));
  return (
    <>
      <div className="page-heading heading-row">
        <div>
          <p className="eyebrow">BUSINESS INTELLIGENCE</p>
          <h1>A clearer view of growth.</h1>
          <p>
            Recorded successful rental payments. Deposits and refunds require
            separate reconciliation.
          </p>
        </div>
        <label>
          Reporting year{" "}
          <select
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
          >
            {Array.from(
              { length: 6 },
              (_, i) => new Date().getFullYear() - i,
            ).map((y) => (
              <option key={y}>{y}</option>
            ))}
          </select>
        </label>
      </div>
      <section className="panel">
        <div className="panel-heading">
          <h2>Monthly rental revenue</h2>
          <strong>
            {money(rows.reduce((n, r) => n + Number(r.gross_revenue), 0))}
          </strong>
        </div>
        {q.isLoading ? (
          <p className="empty-state" role="status">
            Loading revenue…
          </p>
        ) : q.isError ? (
          <p className="empty-state" role="alert">
            Revenue unavailable.{" "}
            <button onClick={() => q.refetch()}>Retry</button>
          </p>
        ) : !rows.length ? (
          <p className="empty-state">No recorded revenue for this year.</p>
        ) : (
          <div style={{ padding: 25 }}>
            {rows.map((r) => (
              <div key={r.month} style={{ marginBottom: 18 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: 12,
                    marginBottom: 8,
                  }}
                >
                  <span>
                    {new Date(r.month).toLocaleDateString("en-IN", {
                      month: "long",
                    })}
                  </span>
                  <strong>{money(r.gross_revenue)}</strong>
                </div>
                <progress
                  aria-label={`Revenue ${r.month}`}
                  max={max}
                  value={Number(r.gross_revenue)}
                />
              </div>
            ))}
          </div>
        )}
      </section>
      <section className="panel" style={{ marginTop: 25 }}>
        <div className="panel-heading">
          <h2>Revenue by branch · all time</h2>
        </div>
        {branches.isError ? (
          <p className="empty-state" role="alert">
            Branch revenue unavailable.
          </p>
        ) : (
          <div className="table-scroll">
            <table className="premium-table">
              <thead>
                <tr>
                  <th>Branch</th>
                  <th>Recorded rental revenue</th>
                </tr>
              </thead>
              <tbody>
                {(branches.data?.branches || []).map((r) => (
                  <tr key={r.branch}>
                    <td>{r.branch}</td>
                    <td>{money(r.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!branches.isLoading && !branches.data?.branches?.length && (
              <p className="empty-state">No branch revenue yet.</p>
            )}
          </div>
        )}
      </section>
    </>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { damageAPI } from "../utils/api";
import { StatusBadge, StatCard, Button, Modal, Card, CardHeader } from "../components/ui/index";
import toast from "react-hot-toast";

const SEV_COLOR = { minor:"#527f73", moderate:"#F59E0B", major:"#EF4444", total_loss:"#7C3AED" };

export default function DamagePage() {
  const qc = useQueryClient();
  const [tab, setTab] = useState("damage");
  const [selected, setSelected] = useState(null);

  const { data: reports, isLoading: rLoading } = useQuery({
    queryKey:["damage"], queryFn:()=>damageAPI.list().then(r=>r.data),
  });
  const { data: penalties, isLoading: pLoading } = useQuery({
    queryKey:["penalties"], queryFn:()=>damageAPI.penalties().then(r=>r.data),
  });

  const closeMutation = useMutation({
    mutationFn: ({id,data})=>damageAPI.close(id,data),
    onSuccess:()=>{ qc.invalidateQueries({queryKey: ["damage"]}); toast.success("Report closed"); setSelected(null); },
  });
  const waiveMutation = useMutation({
    mutationFn:({id,reason})=>damageAPI.waiverPenalty(id,{reason}),
    onSuccess:()=>{ qc.invalidateQueries({queryKey: ["penalties"]}); toast.success("Penalty waived"); },
  });

  const openCount   = (reports?.results||[]).filter(r=>r.status!=="closed").length;
  const totalFines  = (penalties?.results||[]).filter(p=>p.status==="pending").reduce((s,p)=>s+Number(p.amount||0),0);
  const insuranceCnt= (reports?.results||[]).filter(r=>r.is_insurance_claimed).length;

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Damage & Fines</h1>
        <Button>+ New Report</Button>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, marginBottom:24 }}>
        <StatCard label="Open Reports"     value={openCount}                          icon="📋" color="#EF4444" />
        <StatCard label="Pending Fines"    value={`₹${totalFines.toLocaleString()}`} icon="⚠️" color="#F59E0B" />
        <StatCard label="Insurance Claims" value={insuranceCnt}                       icon="🛡️" color="#7C3AED" />
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid #dce3d5", marginBottom:20 }}>
        {[["damage","Damage Reports"],["penalties","Penalties & Fines"]].map(([k,l])=>(
          <div key={k} onClick={()=>setTab(k)} style={{
            padding:"10px 18px", fontSize:13, fontWeight:500, cursor:"pointer",
            borderBottom: tab===k ? "2px solid #28543e" : "2px solid transparent",
            marginBottom:-1, color: tab===k ? "#28543e" : "#667864",
          }}>{l}</div>
        ))}
      </div>

      {tab==="damage" && (
        <Card>
          <CardHeader title="Damage Reports" />
          {rLoading ? (
            <div style={{ padding:48, textAlign:"center", color:"#667864" }}>Loading…</div>
          ) : (
            <div style={{ padding:"0 0" }}>
              {(reports?.results||[]).map(r => (
                <div key={r.id} onClick={()=>setSelected(r)} style={{ display:"flex", gap:14, padding:"16px 20px", borderBottom:"1px solid #F3F4F6", cursor:"pointer", alignItems:"flex-start" }}
                  onMouseEnter={e=>e.currentTarget.style.background="#FAFAFA"}
                  onMouseLeave={e=>e.currentTarget.style.background="white"}>
                  <div style={{ width:44, height:44, borderRadius:10, background:"#FEF2F2", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>⚠️</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:600, marginBottom:2 }}>{r.vehicle_name} — {r.vehicle_reg}</div>
                    <div style={{ fontSize:12, color:"#667864", marginBottom:6 }}>{r.damage_type} · {r.damage_location}</div>
                    <div style={{ fontSize:12, color:"#667864" }}>{r.description?.slice(0,100)}{r.description?.length>100?"…":""}</div>
                  </div>
                  <div style={{ textAlign:"right", flexShrink:0 }}>
                    <div style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:15, fontWeight:700, color:"#EF4444", marginBottom:6 }}>₹{Number(r.estimated_repair_cost||0).toLocaleString()}</div>
                    <div style={{ marginBottom:4 }}><StatusBadge status={r.severity} /></div>
                    <div><StatusBadge status={r.status} /></div>
                  </div>
                </div>
              ))}
              {!(reports?.results||[]).length && (
                <div style={{ padding:48, textAlign:"center", color:"#667864", fontSize:13 }}>No damage reports.</div>
              )}
            </div>
          )}
        </Card>
      )}

      {tab==="penalties" && (
        <Card>
          <CardHeader title="Penalties & Fines" />
          {pLoading ? (
            <div style={{ padding:48, textAlign:"center", color:"#667864" }}>Loading…</div>
          ) : (
            <div className="table-scroll"><table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:"#f4f6ef" }}>
                  {["Booking","Customer","Type","Amount","Status","Date","Actions"].map(h=>(
                    <th key={h} style={{ padding:"10px 16px", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", textAlign:"left", borderBottom:"1px solid #dce3d5" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(penalties?.results||[]).map(p=>(
                  <tr key={p.id} style={{ borderBottom:"1px solid #F3F4F6" }}>
                    <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>{p.booking_number}</td>
                    <td style={{ padding:"12px 16px", fontSize:13 }}>{p.customer_name}</td>
                    <td style={{ padding:"12px 16px" }}><StatusBadge status={p.penalty_type?.replace("_"," ")} /></td>
                    <td style={{ padding:"12px 16px", fontSize:13, fontWeight:700, color:"#EF4444" }}>₹{Number(p.amount||0).toLocaleString()}</td>
                    <td style={{ padding:"12px 16px" }}><StatusBadge status={p.status} /></td>
                    <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>{p.created_at?new Date(p.created_at).toLocaleDateString("en-IN"):""}</td>
                    <td style={{ padding:"12px 16px" }}>
                      {p.status==="pending" && (
                        <button onClick={()=>{ const r=prompt("Waiver reason:"); if(r) waiveMutation.mutate({id:p.id,reason:r}); }}
                          style={{ padding:"3px 10px", border:"1px solid #dce3d5", borderRadius:6, background:"none", cursor:"pointer", fontSize:11, color:"#667864" }}>Waive</button>
                      )}
                    </td>
                  </tr>
                ))}
                {!(penalties?.results||[]).length && (
                  <tr><td colSpan={7} style={{ padding:48, textAlign:"center", color:"#667864", fontSize:13 }}>No penalties found.</td></tr>
                )}
              </tbody>
            </table></div>
          )}
        </Card>
      )}

      <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?`${selected.report_number} — ${selected.damage_type}`:""}
        footer={<>
          <Button variant="ghost" onClick={()=>setSelected(null)}>Close</Button>
          {selected?.status!=="closed" && (
            <Button variant="danger" onClick={()=>{ const cost=prompt("Actual repair cost:"); if(cost) closeMutation.mutate({id:selected.id,data:{actual_repair_cost:cost,resolution_notes:"Resolved"}}); }}>Close Report</Button>
          )}
        </>}>
        {selected && (
          <div style={{ fontSize:13, display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
            {[
              ["Vehicle",       selected.vehicle_name],
              ["Registration",  selected.vehicle_reg],
              ["Customer",      selected.customer_name],
              ["Severity",      selected.severity],
              ["Status",        selected.status],
              ["Damage Type",   selected.damage_type],
              ["Location",      selected.damage_location],
              ["Est. Cost",     `₹${Number(selected.estimated_repair_cost||0).toLocaleString()}`],
              ["Actual Cost",   selected.actual_repair_cost?`₹${Number(selected.actual_repair_cost).toLocaleString()}`:"TBD"],
              ["Insurance",     selected.is_insurance_claimed?"Claimed":"Not claimed"],
            ].map(([l,v])=>(
              <div key={l} style={{ background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
                <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{l}</div>
                <div style={{ fontWeight:600, textTransform:"capitalize" }}>{v}</div>
              </div>
            ))}
            <div style={{ gridColumn:"1/-1", background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
              <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>Description</div>
              <div>{selected.description}</div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

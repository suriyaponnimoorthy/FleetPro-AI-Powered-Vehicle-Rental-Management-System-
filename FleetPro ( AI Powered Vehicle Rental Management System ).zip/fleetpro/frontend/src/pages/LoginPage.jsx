import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { useAuth } from "../hooks/useAuth";
export default function LoginPage() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" }),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(form.email, form.password);
      nav("/");
    } catch (e) {
      setError(
        e.response?.data?.error ||
          "Unable to sign in. Check your credentials and API connection.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="login-shell">
      <section className="login-image">
        <div className="wordmark">
          <span className="brand-mark">F</span>FleetPro
        </div>
        <div>
          <p className="eyebrow">A MORE CONSIDERED WAY TO MOVE</p>
          <h1>
            Extraordinary journeys.
            <br />
            <em>Seamlessly managed.</em>
          </h1>
          <p>
            One collection. Two perspectives.
            <br />A world of possibility.
          </p>
        </div>
        <small>THE FLEETPRO COLLECTION</small>
      </section>
      <main className="login-main">
        <div>
          <p className="eyebrow">WELCOME TO FLEETPRO</p>
          <h2>Your journey starts here.</h2>
          <p>Sign in to your personal collection or operations workspace.</p>
          {error && (
            <p role="alert" className="error-banner">
              {error}
            </p>
          )}
          <form onSubmit={submit}>
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              type="email"
              autoComplete="username"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <button className="button" disabled={busy}>
              {busy ? "Signing in…" : "Enter your workspace"}
              <ArrowRight size={17} />
            </button>
          </form>
          <p className="login-note">
            Need an account or help signing in? Contact your FleetPro
            administrator.
          </p>
        </div>
      </main>
    </div>
  );
}

import GatewayPayments from "../components/GatewayPayments";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { paymentAPI } from "../utils/api";
import { StatCard, StatusBadge, Card, CardHeader } from "../components/ui/index";
import toast from "react-hot-toast";

const METHOD_ICON = { upi:"📱", card:"💳", net_banking:"🏦", cash:"💵", bank_transfer:"🔄", wallet:"👛" };

export default function PaymentsPage() {
  const [filter, setFilter] = useState("all");

  const { data: summary } = useQuery({ queryKey:["paymentSummary"], queryFn:()=>paymentAPI.summary().then(r=>r.data) });
  const { data, isLoading } = useQuery({
    queryKey:["payments",filter],
    queryFn:()=>paymentAPI.list(filter!=="all"?{status:filter}:{}).then(r=>r.data),
  });

  const downloadInvoice = async (bookingId) => {
    try {
      const r = await paymentAPI.invoices({ booking: bookingId });
      const inv = (r.data?.results||r.data||[])[0];
      if (!inv) { toast.error("Invoice not found"); return; }
      const pdf = await paymentAPI.downloadPDF(inv.id);
      const url = URL.createObjectURL(new Blob([pdf.data], { type:"application/pdf" }));
      const a = document.createElement("a"); a.href=url; a.download=`invoice-${inv.invoice_number}.pdf`; a.click();
    } catch { toast.error("Failed to download invoice"); }
  };

  return (
    <div>
      <GatewayPayments/>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Payments & Billing</h1>
        <button style={{ padding:"7px 16px", background:"#173c32", color:"white", border:"none", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Export CSV</button>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:16, marginBottom:24 }}>
        <StatCard label="Today's Collection" value={`₹${Number(summary?.today_total||0).toLocaleString()}`} icon="💰" color="#10B981" />
        <StatCard label="Monthly Revenue"    value={`₹${Number(summary?.month_total||0).toLocaleString()}`} icon="📈" color="#28543e" />
        <StatCard label="Today Transactions" value={summary?.today_count||0} icon="🔄" color="#527f73" />
        <StatCard label="Pending Refunds"    value={summary?.pending_refunds||0} icon="↩️" color="#7C3AED" />
      </div>

      <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:20 }}>
        {["all","success","pending","failed","refunded"].map(s => (
          <button key={s} onClick={()=>setFilter(s)} style={{
            padding:"5px 14px", borderRadius:20, border:"1px solid",
            fontSize:12, fontWeight:500, cursor:"pointer", textTransform:"capitalize",
            background:filter===s?"#28543e":"white", borderColor:filter===s?"#28543e":"#dce3d5",
            color:filter===s?"white":"#667864",
          }}>{s}</button>
        ))}
      </div>

      <div style={{ background:"white", borderRadius:12, border:"1px solid #dce3d5", overflow:"hidden" }}>
        {isLoading ? (
          <div style={{ padding:48, textAlign:"center", color:"#667864" }}>Loading payments…</div>
        ) : (
          <div className="table-scroll"><table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:"#f4f6ef" }}>
                {["Txn ID","Customer","Booking","Type","Method","Amount","Status","Date",""].map(h => (
                  <th key={h} style={{ padding:"10px 16px", fontSize:11, fontWeight:600, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", textAlign:"left", borderBottom:"1px solid #dce3d5" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(data?.results||[]).map(p => (
                <tr key={p.id} style={{ borderBottom:"1px solid #F3F4F6" }}>
                  <td style={{ padding:"12px 16px", fontSize:12, color:"#667864", fontFamily:"monospace" }}>{p.transaction_id?.slice(-12)}</td>
                  <td style={{ padding:"12px 16px", fontSize:13 }}>{p.customer_name}</td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>{p.booking_number}</td>
                  <td style={{ padding:"12px 16px" }}><StatusBadge status={p.payment_type?.replace("_"," ")} /></td>
                  <td style={{ padding:"12px 16px", fontSize:13 }}>{METHOD_ICON[p.method]||"💳"} {p.method}</td>
                  <td style={{ padding:"12px 16px", fontSize:13, fontWeight:700, color: p.payment_type==="refund"?"#EF4444":"#173c32" }}>
                    {p.payment_type==="refund"?"-":""}₹{Number(p.amount||0).toLocaleString()}
                  </td>
                  <td style={{ padding:"12px 16px" }}><StatusBadge status={p.status} /></td>
                  <td style={{ padding:"12px 16px", fontSize:12, color:"#667864" }}>
                    {p.paid_at ? new Date(p.paid_at).toLocaleDateString("en-IN",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}) : "—"}
                  </td>
                  <td style={{ padding:"12px 16px" }}>
                    <button onClick={()=>downloadInvoice(p.booking)} style={{ padding:"3px 10px", border:"1px solid #dce3d5", borderRadius:6, background:"none", cursor:"pointer", fontSize:11, color:"#667864" }}>PDF</button>
                  </td>
                </tr>
              ))}
              {!(data?.results||[]).length && (
                <tr><td colSpan={9} style={{ padding:48, textAlign:"center", color:"#667864", fontSize:13 }}>No payments found.</td></tr>
              )}
            </tbody>
          </table></div>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { driverAPI } from "../utils/api";
import { Card, CardHeader, Button, Modal, StatusBadge } from "../components/ui/index";

function Stars({ rating }) {
  return (
    <div style={{ display:"flex", gap:2 }}>
      {[1,2,3,4,5].map(i => (
        <span key={i} style={{ color: i<=Math.round(rating) ? "#F59E0B" : "#dce3d5", fontSize:12 }}>★</span>
      ))}
      <span style={{ fontSize:11, color:"#667864", marginLeft:4 }}>{Number(rating).toFixed(1)}</span>
    </div>
  );
}

export default function DriversPage() {
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(null);
  const [perf, setPerf] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ["drivers", filter],
    queryFn: () => driverAPI.list(filter !== "all" ? { availability_status:filter } : {}).then(r=>r.data),
  });

  const openPerf = async (d) => {
    setSelected(d);
    try { const r = await driverAPI.performance(d.id); setPerf(r.data); } catch {}
  };

  const STATUS_COLOR = { available:"#10B981", on_duty:"#527f73", on_leave:"#F59E0B", inactive:"#667864" };

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:22, fontWeight:700, color:"#173c32" }}>Driver Management</h1>
        <Button>+ Add Driver</Button>
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {["all","available","on_duty","on_leave","inactive"].map(s => (
          <button key={s} onClick={()=>setFilter(s)} style={{
            padding:"5px 14px", borderRadius:20, border:"1px solid",
            fontSize:12, fontWeight:500, cursor:"pointer", textTransform:"capitalize",
            background:filter===s?"#28543e":"white", borderColor:filter===s?"#28543e":"#dce3d5",
            color:filter===s?"white":"#667864",
          }}>{s.replace("_"," ")}</button>
        ))}
      </div>

      {isLoading ? (
        <div style={{ textAlign:"center", padding:48, color:"#667864" }}>Loading drivers…</div>
      ) : (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))", gap:14 }}>
          {(data?.results||data||[]).map(d => (
            <div key={d.id} onClick={()=>openPerf(d)} style={{
              background:"white", border:"1px solid #dce3d5", borderRadius:12, padding:16,
              display:"flex", gap:14, cursor:"pointer", transition:"all .15s",
            }}
            onMouseEnter={e=>e.currentTarget.style.boxShadow="0 4px 14px rgba(0,0,0,.07)"}
            onMouseLeave={e=>e.currentTarget.style.boxShadow="none"}>
              <div style={{ width:44, height:44, borderRadius:"50%", background:"linear-gradient(135deg,#28543e,#527f73)", display:"flex", alignItems:"center", justifyContent:"center", color:"white", fontWeight:700, fontSize:15, flexShrink:0 }}>
                {(d.full_name||"").split(" ").map(n=>n[0]).join("").toUpperCase().slice(0,2)}
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:14, fontWeight:600, marginBottom:2 }}>{d.full_name}</div>
                <div style={{ fontSize:12, color:"#667864", marginBottom:6 }}>ID: {d.employee_id} · {d.branch_city}</div>
                <Stars rating={d.average_rating} />
                <div style={{ display:"flex", gap:14, marginTop:8 }}>
                  <div style={{ fontSize:11, color:"#667864" }}><strong style={{ color:"#173c32" }}>{d.total_trips}</strong> trips</div>
                  <div style={{ fontSize:11, color:"#667864" }}><strong style={{ color:"#173c32" }}>{d.experience_years}</strong> yrs exp</div>
                  <div style={{ fontSize:11 }}>
                    <span style={{ color:STATUS_COLOR[d.availability_status]||"#667864", fontWeight:600, textTransform:"capitalize" }}>
                      ● {d.availability_status?.replace("_"," ")}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {(data?.results||data||[]).length === 0 && (
            <div style={{ gridColumn:"1/-1", textAlign:"center", padding:48, color:"#667864", fontSize:14 }}>No drivers found.</div>
          )}
        </div>
      )}

      <Modal open={!!selected} onClose={()=>{setSelected(null);setPerf(null);}} title={selected?.full_name||""}>
        {selected && (
          <div style={{ fontSize:13 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
              {[
                ["Employee ID",  selected.employee_id],
                ["Branch",       selected.branch_name],
                ["Email",        selected.email],
                ["Phone",        selected.phone||"—"],
                ["Experience",   `${selected.experience_years} yrs`],
                ["Daily Rate",   `₹${Number(selected.daily_rate).toLocaleString()}`],
                ["Monthly Salary",`₹${Number(selected.monthly_salary||0).toLocaleString()}`],
                ["License Valid", selected.is_license_valid ? "✅ Yes" : "❌ No"],
              ].map(([l,v]) => (
                <div key={l} style={{ background:"#f4f6ef", borderRadius:8, padding:"10px 12px" }}>
                  <div style={{ fontSize:10, color:"#667864", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{l}</div>
                  <div style={{ fontWeight:600 }}>{v}</div>
                </div>
              ))}
            </div>
            {perf && (
              <div style={{ background:"#f4f6ef", borderRadius:10, padding:14 }}>
                <div style={{ fontSize:12, fontWeight:600, color:"#667864", marginBottom:10 }}>PERFORMANCE THIS MONTH</div>
                <div style={{ display:"flex", gap:16 }}>
                  {[
                    ["Trips", perf.trips_this_month||0],
                    ["Earnings", `₹${Number(perf.earnings_this_month||0).toLocaleString()}`],
                    ["Rating", `⭐ ${perf.overall_rating||0}`],
                    ["Violations", perf.total_violations||0],
                  ].map(([l,v]) => (
                    <div key={l} style={{ textAlign:"center" }}>
                      <div style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:18, fontWeight:700, color:"#173c32" }}>{v}</div>
                      <div style={{ fontSize:11, color:"#667864" }}>{l}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

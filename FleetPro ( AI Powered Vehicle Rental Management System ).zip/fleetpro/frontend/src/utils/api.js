// frontend/src/utils/api.js
// Axios instance with JWT auto-refresh, error handling, and request logging

import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "/api/v1";

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
});

// Access credentials live in memory. Refresh credentials stay in an HttpOnly cookie.
let accessToken = null;
let refreshRequest;

export function setAccessToken(token) {
  accessToken = token;
}

async function browserAuth(path, body = {}) {
  const { data } = await axios.get(`${BASE_URL}/auth/csrf/`, { withCredentials: true });
  return axios.post(`${BASE_URL}/auth/${path}/`, body, {
    withCredentials: true,
    headers: { "X-CSRFToken": data.csrfToken, "X-FleetPro-Browser": "1" },
  });
}

function withSessionLock(operation) {
  return navigator.locks ? navigator.locks.request("fleetpro-session", operation) : operation();
}

export function refreshSession() {
  if (!refreshRequest) {
    refreshRequest = withSessionLock(async () => {
      const { data } = await browserAuth("token/refresh");
      setAccessToken(data.access);
    }).finally(() => { refreshRequest = undefined; });
  }
  return refreshRequest;
}

api.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status !== 401 || !original?.headers?.Authorization || original._retry) {
      throw error;
    }
    original._retry = true;
    try {
      if (original.headers.Authorization === `Bearer ${accessToken}`) await refreshSession();
    } catch (refreshError) {
      setAccessToken(null);
      window.location.assign("/login");
      throw refreshError;
    }
    return api(original);
  }
);

// ── API modules ───────────────────────────────────────────────

export const authAPI = {
  login:          (data) => withSessionLock(() => browserAuth("login", data)),
  register:       (data) => api.post("/auth/register/", data),
  logout:         () => withSessionLock(() => browserAuth("logout")),
  getProfile:     () => api.get("/auth/profile/"),
  updateProfile:  (data) => api.patch("/auth/profile/", data),
  changePassword: (data) => api.post("/auth/change-password/", data),
  forgotPassword: (email) => api.post("/auth/forgot-password/", { email }),
  resetPassword:  (data) => api.post("/auth/reset-password/", data),
  sendOTP:        (type) => api.post("/auth/send-otp/", { otp_type: type }),
  verifyOTP:      (data) => api.post("/auth/verify-otp/", data),
};

export const vehicleAPI = {
  list:         (params) => api.get("/vehicles/", { params }),
  get:          (id) => api.get(`/vehicles/${id}/`),
  create:       (data) => api.post("/vehicles/", data),
  update:       (id, data) => api.patch(`/vehicles/${id}/`, data),
  delete:       (id) => api.delete(`/vehicles/${id}/`),
  checkAvail:   (id, params) => api.get(`/vehicles/${id}/availability/`, { params }),
  uploadImage:  (id, formData) => api.post(`/vehicles/${id}/images/`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  }),
  fleetStats:   () => api.get("/vehicles/fleet-stats/"),
  categories:   (params) => api.get("/vehicle-categories/", { params }),
  branches:     (params) => api.get("/branches/", { params }),
  maintenance:  (params) => api.get("/maintenance/", { params }),
  completeMaint:(id, data) => api.post(`/maintenance/${id}/complete/`, data),
  insurance:    (params) => api.get("/insurance/", { params }),
  expiringIns:  () => api.get("/insurance/expiring-soon/"),
};

export const bookingAPI = {
  list:         (params) => api.get("/bookings/", { params }),
  get:          (id) => api.get(`/bookings/${id}/`),
  create:       (data) => api.post("/bookings/", data),
  update:       (id, data) => api.patch(`/bookings/${id}/`, data),
  checkAvail:   (data) => api.post("/bookings/check-availability/", data),
  confirm:      (id) => api.post(`/bookings/${id}/confirm/`),
  activate:     (id, data) => api.post(`/bookings/${id}/activate/`, data),
  complete:     (id, data) => api.post(`/bookings/${id}/complete/`, data),
  cancel:       (id, data) => api.post(`/bookings/${id}/cancel/`, data),
  inspection:   (id, data) => api.post(`/bookings/${id}/inspection/`, data),
  review:       (id, data) => api.post(`/bookings/${id}/review/`, data),
};

export const driverAPI = {
  list:       (params) => api.get("/drivers/", { params }),
  get:        (id) => api.get(`/drivers/${id}/`),
  create:     (data) => api.post("/drivers/", data),
  update:     (id, data) => api.patch(`/drivers/${id}/`, data),
  available:  (params) => api.get("/drivers/available/", { params }),
  performance:(id) => api.get(`/drivers/${id}/performance/`),
  toggleAvail:(id, data) => api.post(`/drivers/${id}/toggle-availability/`, data),
  attendance: (params) => api.get("/driver-attendance/", { params }),
};

export const customerAPI = {
  list:        (params) => api.get("/customers/", { params }),
  get:         (id) => api.get(`/customers/${id}/`),
  update:      (id, data) => api.patch(`/customers/${id}/`, data),
  verifyKYC:   (id) => api.post(`/customers/${id}/verify-kyc/`),
  rejectKYC:   (id, data) => api.post(`/customers/${id}/reject-kyc/`, data),
  blacklist:   (id, data) => api.post(`/customers/${id}/blacklist/`, data),
  unblacklist: (id) => api.post(`/customers/${id}/unblacklist/`),
  bookings:    (id) => api.get(`/customers/${id}/bookings/`),
  stats:       (id) => api.get(`/customers/${id}/stats/`),
};

export const paymentAPI = {
  list:       (params) => api.get("/payments/", { params }),
  get:        (id) => api.get(`/payments/${id}/`),
  create:     (data) => api.post("/payments/", data),
  refund:     (id, data) => api.post(`/payments/${id}/refund/`, data),
  summary:    () => api.get("/payments/summary/"),
  invoices:   (params) => api.get("/invoices/", { params }),
  downloadPDF:(id) => api.get(`/invoices/${id}/download-pdf/`, { responseType: "blob" }),
};

export const damageAPI = {
  list:          (params) => api.get("/damage-reports/", { params }),
  get:           (id) => api.get(`/damage-reports/${id}/`),
  create:        (data) => api.post("/damage-reports/", data),
  update:        (id, data) => api.patch(`/damage-reports/${id}/`, data),
  close:         (id, data) => api.post(`/damage-reports/${id}/close/`, data),
  claimInsurance:(id, data) => api.post(`/damage-reports/${id}/claim-insurance/`, data),
  penalties:     (params) => api.get("/penalties/", { params }),
  waiverPenalty: (id, data) => api.post(`/penalties/${id}/waive/`, data),
};

export const analyticsAPI = {
  dashboard:    () => api.get("/analytics/dashboard/"),
  revenue:      (year) => api.get(`/analytics/revenue/monthly/?year=${year}`),
  byBranch:     () => api.get("/analytics/revenue/by-branch/"),
  utilization:  (params) => api.get("/analytics/vehicles/utilization/", { params }),
  topCustomers: (limit) => api.get(`/analytics/customers/top/?limit=${limit || 10}`),
  trends:       (params) => api.get("/analytics/bookings/trends/", { params }),
  driverPerf:   () => api.get("/analytics/drivers/performance/"),
};

export const notificationAPI = {
  list:       (params) => api.get("/notifications/", { params }),
  markRead:   (id) => api.post(`/notifications/${id}/mark-read/`),
  markAllRead:() => api.post("/notifications/mark-all-read/"),
};

export default api;

// frontend/src/main.jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Toaster } from "react-hot-toast";
import App from "./App.jsx";
import "./index.css";
import "./premium.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
    <Toaster
      position="top-right"
      toastOptions={{
        duration: 4000,
        style: {
          fontFamily: "'DM Sans', sans-serif",
          fontSize: 13,
          borderRadius: 8,
        },
        success: { iconTheme: { primary: "#10B981", secondary: "white" } },
        error:   { iconTheme: { primary: "#EF4444", secondary: "white" } },
      }}
    />
  </StrictMode>
);

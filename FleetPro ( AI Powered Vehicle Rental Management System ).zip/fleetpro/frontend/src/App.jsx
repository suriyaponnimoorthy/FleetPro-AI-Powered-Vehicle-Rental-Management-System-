// frontend/src/App.jsx — Root component with routing
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import Layout from "./components/Layout";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import MyJourneys from "./pages/MyJourneys";
import BookingsPage from "./pages/BookingsPage";
import VehiclesPage from "./pages/VehiclesPage";
import DriversPage from "./pages/DriversPage";
import CustomersPage from "./pages/CustomersPage";
import PaymentsPage from "./pages/PaymentsPage";
import DamagePage from "./pages/DamagePage";
import AnalyticsPage from "./pages/AnalyticsPage";
import SettingsPage from "./pages/SettingsPage";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1 },
  },
});

function BookingArea() {
  const { isCustomer } = useAuth();
  return isCustomer ? <MyJourneys /> : <BookingsPage />;
}

function ProtectedRoute({ children, roles }) {
  const { user, isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user?.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              <Route index element={<DashboardPage />} />
              <Route path="bookings/*" element={<BookingArea />} />
              <Route
                path="vehicles/*"
                element={
                  <ProtectedRoute roles={["super_admin", "admin", "staff"]}>
                    <VehiclesPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="drivers/*"
                element={
                  <ProtectedRoute roles={["super_admin", "admin", "staff"]}>
                    <DriversPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="customers/*"
                element={
                  <ProtectedRoute roles={["super_admin", "admin", "staff"]}>
                    <CustomersPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="payments/*"
                element={
                  <ProtectedRoute roles={["super_admin", "admin", "staff"]}>
                    <PaymentsPage />
                  </ProtectedRoute>
                }
              />
              <Route path="damage/*" element={<DamagePage />} />
              <Route
                path="analytics/*"
                element={
                  <ProtectedRoute roles={["super_admin", "admin"]}>
                    <AnalyticsPage />
                  </ProtectedRoute>
                }
              />
              <Route path="settings/*" element={<SettingsPage />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
}

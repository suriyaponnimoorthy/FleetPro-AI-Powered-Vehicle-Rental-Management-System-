import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import api from "../utils/api";
let scriptPromise;
function loadCheckout() {
  if (window.Razorpay) return Promise.resolve();
  if (!scriptPromise)
    scriptPromise = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = resolve;
      script.onerror = () => {
        scriptPromise = null;
        reject(new Error("Unable to load payment checkout."));
      };
      document.head.appendChild(script);
    });
  return scriptPromise;
}
export default function CheckoutButton({ booking }) {
  const [busy, setBusy] = useState(false),
    [notice, setNotice] = useState("");
  const qc = useQueryClient();
  async function pay() {
    setBusy(true);
    setNotice("");
    try {
      const { data: history } = await api.get("/checkout/orders/", {
        params: { booking: booking.id },
      });
      let order = history.results.find((x) =>
        ["created", "initiating", "unknown"].includes(x.status),
      );
      if (!order) {
        const response = await api.post(
          "/checkout/orders/",
          { booking: booking.id },
          { headers: { "Idempotency-Key": crypto.randomUUID() } },
        );
        order = response.data;
      }
      if (order.status !== "created" || !order.provider_order_id) {
        setNotice(
          "Checkout is awaiting verification. Contact your branch; do not attempt another charge.",
        );
        return;
      }
      await loadCheckout();
      const checkout = new window.Razorpay({
        key: order.key_id,
        order_id: order.provider_order_id,
        amount: order.amount_paise,
        currency: order.currency,
        name: "FleetPro",
        description: `Reservation ${booking.booking_number}`,
        theme: { color: "#173c32" },
        handler: async () => {
          setNotice("Checkout completed. Verifying capture with the gateway…");
          try {
            const r = await api.post(`/checkout/orders/${order.id}/reconcile/`);
            setNotice(
              r.data.status === "captured"
                ? "Payment verified. Your reservation status is managed by your branch."
                : "Gateway verification is pending; refresh shortly.",
            );
            qc.invalidateQueries({ queryKey: ["bookings"] });
          } catch {
            setNotice(
              "Verification pending. Your payment will update after the signed gateway notification. Do not pay again.",
            );
          }
        },
        modal: {
          ondismiss: () =>
            setNotice("Checkout closed. No payment success is assumed."),
        },
      });
      checkout.on("payment.failed", () =>
        setNotice(
          "Checkout reported a failed attempt. Ask your branch to reconcile before another order.",
        ),
      );
      checkout.open();
    } catch (e) {
      setNotice(
        e.response?.data?.error || e.message || "Payment is unavailable.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div style={{ marginTop: 18 }}>
      <button className="button small" disabled={busy} onClick={pay}>
        {busy ? "Preparing checkout…" : "Pay securely"}
      </button>
      {notice && (
        <p role="status" style={{ fontSize: 12, marginTop: 12 }}>
          {notice}
        </p>
      )}
    </div>
  );
}

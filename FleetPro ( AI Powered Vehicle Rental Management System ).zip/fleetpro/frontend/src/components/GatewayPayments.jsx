import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import api from "../utils/api";
export default function GatewayPayments() {
  const [notice, setNotice] = useState(""),
    [selected, setSelected] = useState(null),
    [amount, setAmount] = useState(""),
    [reason, setReason] = useState(""),
    [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["gateway-orders"],
    queryFn: () => api.get("/checkout/orders/").then((r) => r.data),
    refetchInterval: 30000,
  });
  async function reconcile(order) {
    setBusy(true);
    try {
      await api.post(`/checkout/orders/${order.id}/reconcile/`);
      setNotice("Provider state checked.");
      qc.invalidateQueries({ queryKey: ["gateway-orders"] });
      qc.invalidateQueries({ queryKey: ["payments"] });
    } catch (e) {
      setNotice(
        JSON.stringify(e.response?.data || "Reconciliation unavailable."),
      );
    } finally {
      setBusy(false);
    }
  }
  async function refund(e) {
    e.preventDefault();
    if (!selected) return;
    const paise = Number(amount) * 100;
    if (!Number.isSafeInteger(paise) || paise <= 0) {
      setNotice("Enter a valid amount with at most two decimal places.");
      return;
    }
    setBusy(true);
    try {
      const { data } = await api.post(
        "/checkout/refunds/",
        { order: selected.id, amount_paise: paise, reason },
        { headers: { "Idempotency-Key": crypto.randomUUID() } },
      );
      setNotice(
        `Refund request ${data.id}: ${data.status}. This is not a settlement confirmation.`,
      );
      setSelected(null);
      qc.invalidateQueries({ queryKey: ["gateway-orders"] });
    } catch (e) {
      setNotice(
        JSON.stringify(
          e.response?.data ||
            "Refund status uncertain. Reconcile before another request.",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="panel" style={{ marginBottom: 25 }}>
      <div className="panel-heading">
        <div>
          <p className="eyebrow">VERIFIED GATEWAY OPERATIONS</p>
          <h2>Captures & refunds</h2>
        </div>
      </div>
      {notice && (
        <p role="status" style={{ padding: 20 }}>
          {notice}
        </p>
      )}
      {q.isError ? (
        <p className="empty-state" role="alert">
          Gateway records unavailable.
        </p>
      ) : (
        <div className="table-scroll">
          <table className="premium-table">
            <thead>
              <tr>
                <th>Order</th>
                <th>Amount</th>
                <th>State</th>
                <th>Available to refund</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {q.data?.results.map((o) => (
                <tr key={o.id}>
                  <td>{o.id.slice(0, 8)}</td>
                  <td>₹{(o.amount_paise / 100).toFixed(2)}</td>
                  <td>{o.status}</td>
                  <td>₹{(o.refundable_paise / 100).toFixed(2)}</td>
                  <td>
                    <button disabled={busy} onClick={() => reconcile(o)}>
                      Verify
                    </button>
                    {o.status === "captured" && o.refundable_paise > 0 && (
                      <button
                        disabled={busy}
                        onClick={() => {
                          setSelected(o);
                          setAmount("");
                          setReason("");
                        }}
                      >
                        Request refund
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!q.isLoading && !q.data?.results.length && (
            <p className="empty-state">No gateway orders in this branch yet.</p>
          )}
        </div>
      )}
      {selected && (
        <form onSubmit={refund} className="account-form">
          <h3>Confirm a refund request</h3>
          <p>
            Order {selected.id}. This submits a real provider refund when live
            keys are configured.
          </p>
          <label>
            Amount · INR
            <input
              type="number"
              required
              min="0.01"
              step="0.01"
              max={selected.refundable_paise / 100}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </label>
          <label>
            Reason
            <input
              maxLength={500}
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </label>
          <button className="button" disabled={busy}>
            Confirm refund request
          </button>
          <button
            type="button"
            className="button"
            disabled={busy}
            onClick={() => setSelected(null)}
          >
            Close
          </button>
        </form>
      )}
    </section>
  );
}

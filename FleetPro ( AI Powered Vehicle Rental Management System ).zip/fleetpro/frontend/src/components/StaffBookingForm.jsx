import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { customerAPI, bookingAPI } from "../utils/api";
import AvailabilityChecker from "./AvailabilityChecker";
export default function StaffBookingForm({ onDone }) {
  const [customer, setCustomer] = useState(""),
    [selection, setSelection] = useState(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [page, setPage] = useState(1);
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["booking-customers", page],
    queryFn: () =>
      customerAPI
        .list({ page, kyc_status: "verified", page_size: 100 })
        .then((r) => r.data),
  });
  async function request() {
    if (!customer) {
      setMessage("Choose a verified customer.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      await bookingAPI.create({
        ...selection.dates,
        customer,
        vehicle: selection.vehicle.id,
        pickup_location: selection.vehicle.branch_name,
        drop_location: selection.vehicle.branch_name,
        with_driver: false,
      });
      qc.invalidateQueries({ queryKey: ["bookings"] });
      onDone();
    } catch (e) {
      setMessage(
        JSON.stringify(e.response?.data || "Unable to request booking."),
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div>
      <label className="eyebrow" htmlFor="booking-customer">
        Verified customer
      </label>
      <select
        id="booking-customer"
        style={{ padding: 12, width: "100%", marginBottom: 15 }}
        value={customer}
        onChange={(e) => {
          setCustomer(e.target.value);
          setSelection(null);
        }}
      >
        <option value="">Choose a customer</option>
        {(q.data?.results || [])
          .filter((c) => !c.is_blacklisted)
          .map((c) => (
            <option key={c.id} value={c.id}>
              {c.full_name} · {c.email}
            </option>
          ))}
      </select>
      {q.isError && <p role="alert">Customer list unavailable.</p>}
      <div style={{ display: "flex", gap: 10, marginBottom: 15 }}>
        <button
          disabled={page === 1}
          onClick={() => {
            setPage(page - 1);
            setCustomer("");
          }}
        >
          Previous customers
        </button>
        <button
          disabled={!q.data?.next}
          onClick={() => {
            setPage(page + 1);
            setCustomer("");
          }}
        >
          More customers
        </button>
      </div>
      <AvailabilityChecker
        onVehicleSelect={(vehicle, dates) => {
          setSelection({ vehicle, dates });
          setMessage("");
        }}
      />
      {selection && (
        <div style={{ paddingTop: 20 }}>
          <p>
            Selected: {selection.vehicle.make} {selection.vehicle.model}. A
            pending booking request will be created. Server checks availability
            and calculates the total.
          </p>
          <button
            className="button"
            disabled={busy || !customer}
            onClick={request}
          >
            {busy ? "Requesting…" : "Create booking request"}
          </button>
        </div>
      )}
      {message && (
        <p className="error-banner" role="alert">
          {message}
        </p>
      )}
    </div>
  );
}

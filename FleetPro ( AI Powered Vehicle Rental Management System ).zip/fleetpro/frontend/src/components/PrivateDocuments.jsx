import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import api from "../utils/api";
export default function PrivateDocuments() {
  const [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["private-documents"],
    queryFn: () => api.get("/private-documents/mine/").then((r) => r.data),
  });
  async function upload(field, file) {
    if (!file) return;
    setBusy(true);
    setNotice("");
    const form = new FormData();
    form.append("file", file);
    try {
      await api.post(
        `/private-documents/customer/${q.data.profile_id}/${field}/`,
        form,
        { headers: { "Content-Type": "multipart/form-data" } },
      );
      setNotice(
        "Stored privately and submitted for KYC review. Changing documents requires a fresh review.",
      );
      qc.invalidateQueries({ queryKey: ["private-documents"] });
    } catch (e) {
      setNotice(JSON.stringify(e.response?.data || "Upload failed."));
    } finally {
      setBusy(false);
    }
  }
  async function download(url) {
    try {
      const r = await api.get(url.replace("/api/v1", ""), {
        responseType: "blob",
      });
      const blob = URL.createObjectURL(r.data),
        a = document.createElement("a");
      a.href = blob;
      a.download = "private-document";
      a.click();
      URL.revokeObjectURL(blob);
    } catch {
      setNotice("Document download failed or access was denied.");
    }
  }
  return (
    <section className="panel account-form" style={{ marginTop: 25 }}>
      <p className="eyebrow">PRIVATE CUSTOMER DOCUMENTS</p>
      <h2>KYC, handled carefully.</h2>
      <p>
        PDF, JPEG or PNG · maximum 10 MiB. Files are stored separately from
        public images. Replacing a document resets verification.
      </p>
      {q.isError ? (
        <p role="alert">Unable to load documents.</p>
      ) : q.isLoading ? (
        <p role="status">Loading documents…</p>
      ) : (
        <>
          <p>
            Review status: <strong>{q.data.kyc_status}</strong>
          </p>
          {Object.entries(q.data.documents).map(([field, url]) => (
            <div key={field} style={{ marginBottom: 20 }}>
              <label>
                {field.replaceAll("_", " ")}
                <input
                  type="file"
                  disabled={busy}
                  accept="application/pdf,image/jpeg,image/png"
                  onChange={(e) => upload(field, e.target.files?.[0])}
                />
              </label>
              {url && (
                <button
                  type="button"
                  className="button small"
                  onClick={() => download(url)}
                >
                  Download my document
                </button>
              )}
            </div>
          ))}
        </>
      )}
      {notice && <p role="status">{notice}</p>}
    </section>
  );
}

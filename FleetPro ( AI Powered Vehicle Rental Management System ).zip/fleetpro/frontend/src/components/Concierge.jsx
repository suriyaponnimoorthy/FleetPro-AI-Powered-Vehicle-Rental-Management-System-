import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import api from "../utils/api";
export default function Concierge() {
  const [open, setOpen] = useState(false),
    [text, setText] = useState(""),
    [busy, setBusy] = useState(false),
    [consent, setConsent] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Welcome to FleetPro. Ask about your bookings, rental requirements, or finding your next drive.",
      mode: "local-guide",
    },
  ]);
  const input = useRef(null),
    end = useRef(null),
    trigger = useRef(null);
  useEffect(() => {
    if (open) input.current?.focus();
  }, [open]);
  useEffect(() => {
    if (open) end.current?.scrollIntoView({ block: "nearest" });
  }, [messages, open]);
  const close = () => {
    setOpen(false);
    trigger.current?.focus();
  };
  async function send(e, suggestion) {
    e?.preventDefault();
    const message = (suggestion || text).trim();
    if (!message || busy) return;
    const history = messages
      .slice(1)
      .filter((m) => m.mode !== "error" && m.mode !== "account-guide")
      .slice(-8)
      .map(({ role, content }) => ({ role, content: content.slice(0, 1500) }));
    setMessages((m) => [...m, { role: "user", content: message }]);
    setText("");
    setBusy(true);
    try {
      const { data } = await api.post("/intelligence/chat/", {
        message,
        history,
        allow_external_ai: consent,
      });
      setMessages((m) => [
        ...m,
        { role: "assistant", content: data.answer, mode: data.mode },
      ]);
    } catch {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content: "Unable to connect. Please try again shortly.",
          mode: "error",
        },
      ]);
    } finally {
      setBusy(false);
      input.current?.focus();
    }
  }
  return (
    <>
      <button
        ref={trigger}
        className="concierge-trigger"
        aria-label="Open FleetPro concierge"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        <MessageCircle size={20} />
        <span>Concierge</span>
      </button>
      {open && (
        <section
          className="concierge"
          role="dialog"
          aria-modal="false"
          aria-label="FleetPro concierge"
          onKeyDown={(e) => {
            if (e.key === "Escape") close();
          }}
        >
          <header>
            <Sparkles size={20} />
            <div>
              <strong>Your travel concierge</strong>
              <small>Rental guidance · AI with consent</small>
            </div>
            <button
              className="icon-btn"
              aria-label="Close concierge"
              onClick={close}
            >
              <X size={20} />
            </button>
          </header>
          <div className="chat-messages" role="log" aria-live="polite">
            {messages.map((m, i) => (
              <div key={i} className={`message ${m.role}`}>
                <p>{m.content}</p>
                {m.mode && <small>{m.mode.replaceAll("-", " ")}</small>}
              </div>
            ))}
            {busy && <p role="status">Preparing your answer…</p>}
            <div ref={end} />
          </div>
          <div className="chat-prompts">
            {["My bookings", "Rental requirements"].map((s) => (
              <button key={s} disabled={busy} onClick={() => send(null, s)}>
                {s}
              </button>
            ))}
          </div>
          <label className="consent">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
            />
            Use conversational AI. Sends this chat and public catalog facts to
            OpenAI when configured. Avoid personal or payment details.
          </label>
          <form onSubmit={send}>
            <input
              ref={input}
              aria-label="Message"
              maxLength={1500}
              placeholder="How can I help?"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <button aria-label="Send message" disabled={busy || !text.trim()}>
              <Send size={18} />
            </button>
          </form>
        </section>
      )}
    </>
  );
}

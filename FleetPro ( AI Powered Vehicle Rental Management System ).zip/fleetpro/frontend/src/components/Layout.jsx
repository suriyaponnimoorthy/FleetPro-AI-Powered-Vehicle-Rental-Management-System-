import { Outlet, NavLink, Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  Gauge,
  CalendarDays,
  CarFront,
  Users,
  CreditCard,
  ShieldAlert,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  ArrowUpRight,
  Compass,
} from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import Concierge from "./Concierge";
const nav = [
  ["/", "Overview", Gauge],
  ["/bookings", "Bookings", CalendarDays],
  ["/vehicles", "Fleet", CarFront],
  ["/drivers", "Drivers", Users, "staff"],
  ["/customers", "Customers", Users, "staff"],
  ["/payments", "Payments", CreditCard, "staff"],
  ["/damage", "Damage & fines", ShieldAlert],
  ["/analytics", "Analytics", BarChart3, "admin"],
  ["/settings", "Settings", Settings],
];
export default function Layout() {
  const { user, isCustomer, isStaff, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState(false);
  const exit = async () => {
    await logout();
    navigate("/login");
  };
  if (isCustomer)
    return (
      <div className="customer-shell">
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <header className="customer-nav">
          <Link className="wordmark" to="/">
            <span className="brand-mark">F</span>FleetPro
            <span className="brand-small">COLLECTION</span>
          </Link>
          <nav aria-label="Customer navigation">
            <NavLink to="/" end>
              The collection
            </NavLink>
            <NavLink to="/bookings">My journeys</NavLink>
            <NavLink to="/settings">Account</NavLink>
          </nav>
          <button className="icon-btn" aria-label="Sign out" onClick={exit}>
            <LogOut size={19} />
          </button>
        </header>
        <main id="main">
          <Outlet />
        </main>
        <footer className="customer-footer">
          <Link className="wordmark" to="/">
            FleetPro
          </Link>
          <span>Exceptional drives. Thoughtfully chosen.</span>
          <span>Vehicle rental · India</span>
        </footer>
        <Concierge />
      </div>
    );
  return (
    <div className="employee-shell">
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <aside className={expanded ? "sidebar expanded" : "sidebar"}>
        <Link className="wordmark" to="/">
          <span className="brand-mark">F</span>FleetPro
        </Link>
        <p className="eyebrow">OPERATIONS WORKSPACE</p>
        <nav aria-label="Employee navigation">
          {nav
            .filter((n) => n[3] !== "staff" || isStaff)
            .filter((n) => n[3] !== "admin" || isAdmin)
            .map(([to, label, Icon]) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                onClick={() => setExpanded(false)}
              >
                <Icon size={18} />
                <span>{label}</span>
              </NavLink>
            ))}
        </nav>
        <div className="sidebar-note">
          <Compass size={22} />
          <strong>Every detail. In view.</strong>
          <p>Your fleet, people and journeys in one place.</p>
        </div>
        <div className="user-card">
          <span className="avatar">
            {(user?.full_name || user?.email || "F").charAt(0)}
          </span>
          <div>
            <strong>{user?.full_name || user?.email}</strong>
            <small>{user?.role?.replaceAll("_", " ")}</small>
          </div>
          <button className="icon-btn" aria-label="Sign out" onClick={exit}>
            <LogOut size={17} />
          </button>
        </div>
      </aside>
      <div className="workspace">
        <header className="workspace-header">
          <button
            className="icon-btn mobile-menu"
            aria-label="Toggle navigation"
            aria-expanded={expanded}
            onClick={() => setExpanded(!expanded)}
          >
            <Menu />
          </button>
          <span>
            Workspace <span className="slash">/</span> Operations
          </span>
          <div>
            <span className="live-dot" /> Connected to fleet API
          </div>
          <Link className="button small" to="/bookings">
            Manage bookings <ArrowUpRight size={15} />
          </Link>
        </header>
        <main id="main" className="workspace-main">
          <Outlet />
        </main>
      </div>
      <Concierge />
    </div>
  );
}

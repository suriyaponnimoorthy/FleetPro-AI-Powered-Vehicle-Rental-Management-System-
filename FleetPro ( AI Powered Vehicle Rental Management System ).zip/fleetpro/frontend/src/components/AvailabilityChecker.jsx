// frontend/src/components/AvailabilityChecker.jsx
import { useState } from "react";
import { bookingAPI } from "../utils/api";

export default function AvailabilityChecker({ onVehicleSelect }) {
  const [form, setForm]     = useState({ pickup: "", return: "", category: "" });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");

  const check = async () => {
    if (!form.pickup || !form.return) { setError("Select pickup and return dates."); return; }
    if(new Date(form.pickup)<=new Date()||new Date(form.return)<=new Date(form.pickup)){setError("Choose a future pickup and a later return.");return;}
    setError(""); setResults(null); setLoading(true);
    try {
      const { data } = await bookingAPI.checkAvail({
        pickup_datetime:  new Date(form.pickup).toISOString(),
        return_datetime:  new Date(form.return).toISOString(),
        ...(form.category ? { category_id: form.category } : {}),
      });
      setResults(data);
    } catch (e) {
      setError(e.response?.data?.error || "Failed to check availability.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: "white", borderRadius: 12, border: "1px solid #E5E7EB", padding: 24 }}>
      <div style={{ fontFamily: "'Space Grotesk',sans-serif", fontSize: 16, fontWeight: 600, marginBottom: 20 }}>
        Check Vehicle Availability
      </div>

      {/* Form */}
      <div className="availability-fields">
        {[
          { label: "Pickup Date & Time", key: "pickup", type: "datetime-local" },
          { label: "Return Date & Time", key: "return", type: "datetime-local" },
        ].map(f => (
          <div key={f.key}>
            <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#6B7280", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>{f.label}</label>
            <input
              aria-label={f.label}
              type={f.type}
              value={form[f.key]}
              onChange={e => {setForm(p => ({ ...p, [f.key]: e.target.value }));setResults(null);}}
              style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, fontFamily: "DM Sans,sans-serif", outline: "none", color: "#173c32" }}
            />
          </div>
        ))}
      </div>

      {error && <div style={{ background: "#FEF2F2", color: "#991B1B", padding: "10px 14px", borderRadius: 8, fontSize: 13, marginBottom: 14 }}>{error}</div>}

      <button onClick={check} disabled={loading} style={{
        padding: "9px 20px", background: loading ? "#9CA3AF" : "#28543e",
        color: "white", border: "none", borderRadius: 8,
        fontSize: 13, fontWeight: 600, cursor: loading ? "not-allowed" : "pointer",
        fontFamily: "DM Sans,sans-serif",
      }}>
        {loading ? "Checking..." : "🔍 Check Availability"}
      </button>

      {/* Results */}
      {results && (
        <div style={{ marginTop: 24 }}>
          <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 14 }}>
            <strong style={{ color: "#173c32" }}>{results.available_count}</strong> vehicles available
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 14 }}>
            {(results.vehicles || []).map(v => (
              <button type="button"
                key={v.id}
                onClick={() => onVehicleSelect?.(v,{pickup_datetime:new Date(form.pickup).toISOString(),return_datetime:new Date(form.return).toISOString()})}
                style={{
                  border: "1px solid #E5E7EB", borderRadius: 10, padding: 16,
                  cursor: "pointer", transition: "all 0.15s",
                  background: "white",
                }}
                onMouseEnter={e => e.currentTarget.style.borderColor = "#28543e"}
                onMouseLeave={e => e.currentTarget.style.borderColor = "#E5E7EB"}
              >
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>{v.make} {v.model}</div>
                <div style={{ fontSize: 12, color: "#6B7280", marginBottom: 10 }}>{v.category_name} · {v.fuel_type} · {v.seating_capacity} seats</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontFamily: "'Space Grotesk',sans-serif", fontSize: 16, fontWeight: 700, color: "#173c32" }}>
                    ₹{Number(v.daily_rate).toLocaleString()} <span style={{ fontSize: 11, fontWeight: 400, color: "#6B7280" }}>/day</span>
                  </div>
                  <div style={{ fontSize: 12, color: "#F59E0B" }}>
                    ★ {v.average_rating}
                  </div>
                </div>
                <div style={{ marginTop: 10, padding: "6px 10px", background: "#28543e", color: "white", borderRadius: 6, textAlign: "center", fontSize: 12, fontWeight: 600 }}>
                  Select Vehicle
                </div>
              </button>
            ))}
          </div>
          {results.vehicles?.length === 0 && (
            <div style={{ textAlign: "center", padding: "32px 0", color: "#6B7280", fontSize: 14 }}>
              No vehicles available for the selected dates. Try different dates.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

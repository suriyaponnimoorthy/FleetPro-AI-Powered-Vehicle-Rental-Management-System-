// frontend/src/components/ui/index.jsx
// Reusable UI primitives used across all pages

import { useState, useEffect, useRef } from "react";

// ── Button ─────────────────────────────────────────────────
export function Button({ children, variant = "primary", size = "md", disabled, onClick, type = "button", className = "" }) {
  const variants = {
    primary:  { background: "#28543e", color: "#fff", border: "none" },
    secondary:{ background: "none", color: "#667864", border: "1px solid #dce3d5" },
    danger:   { background: "#EF4444", color: "#fff", border: "none" },
    ghost:    { background: "none", color: "#173c32", border: "1px solid #dce3d5" },
  };
  const sizes = {
    sm: { padding: "5px 12px", fontSize: 12 },
    md: { padding: "8px 16px", fontSize: 13 },
    lg: { padding: "11px 22px", fontSize: 15 },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{
        ...variants[variant],
        ...sizes[size],
        borderRadius: 8,
        fontWeight: 600,
        fontFamily: "DM Sans, sans-serif",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.6 : 1,
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
      }}
    >
      {children}
    </button>
  );
}

// ── Badge / Status Pill ────────────────────────────────────
export function StatusBadge({ status }) {
  const map = {
    active:     { bg: "#ECFDF5", text: "#065F46" },
    confirmed:  { bg: "#EFF9FF", text: "#0C4A6E" },
    pending:    { bg: "#e9efdf", text: "#9A3412" },
    completed:  { bg: "#F5F3FF", text: "#5B21B6" },
    cancelled:  { bg: "#FEF2F2", text: "#991B1B" },
    no_show:    { bg: "#F3F4F6", text: "#4B5563" },
    available:  { bg: "#ECFDF5", text: "#065F46" },
    rented:     { bg: "#e9efdf", text: "#9A3412" },
    maintenance:{ bg: "#FFFBEB", text: "#92400E" },
    verified:   { bg: "#ECFDF5", text: "#065F46" },
    rejected:   { bg: "#FEF2F2", text: "#991B1B" },
    paid:       { bg: "#ECFDF5", text: "#065F46" },
    overdue:    { bg: "#FEF2F2", text: "#991B1B" },
    partial:    { bg: "#FFFBEB", text: "#92400E" },
  };
  const style = map[status] || { bg: "#F3F4F6", text: "#4B5563" };
  return (
    <span style={{
      background: style.bg, color: style.text,
      fontSize: 11, fontWeight: 600,
      padding: "3px 10px", borderRadius: 20,
      textTransform: "capitalize",
      display: "inline-block",
    }}>
      {status?.replace("_", " ")}
    </span>
  );
}

// ── Card ────────────────────────────────────────────────────
export function Card({ children, style = {}, className = "" }) {
  return (
    <div style={{
      background: "white",
      borderRadius: 12,
      border: "1px solid #dce3d5",
      overflow: "hidden",
      ...style,
    }} className={className}>
      {children}
    </div>
  );
}

export function CardHeader({ title, action }) {
  return (
    <div style={{
      padding: "16px 20px",
      borderBottom: "1px solid #dce3d5",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: "#173c32" }}>{title}</div>
      {action && <div>{action}</div>}
    </div>
  );
}

// ── Input ───────────────────────────────────────────────────
export function Input({ label, error, ...props }) {
  return (
    <div style={{ marginBottom: 16 }}>
      {label && (
        <label style={{
          display: "block", fontSize: 12, fontWeight: 600,
          color: "#667864", textTransform: "uppercase",
          letterSpacing: "0.5px", marginBottom: 6,
        }}>{label}</label>
      )}
      <input
        {...props}
        style={{
          width: "100%", padding: "9px 12px",
          border: `1px solid ${error ? "#EF4444" : "#dce3d5"}`,
          borderRadius: 8, fontSize: 13,
          fontFamily: "DM Sans, sans-serif",
          outline: "none", color: "#173c32",
          background: "white",
        }}
      />
      {error && <div style={{ fontSize: 12, color: "#EF4444", marginTop: 4 }}>{error}</div>}
    </div>
  );
}

// ── Select ──────────────────────────────────────────────────
export function Select({ label, options = [], error, ...props }) {
  return (
    <div style={{ marginBottom: 16 }}>
      {label && (
        <label style={{
          display: "block", fontSize: 12, fontWeight: 600,
          color: "#667864", textTransform: "uppercase",
          letterSpacing: "0.5px", marginBottom: 6,
        }}>{label}</label>
      )}
      <select
        {...props}
        style={{
          width: "100%", padding: "9px 12px",
          border: `1px solid ${error ? "#EF4444" : "#dce3d5"}`,
          borderRadius: 8, fontSize: 13,
          fontFamily: "DM Sans, sans-serif",
          outline: "none", color: "#173c32",
          background: "white", cursor: "pointer",
        }}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      {error && <div style={{ fontSize: 12, color: "#EF4444", marginTop: 4 }}>{error}</div>}
    </div>
  );
}

// ── Modal ───────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, footer }) {
  const dialog = useRef(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement;
    dialog.current?.querySelector('button, input, select')?.focus();
    return () => previous?.focus();
  }, [open]);
  if (!open) return null;
  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
        zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center",
      }}
    >
      <div ref={dialog} role="dialog" aria-modal="true" aria-label={title}
        onKeyDown={e => {
          if(e.key==='Escape') onClose();
          if(e.key==='Tab') {
            const nodes=[...e.currentTarget.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),a[href]')];
            if(e.shiftKey && document.activeElement===nodes[0]){e.preventDefault();nodes.at(-1)?.focus();}
            else if(!e.shiftKey && document.activeElement===nodes.at(-1)){e.preventDefault();nodes[0]?.focus();}
          }
        }} style={{
        background: "white", borderRadius: 16,
        width: "min(560px, calc(100vw - 24px))", maxHeight: "85vh",
        overflowY: "auto",
        boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
      }}>
        <div style={{
          padding: "20px 24px", borderBottom: "1px solid #dce3d5",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <div style={{ fontFamily: "'Space Grotesk',sans-serif", fontSize: 16, fontWeight: 600 }}>{title}</div>
          <button aria-label="Close dialog" onClick={onClose} style={{
            width: 28, height: 28, borderRadius: 6,
            border: "none", background: "#f4f6ef",
            cursor: "pointer", fontSize: 16, color: "#667864",
          }}>✕</button>
        </div>
        <div style={{ padding: 24 }}>{children}</div>
        {footer && (
          <div style={{
            padding: "16px 24px", borderTop: "1px solid #dce3d5",
            display: "flex", gap: 10, justifyContent: "flex-end",
          }}>{footer}</div>
        )}
      </div>
    </div>
  );
}

// ── Alert ───────────────────────────────────────────────────
export function Alert({ type = "info", children }) {
  const map = {
    info:    { bg: "#EFF9FF", text: "#0C4A6E", border: "#527f73", icon: "ℹ" },
    success: { bg: "#ECFDF5", text: "#065F46", border: "#10B981", icon: "✓" },
    warning: { bg: "#FFFBEB", text: "#92400E", border: "#F59E0B", icon: "!" },
    error:   { bg: "#FEF2F2", text: "#991B1B", border: "#EF4444", icon: "✕" },
  };
  const s = map[type];
  return (
    <div style={{
      background: s.bg, color: s.text,
      borderLeft: `3px solid ${s.border}`,
      borderRadius: "0 8px 8px 0",
      padding: "12px 16px",
      display: "flex", gap: 10,
      fontSize: 13, alignItems: "flex-start",
    }}>
      <span style={{ fontWeight: 700, flexShrink: 0 }}>{s.icon}</span>
      <span>{children}</span>
    </div>
  );
}

// ── Empty State ─────────────────────────────────────────────
export function EmptyState({ emoji = "📭", title, description, action }) {
  return (
    <div style={{ textAlign: "center", padding: "48px 24px", color: "#667864" }}>
      <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.5 }}>{emoji}</div>
      {title && <div style={{ fontSize: 15, fontWeight: 600, color: "#173c32", marginBottom: 8 }}>{title}</div>}
      {description && <div style={{ fontSize: 13, marginBottom: 20 }}>{description}</div>}
      {action}
    </div>
  );
}

// ── Skeleton ────────────────────────────────────────────────
export function Skeleton({ width = "100%", height = 16, borderRadius = 4 }) {
  return (
    <div style={{
      width, height, borderRadius,
      background: "linear-gradient(90deg, #F3F4F6 25%, #dce3d5 50%, #F3F4F6 75%)",
      backgroundSize: "200% 100%",
      animation: "shimmer 1.5s infinite",
    }} />
  );
}

// ── Stat Card ───────────────────────────────────────────────
export function StatCard({ label, value, change, changeDir = "up", icon, color = "#28543e", onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: "white", borderRadius: 12, padding: "18px 20px",
        border: "1px solid #dce3d5", cursor: onClick ? "pointer" : "default",
        position: "relative", overflow: "hidden",
      }}
    >
      <div style={{ fontSize: 12, color: "#667864", fontWeight: 500, marginBottom: 8 }}>{label}</div>
      <div style={{ fontFamily: "'Space Grotesk',sans-serif", fontSize: 26, fontWeight: 700, color: "#173c32", marginBottom: 8 }}>{value}</div>
      {change && (
        <div style={{ fontSize: 12, color: changeDir === "up" ? "#10B981" : "#EF4444" }}>
          {changeDir === "up" ? "↑" : "↓"} {change}
        </div>
      )}
      {icon && (
        <div style={{
          position: "absolute", top: 16, right: 16,
          width: 36, height: 36, borderRadius: 10,
          background: color + "22",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
        }}>{icon}</div>
      )}
    </div>
  );
}

-- =============================================================
-- FleetPro — SQL Query Documentation
-- Advanced queries: CTEs, Window Functions, Subqueries, Views
-- =============================================================


-- ═══════════════════════════════════════════════════════════════
-- 1. BOOKING CONFLICT DETECTION
-- Checks if a vehicle is available for a date range
-- Uses overlap logic: (A.start < B.end) AND (A.end > B.start)
-- ═══════════════════════════════════════════════════════════════

-- Check single vehicle availability
SELECT
    v.id,
    v.registration_number,
    v.make || ' ' || v.model AS vehicle_name,
    COUNT(b.id) AS conflicting_bookings,
    CASE WHEN COUNT(b.id) = 0 THEN 'AVAILABLE' ELSE 'NOT AVAILABLE' END AS availability
FROM vehicles v
LEFT JOIN bookings b
    ON b.vehicle_id = v.id
    AND b.status IN ('confirmed', 'active', 'pending')
    AND b.pickup_datetime  < '2025-06-04 09:00:00+05:30'   -- :return_datetime
    AND b.return_datetime  > '2025-06-01 09:00:00+05:30'   -- :pickup_datetime
WHERE v.id = '<<vehicle_uuid>>'
GROUP BY v.id, v.registration_number, v.make, v.model;


-- All available vehicles for a date range (with category and pricing)
SELECT
    v.id,
    v.registration_number,
    v.make || ' ' || v.model            AS vehicle_name,
    vc.name                              AS category,
    vc.type                              AS category_type,
    vb.city                              AS branch_city,
    COALESCE(v.price_per_day, vc.base_price_per_day) AS daily_rate,
    v.fuel_type,
    v.seating_capacity,
    v.average_rating,
    v.total_trips
FROM vehicles v
JOIN vehicle_categories vc ON v.category_id = vc.id
JOIN vehicle_branches   vb ON v.branch_id   = vb.id
WHERE v.is_active = TRUE
  AND v.status    = 'available'
  AND v.id NOT IN (
      SELECT DISTINCT vehicle_id FROM bookings
      WHERE status IN ('confirmed', 'active', 'pending')
        AND pickup_datetime  < '2025-06-04 09:00:00+05:30'
        AND return_datetime  > '2025-06-01 09:00:00+05:30'
  )
ORDER BY vc.type, daily_rate;


-- ═══════════════════════════════════════════════════════════════
-- 2. LATE RETURN PENALTY CALCULATION
-- Correlated subquery + CASE logic
-- ═══════════════════════════════════════════════════════════════

SELECT
    b.id,
    b.booking_number,
    u.first_name || ' ' || u.last_name     AS customer_name,
    u.phone,
    v.registration_number,
    b.return_datetime                       AS due_return,
    NOW()                                   AS current_time,
    EXTRACT(EPOCH FROM (NOW() - b.return_datetime)) / 3600 AS overdue_hours,
    GREATEST(0,
        FLOOR(EXTRACT(EPOCH FROM (NOW() - b.return_datetime)) / 3600)
    ) * 100                                AS late_fee_inr,
    -- Fuel penalty (if returned with less fuel than picked up)
    CASE
        WHEN b.fuel_level_at_pickup IS NOT NULL
         AND b.fuel_level_at_return IS NOT NULL
         AND (b.fuel_level_at_pickup - b.fuel_level_at_return) > 10
        THEN (b.fuel_level_at_pickup - b.fuel_level_at_return) * 50
        ELSE 0
    END                                    AS fuel_penalty_inr
FROM bookings b
JOIN customer_profiles cp ON b.customer_id  = cp.id
JOIN auth_users         u  ON cp.user_id     = u.id
JOIN vehicles           v  ON b.vehicle_id   = v.id
WHERE b.status = 'active'
  AND b.return_datetime < NOW()
ORDER BY overdue_hours DESC;


-- ═══════════════════════════════════════════════════════════════
-- 3. REVENUE ANALYTICS — CTE + WINDOW FUNCTIONS
-- Monthly revenue with MoM growth and running totals
-- ═══════════════════════════════════════════════════════════════

WITH monthly_revenue AS (
    SELECT
        DATE_TRUNC('month', p.paid_at)           AS month,
        COUNT(DISTINCT p.booking_id)             AS bookings_count,
        COUNT(p.id)                              AS transactions,
        SUM(p.amount)                            AS gross_revenue,
        SUM(p.cgst + p.sgst + p.igst)           AS total_tax,
        SUM(p.amount - p.cgst - p.sgst - p.igst) AS net_revenue,
        AVG(p.amount)                            AS avg_transaction
    FROM payments p
    WHERE p.status = 'success'
      AND p.payment_type = 'booking_payment'
      AND p.paid_at >= NOW() - INTERVAL '12 months'
    GROUP BY DATE_TRUNC('month', p.paid_at)
),
revenue_with_growth AS (
    SELECT
        month,
        bookings_count,
        gross_revenue,
        net_revenue,
        avg_transaction,
        -- Month-over-month change
        gross_revenue - LAG(gross_revenue) OVER (ORDER BY month) AS mom_absolute,
        ROUND(
            100.0 * (gross_revenue - LAG(gross_revenue) OVER (ORDER BY month))
                  / NULLIF(LAG(gross_revenue) OVER (ORDER BY month), 0), 2
        )                                                          AS mom_pct,
        -- Running total
        SUM(gross_revenue) OVER (ORDER BY month
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)      AS cumulative_revenue,
        -- 3-month rolling average
        AVG(gross_revenue) OVER (ORDER BY month
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)              AS rolling_3m_avg
    FROM monthly_revenue
)
SELECT
    TO_CHAR(month, 'Mon YYYY')  AS month_name,
    bookings_count,
    ROUND(gross_revenue, 2)     AS gross_revenue,
    ROUND(net_revenue, 2)       AS net_revenue,
    COALESCE(mom_absolute, 0)   AS mom_change,
    COALESCE(mom_pct, 0)        AS mom_pct_change,
    ROUND(cumulative_revenue, 2) AS ytd_revenue,
    ROUND(rolling_3m_avg, 2)   AS rolling_3m_avg
FROM revenue_with_growth
ORDER BY month DESC;


-- ═══════════════════════════════════════════════════════════════
-- 4. VEHICLE UTILIZATION RATE — Complex JOIN + Window Function
-- ═══════════════════════════════════════════════════════════════

WITH period AS (
    SELECT
        '2025-05-01'::DATE AS start_date,
        '2025-05-31'::DATE AS end_date,
        31 AS total_days
),
booking_days AS (
    SELECT
        vehicle_id,
        SUM(
            GREATEST(0,
                EXTRACT(EPOCH FROM (
                    LEAST(return_datetime, p.end_date::TIMESTAMPTZ + INTERVAL '1 day')
                    - GREATEST(pickup_datetime, p.start_date::TIMESTAMPTZ)
                )) / 86400
            )
        ) AS days_rented
    FROM bookings, period p
    WHERE status IN ('active', 'completed')
      AND pickup_datetime <= p.end_date::TIMESTAMPTZ + INTERVAL '1 day'
      AND return_datetime >= p.start_date::TIMESTAMPTZ
    GROUP BY vehicle_id
),
vehicle_stats AS (
    SELECT
        v.id,
        v.registration_number,
        v.make || ' ' || v.model               AS vehicle_name,
        vc.name                                 AS category,
        vc.type                                 AS category_type,
        vb.city                                 AS branch_city,
        v.status,
        COALESCE(bd.days_rented, 0)             AS days_rented,
        p.total_days,
        ROUND(COALESCE(bd.days_rented, 0) / p.total_days * 100, 1) AS utilization_pct,
        COALESCE(v.price_per_day, vc.base_price_per_day) AS daily_rate,
        ROUND(COALESCE(bd.days_rented, 0) *
              COALESCE(v.price_per_day, vc.base_price_per_day), 2) AS estimated_revenue,
        v.average_rating,
        v.total_trips,
        -- Rank within category
        RANK() OVER (PARTITION BY vc.type ORDER BY
            COALESCE(bd.days_rented, 0) DESC)   AS rank_in_category
    FROM vehicles v
    JOIN vehicle_categories vc ON v.category_id = vc.id
    JOIN vehicle_branches   vb ON v.branch_id   = vb.id
    CROSS JOIN period p
    LEFT JOIN booking_days  bd ON bd.vehicle_id = v.id
    WHERE v.is_active = TRUE
)
SELECT * FROM vehicle_stats
ORDER BY utilization_pct DESC;


-- ═══════════════════════════════════════════════════════════════
-- 5. TOP CUSTOMERS — Ranking + Correlated Subquery
-- ═══════════════════════════════════════════════════════════════

WITH customer_metrics AS (
    SELECT
        cp.id,
        u.first_name || ' ' || u.last_name         AS full_name,
        u.email,
        u.phone,
        cp.city,
        cp.kyc_status,
        cp.total_bookings,
        cp.total_spend,
        cp.loyalty_points,
        -- Last booking date (correlated subquery)
        (SELECT MAX(created_at) FROM bookings
         WHERE customer_id = cp.id
           AND status = 'completed')                AS last_booking_date,
        -- Average booking value
        ROUND(cp.total_spend / NULLIF(cp.total_bookings, 0), 2) AS avg_booking_value,
        -- Favourite vehicle type
        (SELECT vc.type FROM bookings b
         JOIN vehicles v  ON b.vehicle_id  = v.id
         JOIN vehicle_categories vc ON v.category_id = vc.id
         WHERE b.customer_id = cp.id AND b.status = 'completed'
         GROUP BY vc.type ORDER BY COUNT(*) DESC LIMIT 1) AS fav_vehicle_type,
        -- Overall rank
        RANK() OVER (ORDER BY cp.total_spend DESC)  AS overall_rank,
        -- Rank within city
        RANK() OVER (PARTITION BY cp.city ORDER BY cp.total_spend DESC) AS city_rank,
        -- Spend percentile
        PERCENT_RANK() OVER (ORDER BY cp.total_spend) * 100 AS spend_percentile
    FROM customer_profiles cp
    JOIN auth_users u ON cp.user_id = u.id
    WHERE cp.is_blacklisted = FALSE
)
SELECT *
FROM customer_metrics
WHERE overall_rank <= 20
ORDER BY overall_rank;


-- ═══════════════════════════════════════════════════════════════
-- 6. DRIVER PERFORMANCE REPORT — GROUP BY + HAVING
-- ═══════════════════════════════════════════════════════════════

SELECT
    dp.employee_id,
    u.first_name || ' ' || u.last_name         AS driver_name,
    vb.city                                     AS branch_city,
    dp.availability_status,
    dp.experience_years,
    dp.average_rating,
    dp.total_trips                              AS career_trips,
    dp.total_violations,
    -- This month
    COUNT(b.id) FILTER (
        WHERE b.status = 'completed'
        AND DATE_TRUNC('month', b.completed_at) = DATE_TRUNC('month', NOW())
    )                                           AS trips_this_month,
    COALESCE(SUM(b.driver_charges) FILTER (
        WHERE b.status = 'completed'
        AND DATE_TRUNC('month', b.completed_at) = DATE_TRUNC('month', NOW())
    ), 0)                                       AS earnings_this_month,
    -- Average trip duration
    AVG(EXTRACT(EPOCH FROM (b.return_datetime - b.pickup_datetime)) / 3600)
        FILTER (WHERE b.status = 'completed')   AS avg_trip_hours,
    -- Rating from reviews
    AVG(br.driver_rating)
        FILTER (WHERE br.driver_rating IS NOT NULL) AS review_rating
FROM driver_profiles dp
JOIN auth_users      u  ON dp.user_id    = u.id
LEFT JOIN vehicle_branches vb ON dp.branch_id = vb.id
LEFT JOIN bookings   b  ON b.driver_id   = dp.id
LEFT JOIN booking_reviews br ON br.booking_id = b.id
WHERE u.is_active = TRUE
GROUP BY dp.id, dp.employee_id, u.first_name, u.last_name,
         vb.city, dp.availability_status, dp.experience_years,
         dp.average_rating, dp.total_trips, dp.total_violations
HAVING dp.total_trips > 0
ORDER BY trips_this_month DESC, dp.average_rating DESC;


-- ═══════════════════════════════════════════════════════════════
-- 7. DAMAGE COST ANALYTICS — FULL JOIN SIMULATION
-- ═══════════════════════════════════════════════════════════════

-- Damage by vehicle with insurance recovery
SELECT
    v.registration_number,
    v.make || ' ' || v.model       AS vehicle_name,
    vc.name                         AS category,
    COUNT(dr.id)                    AS total_incidents,
    SUM(dr.estimated_repair_cost)   AS total_estimated,
    SUM(COALESCE(dr.actual_repair_cost, dr.estimated_repair_cost)) AS total_actual,
    SUM(dr.insurance_claim_amount)  AS total_insured,
    SUM(dr.customer_liability_amount) AS customer_paid,
    SUM(COALESCE(dr.actual_repair_cost, dr.estimated_repair_cost))
        - SUM(dr.insurance_claim_amount)
        - SUM(dr.customer_liability_amount) AS net_loss,
    -- Severity breakdown
    COUNT(*) FILTER (WHERE dr.severity = 'minor')    AS minor_count,
    COUNT(*) FILTER (WHERE dr.severity = 'moderate') AS moderate_count,
    COUNT(*) FILTER (WHERE dr.severity = 'major')    AS major_count
FROM vehicles v
JOIN vehicle_categories vc ON v.category_id = vc.id
LEFT JOIN damage_reports dr ON dr.vehicle_id = v.id
WHERE v.is_active = TRUE
GROUP BY v.id, v.registration_number, v.make, v.model, vc.name
HAVING COUNT(dr.id) > 0
ORDER BY total_actual DESC;


-- ═══════════════════════════════════════════════════════════════
-- 8. BOOKING TRENDS — DATE SERIES + LEFT JOIN
-- Fill gaps where there are no bookings
-- ═══════════════════════════════════════════════════════════════

WITH date_series AS (
    SELECT generate_series(
        DATE_TRUNC('month', NOW() - INTERVAL '11 months'),
        DATE_TRUNC('month', NOW()),
        INTERVAL '1 month'
    )::DATE AS month
),
monthly_bookings AS (
    SELECT
        DATE_TRUNC('month', created_at)::DATE AS month,
        COUNT(*)                               AS total,
        COUNT(*) FILTER (WHERE status IN ('completed','active','confirmed')) AS successful,
        COUNT(*) FILTER (WHERE status = 'cancelled') AS cancelled,
        SUM(total_amount) FILTER (WHERE status = 'completed') AS revenue
    FROM bookings
    GROUP BY DATE_TRUNC('month', created_at)::DATE
)
SELECT
    ds.month,
    TO_CHAR(ds.month, 'Mon YYYY')           AS month_label,
    COALESCE(mb.total, 0)                   AS total_bookings,
    COALESCE(mb.successful, 0)              AS successful_bookings,
    COALESCE(mb.cancelled, 0)               AS cancelled_bookings,
    COALESCE(mb.revenue, 0)                 AS revenue,
    ROUND(
        COALESCE(mb.successful, 0) * 100.0
        / NULLIF(COALESCE(mb.total, 0), 0), 1
    )                                       AS success_rate_pct
FROM date_series ds
LEFT JOIN monthly_bookings mb ON mb.month = ds.month
ORDER BY ds.month;


-- ═══════════════════════════════════════════════════════════════
-- 9. BRANCH REVENUE COMPARISON — GROUPING SETS
-- ═══════════════════════════════════════════════════════════════

SELECT
    COALESCE(vb.name, 'ALL BRANCHES')      AS branch,
    COALESCE(vb.city, 'TOTAL')             AS city,
    COALESCE(vc.type, 'ALL TYPES')         AS vehicle_type,
    COUNT(DISTINCT b.id)                   AS bookings,
    ROUND(SUM(p.amount), 2)                AS revenue,
    ROUND(AVG(b.total_amount), 2)          AS avg_booking_value,
    COUNT(DISTINCT b.customer_id)          AS unique_customers
FROM bookings b
JOIN vehicles           v  ON b.vehicle_id      = v.id
JOIN vehicle_categories vc ON v.category_id     = vc.id
JOIN vehicle_branches   vb ON b.pickup_branch_id = vb.id
LEFT JOIN payments      p  ON p.booking_id = b.id
    AND p.status = 'success'
    AND p.payment_type = 'booking_payment'
WHERE b.status = 'completed'
  AND b.completed_at >= NOW() - INTERVAL '3 months'
GROUP BY GROUPING SETS (
    (vb.name, vb.city, vc.type),
    (vb.name, vb.city),
    ()
)
ORDER BY revenue DESC NULLS LAST;


-- ═══════════════════════════════════════════════════════════════
-- 10. PENDING KYC CUSTOMERS WITH DOCUMENT STATUS
-- Nested subquery + CASE
-- ═══════════════════════════════════════════════════════════════

SELECT
    u.first_name || ' ' || u.last_name AS full_name,
    u.email,
    u.phone,
    cp.city,
    cp.kyc_status,
    cp.created_at                       AS registered_at,
    -- Document completeness
    CASE WHEN cp.aadhar_document  <> '' THEN '✓' ELSE '✗' END AS aadhar,
    CASE WHEN cp.dl_document      <> '' THEN '✓' ELSE '✗' END AS dl_doc,
    CASE WHEN cp.pan_document     <> '' THEN '✓' ELSE '✗' END AS pan,
    -- Days since registration
    DATE_PART('day', NOW() - cp.created_at)::INT AS days_pending,
    -- Has bookings attempted
    (SELECT COUNT(*) FROM bookings WHERE customer_id = cp.id) AS booking_attempts
FROM customer_profiles cp
JOIN auth_users u ON cp.user_id = u.id
WHERE cp.kyc_status IN ('pending', 'submitted')
  AND cp.is_blacklisted = FALSE
ORDER BY days_pending DESC, cp.created_at;

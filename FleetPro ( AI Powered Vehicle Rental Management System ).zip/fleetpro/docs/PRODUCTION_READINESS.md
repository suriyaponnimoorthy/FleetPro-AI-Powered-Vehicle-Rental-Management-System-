# Production hardening update — 31 October 2026

This update implements the six requested areas. It is **not a claim that a live deployment, merchant payment, refund, external message or AI request has been verified**. The project contains no real provider credentials or hosting access.

| Requested area | Implemented | Verified here | Still needs external access |
| --- | --- | --- | --- |
| Verified payments and refund reconciliation | Razorpay order creation; raw-body signed webhooks; duplicate detection; split rental/deposit ledger; bounded partial refunds; pending/unknown/processed states; authenticated reconciliation; customer checkout and staff controls | Mocked provider success/failure, signature, idempotency, amount/currency mismatch, partial-refund, ledger and reconciliation tests pass | Merchant test account, real webhook delivery, test captures/refunds and live-mode acceptance |
| Branch-level permissions | Staff/admin queries, related-object writes, analytics and employee AI scoped to assigned branch; no branch means no branch access; global Django admin/role changes reserved for super-admin | Cross-branch reads/writes, role escalation and anonymous/unassigned behavior tested | Real organization/branch assignment and acceptance review |
| Private KYC/uploads | Separate unserved local volume or private S3; authorized audited downloads; PDF/raster validation; production malware scanning fails closed; document replacement resets KYC; public media routes restricted | Owner/same-branch authorization, foreign/anonymous denial, fake-file rejection and unavailable-scanner rejection tested | Live ClamAV signatures, private-bucket/IAM configuration, migration of existing public documents and storage/recovery acceptance |
| PostgreSQL concurrency | Four real-PostgreSQL tests: conflicting bookings, duplicate capture webhooks, competing refunds and immutable-ledger database trigger; PostgreSQL 16 CI job | Tests are present and explicitly skipped on SQLite; no SQLite result is represented as PostgreSQL proof | Run the supplied CI job or a PostgreSQL test environment and retain a passing result |
| Deployment/HTTPS/email/SMS/backups/monitoring | Docker/Caddy stack, TLS configuration, health probes, production checks, deployment CI, age-encrypted backups, offsite upload option, restore drill, heartbeat/metrics/alert templates; SMTP/Twilio probes; SMS delivery reconciliation | Frontend build, Django production-settings checks, OpenAPI validation, YAML parsing, public-port/private-volume isolation, local Gunicorn HTTPS and direct private-path denial | Docker build/start, Caddy/public certificate verification, production PostgreSQL, real inbox/device delivery, encrypted offsite recovery drill and configured alert receivers |
| Configured conversational AI and live test | Server-only environment configuration, consent, bounded model calls, live read-only probe, local fallback and recommendation reranking | Mocked model success/failure, consent and context tests; missing keys report unconfigured and no success is claimed | Configure a real API key in the server's secret environment and run the live probe/quality evaluation |

## Current local validation

- **75 backend tests passed; four PostgreSQL-only tests skipped.** The suite was run with migrations enabled.
- New migrations apply; `makemigrations --check --dry-run` reports no changes.
- `manage.py check --deploy --fail-level WARNING` passes with representative non-debug production settings. This is a configuration check, not a running production stack.
- OpenAPI generation and schema validation pass without warnings; `docs/openapi.yaml` is included.
- Frontend production build passes.
- Local Gunicorn HTTPS with a temporary trusted test certificate returned 200 for readiness; direct access to a private media path returned 404.
- Browser checks verify disabled/unconfigured checkout fails closed, customer document controls and employee gateway controls render, and no JavaScript exceptions were observed. The gateway SDK's live payment window was not exercised.
- Compose/CI/monitoring YAML parses, only the proxy publishes host ports, and private document storage is not mounted into the public proxy.

## Important operating details

Payments are credited only from a verified captured gateway entity. Refund API acceptance does not mean a refund settled; unknown requests reserve their amount until reconciliation. Ledger corrections are new entries; app updates and a PostgreSQL trigger prohibit mutation of ledger rows. Historical manually recorded payments are not retroactively certified. Reconcile them separately before importing real balances.

The application distinguishes email/SMS acceptance from delivery. SMTP connection checks prove authentication/connectivity only. Twilio acceptance is pending until a delivered status is fetched with `reconcile_sms`. The integration probe intentionally creates no payment, refund, email or SMS.

Private local files are access-controlled but disk encryption still depends on the host/provider. S3 uploads request server-side encryption; configure bucket public-access blocking, versioning and backup separately. Keep database/backups private, use restricted credentials, and review retention obligations for identity documents.

The backup script requires an age public recipient; it keeps the private identity off the application host. Offsite S3 upload is optional and must be configured to achieve offsite protection. A fresh local backup is not proof of successful offsite recovery. Alert receivers and a monitoring collector must be connected by the operator; alert rules alone do not page anyone.

## Finish the live gates

Follow `DEPLOYMENT_GUIDE.md`. Provide a hosting target/domain and configure secrets securely on that host, then:

1. Run both CI jobs, especially the real PostgreSQL concurrency tests.
2. Start the private staging stack and verify HTTPS/private media denial.
3. Configure Razorpay test keys/webhooks, SMTP/Twilio and AI credentials. Run `check_integrations --live` and actual application acceptance tests with your own test recipients.
4. Perform a restore into an isolated database/media environment and test monitoring alerts.
5. Review the results before enabling real customer data and live payments.

Do not paste API secrets into chat. Use your deployment platform's secret settings or a protected `.env.production` file. No paid infrastructure, live charge, refund or external message was created during this work.

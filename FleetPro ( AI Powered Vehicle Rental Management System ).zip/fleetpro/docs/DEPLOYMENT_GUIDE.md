# FleetPro deployment and verification

The maintained path is Docker Compose with Caddy, PostgreSQL, Redis, Django, Celery and ClamAV. The older nginx configuration is retained for reference and now denies private media paths. Production credentials, a domain and a host are required. No production infrastructure is created by extracting the ZIP.

## 1. Prepare configuration securely

From the extracted `fleetpro` directory, copy `.env.production.example` to `.env.production` and restrict its permissions. Supply values through your host's secret manager or a restricted local editor. Never commit or paste secrets into a public issue or chat.

Set a random SECRET_KEY of at least 50 characters, separate strong DB_PASSWORD and DB_ADMIN_PASSWORD values, APP_DOMAIN (hostname only), TLS_EMAIL, exact ALLOWED_HOSTS and CSRF_TRUSTED_ORIGINS (`https://your-domain`). Use the SMTP credentials and verified sending identity from your email provider. Configure Twilio credentials/from-number if SMS is required. Indian SMS delivery can additionally depend on provider registration and approved templates; verify this with your provider.

Supply Razorpay **test** keys and a webhook secret first. Set FLEETPRO_AI_API_KEY and an available model. Set METRICS_TOKEN to a separate random secret. Private uploads use an unserved local Docker volume by default; configure PRIVATE_S3_BUCKET only for a separate private bucket, with public access blocked and appropriate IAM credentials/role. Never reuse a publicly readable bucket for KYC documents.

Do not set DEBUG=True or disable PRIVATE_UPLOAD_SCAN_REQUIRED in production. Do not use local_settings on the server. Run `check --deploy` as a release gate.

## 2. Start a private staging environment

Use a staging host/domain with access limited by your firewall/VPN until validation is complete. Point DNS at the host. Open ports 80/443 for certificate issuance and application access as appropriate; database, Redis, ClamAV and Django have no host ports in the supplied stack.

```bash
docker compose --env-file .env.production -f deployment/docker-compose.yml config -q
docker compose --env-file .env.production -f deployment/docker-compose.yml build
docker compose --env-file .env.production -f deployment/docker-compose.yml up -d
```

The one-shot migrate service must succeed before Django/worker/beat start. Caddy obtains/renews public TLS certificates for the supplied domain. ClamAV's initial signature download may take time; document uploads fail closed until scanning is available. Test `/health/ready/` and the actual upload flow.

For a fresh database volume, init-app-db.sh creates the application login without superuser/create-role/create-database privileges. PostgreSQL administrative credentials stay in the database container. Existing volumes need an explicit audited role migration; the initialization script does not rerun or delete your data.

Create your first super-admin:

```bash
docker compose --env-file .env.production -f deployment/docker-compose.yml exec backend python manage.py createsuperuser
```

Use the super-admin to assign every employee and customer home branch. A branch-less employee sees no branch data. Only super-admins may enter the unscoped Django admin console or change account roles/branch assignment. Customers retain access to their own bookings/documents and may discover the public multi-branch catalog.

Do not seed demo accounts into a production database. Remove/change any historical demo users and review imported records.

## 3. Payment acceptance and refunds

Configure a Razorpay webhook at:

`https://YOUR_DOMAIN/api/v1/checkout/webhook/`

Subscribe to `payment.captured`, `refund.processed` and `refund.failed`. Configure the same webhook secret on the backend. The raw payload is HMAC-SHA256 verified; duplicate event IDs are guarded. Unmapped signed events return a retryable error and are counted in monitoring.

Customer checkout creates an order from the server-calculated booking total, split into rental and refundable deposit. It is not possible to supply a client price or mark an arbitrary payment successful through the legacy API. Browser checkout callbacks only request server verification; they do not establish success.

Staff can verify an order and request a bounded partial refund from Payments. Requests use local UUID idempotency keys and Razorpay's refund idempotency header. API acceptance leaves the refund pending; only a verified processed event/authenticated fetch reduces the paid balance. Unknown requests reserve their amount until reconciliation. A failed refund releases that reservation. Refund allocation returns deposit first, then rental; confirm this business policy before launch.

Manual recovery commands:

```bash
python manage.py reconcile_payments --order LOCAL_ORDER_UUID
# If order creation timed out, find the receipt in the provider dashboard first:
python manage.py adopt_gateway_order LOCAL_ORDER_UUID order_PROVIDER_ID
python manage.py reconcile_payments --order LOCAL_ORDER_UUID
```

The adoption command fetches and checks receipt, currency and amount. Do not create another charge just because a previous request timed out. Existing historical paid records are not retroactively certified by this update; reconcile/migrate them separately.

Test acceptance scenarios in Razorpay test mode: successful capture, failed checkout, duplicate webhook delivery, missed webhook recovery, partial refund, duplicate refund request, failed refund and provider timeout. Check provider dashboard totals against the local ledger. Then use live keys only after merchant onboarding and staging acceptance. Provider-side test/live execution has not been performed in this workspace.

## 4. Documents and existing uploads

The customer Account page supports private KYC upload/download. Uploaded documents reset KYC to submitted; a branch employee must review again. Staff use scoped customer review actions. Downloads require the owner or an authorized branch employee and emit an audit event. The proxy serves only public vehicle/profile image folders; private uploads are never mounted into the proxy.

For an existing installation, migrate old document files during maintenance:

```bash
python manage.py migrate_private_documents --remove-public
```

This validates/scans each recognized historical local file, saves it privately, updates its database field and removes the old public copy after success. Missing/unrecognized files require manual review. For old S3 objects, remove any historical public access and migrate them explicitly; this command does not silently delete cloud data.

For private S3: enable Block Public Access, versioning, access logging/CloudTrail as appropriate, lifecycle/retention and backup/replication. The adapter requests server-side AES256 encryption. Bucket configuration is an operator responsibility; the live probe checks public-access blocking when credentials are available.

## 5. Backups and restore drills

Set BACKUP_AGE_RECIPIENT to an **age public recipient**; keep the private decryption identity offline in a secure recovery location. Set BACKUP_S3_BUCKET to a separate restricted backup bucket if offsite upload is required. Enable versioning/retention on it. The image includes age and PostgreSQL client tools.

```bash
docker compose --env-file .env.production -f deployment/docker-compose.yml exec backup python scripts/backup.py
```

Celery beat schedules this at 02:30 in the configured application timezone. It creates a pg_dump custom-format snapshot plus local public/private media, encrypts the bundle with age, computes SHA-256, optionally uploads the encrypted object to S3 and records completion status. No backup is silently considered successful if a dump, encryption or requested upload fails. S3-backed source documents require their own versioned object backup; local media archives cannot substitute for that.

Restore into a **new isolated database and media directories**, never directly into the live database:

1. Retrieve the encrypted backup and verify its recorded SHA-256.
2. Decrypt with `age --decrypt -i /secure/recovery-identity -o recovery.tar backup.tar.age` on a trusted recovery machine.
3. Extract into a restricted temporary directory, inspect the manifest, then use pg_restore with `--exit-on-error` into an empty recovery database.
4. Start an isolated app with restored media/private media, verify migrations, logins, booking/ledger counts and representative authorized document downloads.
5. Record recovery time/data age. Destroy the drill environment securely after review. Actual production cutover needs an explicit maintenance/rollback plan.

The CI script `scripts/backup_restore_ci.sh` validates an unencrypted disposable pg_dump/restore round trip inside test containers. It is not a production restore command. An actual encrypted offsite recovery drill remains required before launch.

## 6. Monitoring and live gates

`/health/live/` checks process liveness; `/health/ready/` checks database/cache without disclosing exception strings. The private `/internal/metrics` requires a dedicated bearer token and is denied by the public proxy. Prometheus configuration and alert rules are provided in deployment/. Run your collector on the private Docker network and configure Alertmanager recipients explicitly. Sentry is optional via SENTRY_DSN and defaults to no personal information.

Monitor uncertain payments, unmatched webhooks, delivery failures, stale worker heartbeat and stale backups. Wire alerts to a real on-call destination and test an alert; a YAML file alone does not send notifications. SMS API acceptance is recorded as pending, not delivered. Run `python manage.py reconcile_sms` to fetch provider delivery states. Provider delivery reports/recipient-device testing are separate acceptance checks. SMTP probe success is connection/authentication, not proof of inbox delivery.

```bash
bash scripts/production_preflight.sh
python scripts/verify_https.py https://YOUR_DOMAIN
# inside the configured backend:
python manage.py check_integrations --live --report integration-report.json
```

Live probes are read-only: they check payment credentials, request an AI response, authenticate SMTP/Twilio and check storage/scanner access. They never charge a card, issue a refund or send email/SMS. Test delivery to your own explicitly chosen email/phone through the normal application separately.

## 7. CI gates

The `.github/workflows/production-gates.yml` workflow has:

- A PostgreSQL 16 service, migrations, all tests including concurrent booking/refund/webhook tests and the PostgreSQL immutable-ledger trigger.
- Frontend production build.
- Container builds, isolated HTTPS with Caddy's internal test CA, private-media denial, Django production checks and a disposable database restore drill.

Run it after placing the extracted source at the root of your Git repository. CI credentials are generated for disposable infrastructure; they are not production keys. No workflow execution or production deployment is claimed until those jobs actually succeed.

### Security update rollout

- Generate a separate random `REDIS_PASSWORD` and set it in `.env.production` before recreating the Compose services. The application, workers, and Redis must use the same value. Keep database owner credentials separate from application credentials.
- For an S3 backup target, configure `BACKUP_AWS_ACCESS_KEY_ID`, `BACKUP_AWS_SECRET_ACCESS_KEY`, and `BACKUP_AWS_REGION` separately from private-upload credentials. Restrict the backup account to writing the backup prefix.
- Run the database migrations with old web and worker processes stopped. The migration invalidates older OTPs and clears existing phone verification flags so users can re-verify their numbers. Drivers using the former shared password must reset it. Existing browser users must sign in again.
- Test both payment event orders in the Razorpay sandbox. A verified capture for a cancelled booking creates a durable refund request. The payments worker submits queued requests and the provider webhook or reconciliation records final settlement. Investigate refunds left in initiating, unknown, or failed state before retrying. Use `reconcile_payments --order <local-order-id>` to check Razorpay after an interrupted submission.
- Use the same HTTPS site for the browser frontend and API so the refresh cookie is sent. API clients that use bearer tokens can continue to submit refresh tokens directly and should sign in again after upgrading.

> Historical review of the first premium edition. The new hardening update supersedes the implementation status below; see [PRODUCTION_READINESS.md](PRODUCTION_READINESS.md).

# FleetPro project review and improvement plan

Reviewed against the uploaded Fleetpro(2).zip on 31 October 2026. Findings below come from source inspection and local execution, rather than assumptions about features in a deployed system.

## Assessment

The source has a useful rental-domain foundation: accounts, fleet, branches, bookings, drivers, KYC, payments, damage and notifications. The original archive was not a ready-to-run production system. It contained combined source fragments, missing imports/classes, schema duplication and multiple UI controls that did not perform their advertised operation.

This update fixes the core startup, recommendation, customer booking and role-routing paths, and introduces the requested brand system and two interfaces. It does not claim the remaining financial, deployment and analytics modules are production-complete.

## Original drawbacks and what changed

| Priority | Drawback and evidence | Effect | This update |
| --- | --- | --- | --- |
| Critical | `frontend/src/pages/DashboardPage.jsx` contained imports inside a function, repeated imports, a duplicate default export and a self re-export. | Frontend could not compile reliably. | Replaced with a clean role-aware dashboard; production build passes. |
| Critical | Duplicate Driver/DriverAttendance models in `apps/customers/models.py`, duplicate admin registrations in `apps/authentication/admin.py`, missing validators and authentication utilities. | Django failed startup/system checks. | Kept one canonical model and registration per entity; restored utilities/imports; checks pass. |
| Critical | No app migration directories; master routes imported nonexistent analytics views and an unused nonexistent booking serializer. | Installation and API routing were incomplete. | Generated initial migrations, supplied routed analytics views and removed the invalid import. |
| High | Customers could access generic booking updates and invoke KYC actions through overly broad ownership permissions. | A customer could attempt unauthorized status/financial/KYC changes. | Restricted employee booking mutations, KYC decisions, blacklist changes and customer profile writes; added regression tests. |
| High | `requirements.txt` pinned Django 4.2.11 and older auth/filter integrations. | The framework line had reached the end of extended support. | Upgraded Django to 5.2.18 and compatible DRF, JWT, filter, OTP, schema and scheduler packages; reran the complete suite. Broader dependency modernization remains. |
| High | Original dashboard read field names absent from its API and displayed hardcoded recent events. | Misleading empty/zero values and sample activity appeared as live operations. | Uses actual response fields and current booking data with loading, error and empty states. |
| High | One employee-oriented shell served all users. | Poor customer discovery/conversion flow and unnecessary operational controls. | Separate luxury customer shell and dense employee shell, selected by authenticated role. |
| High | No recommendation service or integrated chatbot. | Users had to choose vehicles manually; support was static. | Added content recommendations, optional AI ordering and an optional generative concierge with visible local fallback. |
| High | Partial-day calculations ignored remaining minutes when rounding. | Sub-hour rentals could be billed incorrectly. | Uses ceiling of elapsed seconds divided by one day; tested short and partial-day rentals. |
| Medium | Registration created a customer profile a second time; Celery app was not exported; OTP task module was missing. | Registration/task flows failed. | Idempotent profile creation, Celery initialization and OTP dispatch module supplied. |
| Medium | Booking notifications ran before commit or were duplicated; pending requests were described as confirmed. | Race conditions and confusing communication. | Booking and payment tasks are queued after commit; removed duplicate booking signal dispatch; pending messages show their true status. A durable outbox is still needed. |
| Medium | Settings showed successful saves without persisting business/notification preferences. | Users received false confirmation. | Replaced with profile/password forms connected to real endpoints; omitted unsupported preference controls. |
| Medium | Employee new-booking UI stopped at a “complete via API” toast. | Staff could not finish the visible workflow. | Added verified-customer selection, availability search and actual pending booking creation. |
| Medium | JWT refresh rotation did not retain the new refresh token; login errors entered the refresh flow. | Sessions could fail after rotation. | Saves rotated refresh tokens, avoids auth endpoint recursion and clears query data on logout. |
| Medium | CSS was not imported from the main entry point; tables/modal forms were not responsive. | Inconsistent appearance and difficult mobile use. | Imports a shared design layer; adds responsive layouts, scrollable employee tables, focus states, modal focus management and reduced-motion support. |

The Django support finding is backed by the official [7 April 2026 security release notice](https://www.djangoproject.com/weblog/2026/apr/07/security-releases/), which states that Django 4.2 reached the end of extended support. The update does not imply that every third-party dependency is now current or vulnerability-free.

## Brand system

| Element | Shared design | Customer portal | Employee dashboard |
| --- | --- | --- | --- |
| Colors | Forest `#173c32`, champagne `#d8be8a`, ivory `#f6f4ee`; semantic statuses | Ivory editorial surfaces and an immersive touring illustration | Deep-green navigation and restrained operational panels |
| Typography | DM Sans with Arial fallback; Georgia display family | Large serif headlines, generous spacing, concise vehicle stories | Compact labels, tabular numbers, legible data tables |
| Motion | `cubic-bezier(.22,1,.36,1)`; reduced-motion override | Subtle image zoom and card elevation | Brief navigation/control transitions |
| Goal | A coherent FleetPro identity | Discovery, preference matching and reservation requests | Fast fleet monitoring and reservation control |

The design is intentionally original. Add licensed photographs of the actual vehicles to replace the included generic car/motorcycle illustrations; do not imply that a fallback illustration depicts a specific model.

## Recommendation system

`POST /api/v1/intelligence/recommendations/` is authenticated and limited to 20 requests/minute per user along with the chat endpoint.

The first stage filters active, currently available vehicles from active branches/categories. City, minimum seats, maximum daily budget, fuel and transmission are hard constraints. If dates are supplied, both are required, they must be in the future and within the configured rental duration, and conflicting pending/confirmed/active bookings are excluded. Scheduled service on or before the return date is treated conservatively as a blocker.

The content scorer prefers category matches, requested budget fit, rating and—only with opt-in—the authenticated customer's completed rental categories. It returns reasons and a preference score. This is an explainable content recommender, not a trained collaborative model or a statistical likelihood of satisfaction.

With a configured key and explicit opt-in, AI orders the top 12 eligible candidates using the trip description. It cannot introduce a new vehicle, alter a rate, override a filter or create a reservation. Invalid ordering or provider failures fall back to the content scorer. Candidate ordering is limited to the shortlist; it does not semantically search the entire fleet.

Before scaling, move monetary constraints and shortlist generation fully into database queries, index the candidate features, record consented impressions/selections and evaluate results. Suggested metrics: recommendation click-through, booking conversion, coverage, no-match rate, latency and cancellation rate. Compare by city, category and new versus returning users. Add collaborative ranking only when there is enough clean interaction data.

## Chatbot

`POST /api/v1/intelligence/chat/` validates message length, history roles and history size. It provides:

- Local rental requirements/policy guidance.
- Locally scoped summaries of the authenticated customer's latest bookings.
- Optional server-side OpenAI generation for general catalog/rental questions after consent.
- Visible local fallback when external generation is disabled or unavailable.

Only allowlisted catalog facts are queried for external grounding. No customer profile, KYC document, card data, GPS device identifier or internal fleet note is deliberately added to the provider context. The browser excludes locally generated account summaries from subsequent AI history; user-entered messages can still contain personal information, so the consent text asks users to avoid it. Chat is session-local in the interface, not persisted to a conversation database.

The model has no write tools and cannot process payment or confirm/change reservations. Prompt instructions reduce—but cannot eliminate—hallucinations or prompt injection. A production assistant needs approved policy retrieval, versioned policy documents, human escalation/ticket creation, multilingual evaluation, abuse handling and operational monitoring. Those are future work, not silently simulated integrations.

The provider adapter follows the [OpenAI Responses API reference](https://developers.openai.com/api/reference/resources/responses/methods/create), including bounded output and `store=false`. Provider access and billing must be configured separately.

## Remaining limitations and recommended sequence

### Before real transactions

1. **Repair the payment/refund ledger.** Existing staff APIs record payments/refunds as successful without proving a gateway settlement. Refund validation/reconciliation is incomplete. Add signed webhook verification, event idempotency, immutable ledger entries, amount bounds and partial-refund accounting. Clearly separate initiation, settlement and failure; reconcile deposits, tax and refunds. Do not treat a local database record as money moved.
2. **Enforce branch authorization server-side.** Staff access is primarily role-based and often global. Scope querysets, related-object choices, analytics and AI catalog access to allowed branches where the business requires it. Add cross-branch tests.
3. **Protect documents and uploads.** Separate public vehicle photography from KYC/inspection/signature files. Use private object storage with expiring authorized downloads, size/type validation, malware scanning and retention rules. The provided media-serving configuration is not suitable for exposing private documents.
4. **Harden booking concurrency.** Creation locks the vehicle row on PostgreSQL, but local SQLite tests do not prove concurrent behavior. Staff update/transition paths and driver allocation need dedicated locked service methods and database constraints. Add a pending-hold expiry policy so abandoned requests do not block vehicles indefinitely.
5. **Harden auth and delivery.** Move browser tokens to a secure cookie/session design, complete OTP attempt accounting and password-reset/session invalidation, require MFA for privileged users, and use a transactional outbox for reliable task dispatch and delivery retries. Current OTP storage and mock SMS behavior need production review.

### Before deployment

6. **Validate the deployment environment.** The Docker stack and TLS were not launched here. Configure actual hostnames/certificates, trusted proxy boundaries, persistent volumes, secrets and monitoring. Recheck health/readiness behavior and container permissions. Run supported dependency/security audits and test the remaining pinned packages.
7. **Complete every operational page.** Existing drivers, damage, payment and customer screens retain parts of the original implementation. Some actions such as CSV export still need completion; list pagination/search and error behavior need consistency. Consolidated modules and re-exports remain technical debt.
8. **Verify analytics definitions.** Basic revenue/booking endpoints work, but advanced existing queries may double-count joined records or use inconsistent time windows and field names. Define gross/net rental revenue, deposits, refunds and utilization precisely, then compare reports against ledger fixtures.
9. **Test accessibility broadly.** Keyboard/focus and responsive improvements are included, but this is not a WCAG certification. Run screen-reader, zoom, contrast and touch-target testing across the complete application; some older employee forms still need accessibility work.
10. **Improve the recommender and assistant with evidence.** Start with consented event collection and offline evaluation. Then add approved policy retrieval, multilingual chat, real staff handoff, recommendation feedback and quality/cost monitoring. Predictive maintenance, demand forecasting and dynamic pricing need appropriate historical data and human oversight before use.

## Scope of validation

See `VALIDATION.md`. Local tests, migrations, API smoke tests and browser checks passed. PostgreSQL races, live model generation, gateway settlement, external email/SMS delivery, S3 and Docker/TLS deployment were not verified. These limits are material: this update is a stronger development baseline, not a claim of production readiness.

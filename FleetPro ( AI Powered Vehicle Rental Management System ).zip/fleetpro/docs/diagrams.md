# FleetPro — System Architecture & UML Diagrams
# All diagrams in Mermaid format — render at https://mermaid.live

## 1. SYSTEM ARCHITECTURE DIAGRAM
```mermaid
graph TB
    subgraph "Client Layer"
        Browser["🌐 Browser (React SPA)"]
        Mobile["📱 Mobile App"]
        Admin["🖥️ Admin Panel"]
    end

    subgraph "Infrastructure Layer"
        Nginx["🔀 Nginx\nReverse Proxy\nSSL + Rate Limit"]
    end

    subgraph "Application Layer"
        Django["🐍 Django REST\nGunicorn 4x\nPort 8000"]
        React["⚛️ React Vite\nPort 3000"]
        Celery["⚙️ Celery Workers\n4 Concurrent"]
        Beat["⏰ Celery Beat\nScheduler"]
    end

    subgraph "Data Layer"
        PG[("🐘 PostgreSQL 15\nPrimary DB\n22 Tables")]
        Redis[("🔴 Redis 7\nCache + Broker")]
    end

    subgraph "External Services"
        S3["☁️ AWS S3\nFile Storage"]
        Razorpay["💳 Razorpay\nPayments"]
        Twilio["📲 Twilio\nSMS"]
        SMTP["📧 SMTP\nEmail"]
        Sentry["🔍 Sentry\nMonitoring"]
    end

    Browser & Mobile & Admin --> Nginx
    Nginx --> React
    Nginx --> Django
    Django --> PG
    Django --> Redis
    Django --> S3
    Django --> Razorpay
    Celery --> PG
    Celery --> Redis
    Celery --> Twilio
    Celery --> SMTP
    Beat --> Celery
    Django --> Sentry
```

---

## 2. BOOKING SEQUENCE DIAGRAM
```mermaid
sequenceDiagram
    actor Customer
    participant React as React App
    participant API as Django API
    participant DB as PostgreSQL
    participant Queue as Celery
    participant Notify as Notification Service

    Customer->>React: Select vehicle + dates
    React->>API: POST /bookings/check-availability/
    API->>DB: SELECT with overlap detection
    DB-->>API: is_available: true
    API-->>React: {is_available: true, vehicles[]}

    Customer->>React: Confirm booking
    React->>API: POST /bookings/ {vehicle_id, dates, customer}
    API->>DB: BEGIN TRANSACTION
    API->>DB: SELECT FOR UPDATE vehicle
    API->>DB: Re-check availability (within lock)
    alt Vehicle taken
        DB-->>API: Conflict found
        API-->>React: 409 Conflict
        React-->>Customer: "Vehicle unavailable. Please choose another."
    else Available
        API->>DB: INSERT booking (status=pending)
        API->>DB: Calculate total amount
        API->>DB: COMMIT
        DB-->>API: Booking created
        API->>Queue: send_booking_confirmation.delay(booking_id)
        Queue->>Notify: Send email + SMS
        Notify-->>Customer: Booking confirmation notification
        API-->>React: 201 Created {booking}
        React-->>Customer: "Booking confirmed! ✓"
    end

    Note over API,DB: Admin confirms booking
    API->>DB: UPDATE booking SET status='confirmed'
    DB->>DB: Trigger: no vehicle status change yet

    Note over API,DB: Staff activates on vehicle pickup
    API->>DB: UPDATE booking SET status='active'
    DB->>DB: Trigger: vehicle.status = 'rented'
    DB->>DB: Trigger: driver.availability = 'on_duty'
    API->>Queue: send_return_reminder.apply_async(eta=return-24h)

    Note over API,DB: Return + completion
    API->>DB: UPDATE booking SET status='completed'
    DB->>DB: Trigger: vehicle.status = 'available'
    DB->>DB: Trigger: customer.total_spend += amount
    DB->>DB: Trigger: customer.loyalty_points += points
    API->>Queue: send_payment_receipt.delay(payment_id)
```

---

## 3. DATA FLOW DIAGRAM — Level 1
```mermaid
flowchart TD
    C([Customer]) -->|Register/Login| AUTH
    C -->|Book Vehicle| BOOK
    C -->|Make Payment| PAY
    C -->|View History| HIST

    SA([Super Admin]) -->|Manage Fleet| VEH
    SA -->|View Reports| ANA
    SA -->|User Management| AUTH

    ST([Staff]) -->|Activate/Complete Booking| BOOK
    ST -->|Record Inspection| INSP
    ST -->|Log Damage| DAM

    D([Driver]) -->|View Assignment| BOOK
    D -->|Update Availability| DRV

    subgraph "FleetPro System"
        AUTH[Auth & Access Control]
        BOOK[Booking Engine]
        VEH[Vehicle Management]
        PAY[Payment Processing]
        DAM[Damage & Penalty]
        ANA[Analytics Engine]
        INSP[Inspection Module]
        DRV[Driver Management]
        NOTIF[Notification Service]
    end

    subgraph "Data Stores"
        PG[(PostgreSQL)]
        REDIS[(Redis Cache)]
        S3[(AWS S3)]
    end

    AUTH <--> PG
    BOOK <--> PG
    VEH <--> PG
    PAY <--> PG
    DAM <--> PG
    ANA <--> PG
    BOOK --> NOTIF
    PAY --> NOTIF
    VEH --> S3
    ANA --> REDIS
```

---

## 4. CLASS DIAGRAM (Domain Model)
```mermaid
classDiagram
    class User {
        +UUID id
        +String email
        +String role
        +String first_name
        +Boolean is_active
        +login()
        +logout()
        +reset_password()
    }

    class Vehicle {
        +UUID id
        +String registration_number
        +String make
        +String model
        +String status
        +Decimal price_per_day
        +get_daily_rate()
        +get_security_deposit()
        +check_availability(from, to)
    }

    class Booking {
        +UUID id
        +String booking_number
        +DateTime pickup_datetime
        +DateTime return_datetime
        +String status
        +Decimal total_amount
        +calculate_total()
        +check_vehicle_availability()
        +cancel(reason)
        +activate(odometer)
        +complete(odometer)
    }

    class Payment {
        +UUID id
        +String transaction_id
        +Decimal amount
        +String status
        +String method
        +process()
        +refund()
    }

    class CustomerProfile {
        +UUID id
        +String kyc_status
        +Integer total_bookings
        +Decimal total_spend
        +verify_kyc()
        +blacklist(reason)
    }

    class Driver {
        +UUID id
        +String employee_id
        +String dl_number
        +String availability_status
        +Decimal daily_rate
        +assign_booking()
        +update_availability()
    }

    class DamageReport {
        +UUID id
        +String severity
        +Decimal estimated_cost
        +Boolean is_insurance_claimed
        +assess()
        +claim_insurance()
        +charge_customer()
    }

    class VehicleCategory {
        +String name
        +String type
        +Decimal base_price_per_day
        +Decimal security_deposit
    }

    User "1" --> "0..1" CustomerProfile
    User "1" --> "0..1" Driver
    Vehicle "*" --> "1" VehicleCategory
    Booking "*" --> "1" CustomerProfile
    Booking "*" --> "1" Vehicle
    Booking "*" --> "0..1" Driver
    Booking "1" --> "*" Payment
    Booking "1" --> "*" DamageReport
```

---

## 5. USE CASE DIAGRAM
```mermaid
graph LR
    subgraph "Actors"
        SA[Super Admin]
        AD[Admin]
        ST[Staff]
        DR[Driver]
        CU[Customer]
    end

    subgraph "Use Cases"
        UC1[Register / Login]
        UC2[Browse Fleet]
        UC3[Check Availability]
        UC4[Create Booking]
        UC5[Make Payment]
        UC6[Cancel Booking]
        UC7[View Booking History]
        UC8[Submit Review]

        UC9[Confirm Booking]
        UC10[Activate Booking]
        UC11[Complete Booking]
        UC12[Record Inspection]
        UC13[Log Damage]
        UC14[Process Refund]

        UC15[Manage Fleet]
        UC16[Assign Driver]
        UC17[Manage Users]
        UC18[View Analytics]
        UC19[Generate Reports]
        UC20[Configure System]

        UC21[View Assignment]
        UC22[Update Availability]
    end

    CU --> UC1
    CU --> UC2
    CU --> UC3
    CU --> UC4
    CU --> UC5
    CU --> UC6
    CU --> UC7
    CU --> UC8

    ST --> UC9
    ST --> UC10
    ST --> UC11
    ST --> UC12
    ST --> UC13

    AD --> UC14
    AD --> UC15
    AD --> UC16
    AD --> UC17
    AD --> UC18
    AD --> UC19

    SA --> UC20
    SA --> UC17

    DR --> UC21
    DR --> UC22
```

---

## 6. STATE DIAGRAM — Booking Lifecycle
```mermaid
stateDiagram-v2
    [*] --> Draft: Customer starts
    Draft --> Pending: Submit booking
    Pending --> Confirmed: Admin approves
    Pending --> Cancelled: Rejected / Customer cancels
    Confirmed --> Active: Vehicle picked up (staff)
    Confirmed --> Cancelled: Customer cancels (before pickup)
    Confirmed --> NoShow: No pickup within grace period
    Active --> Completed: Vehicle returned
    Active --> Completed: Auto-complete after 48h overdue
    Completed --> [*]
    Cancelled --> [*]
    NoShow --> [*]

    note right of Active: Penalty accrues hourly if overdue\n₹100/hour late fee
    note right of Confirmed: Free cancellation > 24h before pickup\n10% fee < 24h before pickup
```

---

## 7. DEPLOYMENT DIAGRAM
```mermaid
graph TB
    subgraph "Production Server"
        subgraph "Docker Network: fleetpro_network"
            N[nginx:443/80]
            B[backend:8000\nDjango+Gunicorn]
            F[frontend:3000\nReact+Vite]
            W[celery_worker]
            BT[celery_beat]
            PG[(postgres:5432)]
            RD[(redis:6379)]
        end

        VOL1[/postgres_data/]
        VOL2[/redis_data/]
        VOL3[/media_files/]
        VOL4[/static_files/]
    end

    Internet -->|HTTPS 443| N
    N -->|proxy_pass| F
    N -->|proxy_pass /api/| B
    N -->|/static/| VOL4
    N -->|/media/| VOL3
    B --> PG
    B --> RD
    W --> PG
    W --> RD
    BT --> RD
    PG --- VOL1
    RD --- VOL2
    B --- VOL3
    B --- VOL4
```

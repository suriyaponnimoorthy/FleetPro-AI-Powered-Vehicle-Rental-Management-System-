-- =============================================================
-- FleetPro Vehicle Rental Management System
-- PostgreSQL Schema v1.0
-- 22 normalized tables, full indexing, views, procedures, triggers
-- =============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";        -- For full-text search
CREATE EXTENSION IF NOT EXISTS "btree_gin";       -- For composite GIN indexes

-- =============================================================
-- 1. BRANCHES
-- =============================================================
CREATE TABLE vehicle_branches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200)    NOT NULL,
    code            VARCHAR(10)     NOT NULL UNIQUE,
    address         TEXT            NOT NULL,
    city            VARCHAR(100)    NOT NULL,
    state           VARCHAR(100)    NOT NULL,
    pincode         VARCHAR(10)     NOT NULL,
    phone           VARCHAR(20)     NOT NULL,
    email           VARCHAR(254),
    latitude        DECIMAL(9,6),
    longitude       DECIMAL(9,6),
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    opening_time    TIME            NOT NULL DEFAULT '08:00',
    closing_time    TIME            NOT NULL DEFAULT '20:00',
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 2. USERS (AUTH)
-- =============================================================
CREATE TABLE auth_users (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                   VARCHAR(254)    NOT NULL UNIQUE,
    phone                   VARCHAR(20),
    password                VARCHAR(128)    NOT NULL,
    first_name              VARCHAR(100)    NOT NULL,
    last_name               VARCHAR(100)    NOT NULL,
    role                    VARCHAR(20)     NOT NULL CHECK (role IN ('super_admin','admin','staff','driver','customer')),
    profile_photo           VARCHAR(500),
    branch_id               UUID            REFERENCES vehicle_branches(id) ON DELETE SET NULL,
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    is_staff                BOOLEAN         NOT NULL DEFAULT FALSE,
    is_superuser            BOOLEAN         NOT NULL DEFAULT FALSE,
    is_email_verified       BOOLEAN         NOT NULL DEFAULT FALSE,
    is_phone_verified       BOOLEAN         NOT NULL DEFAULT FALSE,
    is_kyc_verified         BOOLEAN         NOT NULL DEFAULT FALSE,
    date_joined             TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    last_login              TIMESTAMPTZ,
    last_login_ip           INET,
    failed_login_attempts   SMALLINT        NOT NULL DEFAULT 0,
    locked_until            TIMESTAMPTZ
);

CREATE INDEX idx_users_email_role     ON auth_users(email, role);
CREATE INDEX idx_users_role_active    ON auth_users(role, is_active);
CREATE INDEX idx_users_phone          ON auth_users(phone) WHERE phone IS NOT NULL;

-- =============================================================
-- 3. OTP VERIFICATIONS
-- =============================================================
CREATE TABLE auth_otp_verifications (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID        NOT NULL REFERENCES auth_users(id) ON DELETE CASCADE,
    otp_type    VARCHAR(20) NOT NULL CHECK (otp_type IN ('email_verify','phone_verify','password_reset','login_2fa')),
    code        VARCHAR(6)  NOT NULL,
    is_used     BOOLEAN     NOT NULL DEFAULT FALSE,
    attempts    SMALLINT    NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX idx_otp_user_type ON auth_otp_verifications(user_id, otp_type, is_used);

-- =============================================================
-- 4. ACTIVITY LOGS
-- =============================================================
CREATE TABLE auth_activity_logs (
    id          BIGSERIAL PRIMARY KEY,
    user_id     UUID        REFERENCES auth_users(id) ON DELETE SET NULL,
    action      VARCHAR(20) NOT NULL,
    model_name  VARCHAR(100),
    object_id   VARCHAR(100),
    description TEXT,
    ip_address  INET,
    user_agent  TEXT,
    changes     JSONB       DEFAULT '{}',
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_activity_user_ts      ON auth_activity_logs(user_id, timestamp DESC);
CREATE INDEX idx_activity_action_ts    ON auth_activity_logs(action, timestamp DESC);
CREATE INDEX idx_activity_model_obj    ON auth_activity_logs(model_name, object_id);

-- =============================================================
-- 5. VEHICLE CATEGORIES
-- =============================================================
CREATE TABLE vehicle_categories (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name                VARCHAR(100)        NOT NULL UNIQUE,
    type                VARCHAR(20)         NOT NULL CHECK (type IN ('car','bike','luxury','electric','commercial')),
    description         TEXT,
    icon                VARCHAR(100),
    base_price_per_day  DECIMAL(10,2)       NOT NULL,
    base_price_per_hour DECIMAL(10,2)       NOT NULL,
    security_deposit    DECIMAL(10,2)       NOT NULL DEFAULT 5000,
    is_active           BOOLEAN             NOT NULL DEFAULT TRUE,
    sort_order          SMALLINT            NOT NULL DEFAULT 0
);

-- =============================================================
-- 6. VEHICLES
-- =============================================================
CREATE TABLE vehicles (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    registration_number     VARCHAR(20)     NOT NULL UNIQUE,
    make                    VARCHAR(100)    NOT NULL,
    model                   VARCHAR(100)    NOT NULL,
    variant                 VARCHAR(100),
    year                    SMALLINT        NOT NULL,
    color                   VARCHAR(50)     NOT NULL,
    category_id             UUID            NOT NULL REFERENCES vehicle_categories(id) ON DELETE RESTRICT,
    branch_id               UUID            NOT NULL REFERENCES vehicle_branches(id) ON DELETE RESTRICT,
    status                  VARCHAR(20)     NOT NULL DEFAULT 'available'
                                CHECK (status IN ('available','rented','reserved','maintenance','inactive','retired')),
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    fuel_type               VARCHAR(20)     NOT NULL CHECK (fuel_type IN ('petrol','diesel','electric','hybrid','cng')),
    transmission            VARCHAR(20)     NOT NULL DEFAULT 'manual',
    seating_capacity        SMALLINT        NOT NULL DEFAULT 5,
    engine_cc               SMALLINT,
    mileage_kmpl            DECIMAL(5,1),
    odometer_reading        INTEGER         NOT NULL DEFAULT 0,
    price_per_day           DECIMAL(10,2),          -- NULL = use category price
    price_per_hour          DECIMAL(10,2),
    security_deposit        DECIMAL(10,2),
    rc_number               VARCHAR(50),
    rc_expiry_date          DATE,
    fitness_expiry_date     DATE,
    permit_expiry_date      DATE,
    pollution_expiry_date   DATE,
    gps_device_id           VARCHAR(100),
    last_known_lat          DECIMAL(9,6),
    last_known_lng          DECIMAL(9,6),
    last_location_update    TIMESTAMPTZ,
    features                JSONB           DEFAULT '[]',
    description             TEXT,
    notes                   TEXT,
    total_trips             INTEGER         NOT NULL DEFAULT 0,
    average_rating          DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vehicles_status_branch   ON vehicles(status, branch_id);
CREATE INDEX idx_vehicles_category_status ON vehicles(category_id, status);
CREATE INDEX idx_vehicles_reg_num         ON vehicles(registration_number);
CREATE INDEX idx_vehicles_fuel_status     ON vehicles(fuel_type, status);
-- Full-text search on make+model
CREATE INDEX idx_vehicles_fts ON vehicles USING gin(to_tsvector('english', make || ' ' || model));

-- =============================================================
-- 7. VEHICLE IMAGES
-- =============================================================
CREATE TABLE vehicle_images (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id  UUID        NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    image       VARCHAR(500) NOT NULL,
    caption     VARCHAR(200),
    is_primary  BOOLEAN     NOT NULL DEFAULT FALSE,
    sort_order  SMALLINT    NOT NULL DEFAULT 0,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_vehicle_images_vehicle ON vehicle_images(vehicle_id, is_primary);

-- =============================================================
-- 8. VEHICLE INSURANCE
-- =============================================================
CREATE TABLE vehicle_insurance (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id          UUID            NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    policy_number       VARCHAR(100)    NOT NULL UNIQUE,
    insurance_company   VARCHAR(200)    NOT NULL,
    insurance_type      VARCHAR(20)     NOT NULL CHECK (insurance_type IN ('comprehensive','third_party','zero_dep')),
    start_date          DATE            NOT NULL,
    end_date            DATE            NOT NULL,
    premium_amount      DECIMAL(12,2)   NOT NULL,
    insured_value       DECIMAL(14,2)   NOT NULL,
    agent_name          VARCHAR(200),
    agent_phone         VARCHAR(20),
    document            VARCHAR(500),
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_insurance_vehicle_active ON vehicle_insurance(vehicle_id, is_active, end_date);

-- =============================================================
-- 9. MAINTENANCE SCHEDULES
-- =============================================================
CREATE TABLE vehicle_maintenance_schedules (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id          UUID        NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    maintenance_type    VARCHAR(20) NOT NULL,
    status              VARCHAR(20) NOT NULL DEFAULT 'scheduled'
                            CHECK (status IN ('scheduled','in_progress','completed','cancelled','overdue')),
    scheduled_date      DATE        NOT NULL,
    completed_date      DATE,
    odometer_at_service INTEGER,
    next_service_km     INTEGER,
    next_service_date   DATE,
    service_center      VARCHAR(200),
    technician_name     VARCHAR(200),
    estimated_cost      DECIMAL(10,2) NOT NULL DEFAULT 0,
    actual_cost         DECIMAL(10,2),
    description         TEXT,
    parts_replaced      JSONB       DEFAULT '[]',
    created_by_id       UUID        REFERENCES auth_users(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_maintenance_vehicle_status   ON vehicle_maintenance_schedules(vehicle_id, status);
CREATE INDEX idx_maintenance_scheduled_status ON vehicle_maintenance_schedules(scheduled_date, status);

-- =============================================================
-- 10. CUSTOMER PROFILES
-- =============================================================
CREATE TABLE customer_profiles (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID            NOT NULL UNIQUE REFERENCES auth_users(id) ON DELETE CASCADE,
    date_of_birth           DATE,
    gender                  VARCHAR(10)     CHECK (gender IN ('male','female','other','prefer_not')),
    address                 TEXT,
    city                    VARCHAR(100),
    state                   VARCHAR(100),
    pincode                 VARCHAR(10),
    emergency_contact_name  VARCHAR(200),
    emergency_contact_phone VARCHAR(20),
    dl_number               VARCHAR(50),
    dl_expiry_date          DATE,
    dl_document             VARCHAR(500),
    aadhar_number           VARCHAR(20),
    aadhar_document         VARCHAR(500),
    pan_number              VARCHAR(10),
    kyc_status              VARCHAR(20)     NOT NULL DEFAULT 'pending'
                                CHECK (kyc_status IN ('pending','submitted','verified','rejected')),
    kyc_verified_at         TIMESTAMPTZ,
    kyc_verified_by         UUID            REFERENCES auth_users(id) ON DELETE SET NULL,
    total_bookings          INTEGER         NOT NULL DEFAULT 0,
    total_spend             DECIMAL(14,2)   NOT NULL DEFAULT 0.00,
    loyalty_points          INTEGER         NOT NULL DEFAULT 0,
    is_blacklisted          BOOLEAN         NOT NULL DEFAULT FALSE,
    blacklist_reason        TEXT,
    notes                   TEXT,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_customer_kyc_status ON customer_profiles(kyc_status);
CREATE INDEX idx_customer_blacklisted ON customer_profiles(is_blacklisted);

-- =============================================================
-- 11. DRIVER PROFILES
-- =============================================================
CREATE TABLE driver_profiles (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID            NOT NULL UNIQUE REFERENCES auth_users(id) ON DELETE CASCADE,
    branch_id           UUID            REFERENCES vehicle_branches(id) ON DELETE SET NULL,
    employee_id         VARCHAR(20)     NOT NULL UNIQUE,
    date_of_birth       DATE,
    address             TEXT,
    city                VARCHAR(100),
    dl_number           VARCHAR(50)     NOT NULL UNIQUE,
    dl_expiry_date      DATE            NOT NULL,
    dl_categories       JSONB           DEFAULT '["LMV"]',
    dl_document         VARCHAR(500),
    aadhar_number       VARCHAR(20),
    aadhar_document     VARCHAR(500),
    police_verification VARCHAR(500),
    experience_years    SMALLINT        NOT NULL DEFAULT 0,
    availability_status VARCHAR(20)     NOT NULL DEFAULT 'available'
                            CHECK (availability_status IN ('available','on_duty','on_leave','inactive')),
    daily_rate          DECIMAL(10,2)   NOT NULL DEFAULT 500.00,
    monthly_salary      DECIMAL(12,2)   NOT NULL DEFAULT 20000.00,
    joining_date        DATE            NOT NULL DEFAULT CURRENT_DATE,
    total_trips         INTEGER         NOT NULL DEFAULT 0,
    average_rating      DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
    total_violations    SMALLINT        NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_driver_branch_status ON driver_profiles(branch_id, availability_status);
CREATE INDEX idx_driver_dl_number     ON driver_profiles(dl_number);

-- =============================================================
-- 12. BOOKINGS (core transactional table)
-- =============================================================
CREATE TABLE bookings (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_number          VARCHAR(20)     NOT NULL UNIQUE,
    customer_id             UUID            NOT NULL REFERENCES customer_profiles(id) ON DELETE RESTRICT,
    vehicle_id              UUID            NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
    driver_id               UUID            REFERENCES driver_profiles(id) ON DELETE SET NULL,
    created_by_id           UUID            REFERENCES auth_users(id) ON DELETE SET NULL,
    approved_by_id          UUID            REFERENCES auth_users(id) ON DELETE SET NULL,
    pickup_datetime         TIMESTAMPTZ     NOT NULL,
    return_datetime         TIMESTAMPTZ     NOT NULL,
    actual_return_datetime  TIMESTAMPTZ,
    pickup_location         VARCHAR(500)    NOT NULL,
    pickup_branch_id        UUID            REFERENCES vehicle_branches(id) ON DELETE SET NULL,
    drop_location           VARCHAR(500)    NOT NULL,
    drop_branch_id          UUID            REFERENCES vehicle_branches(id) ON DELETE SET NULL,
    status                  VARCHAR(20)     NOT NULL DEFAULT 'pending'
                                CHECK (status IN ('draft','pending','confirmed','active','completed','cancelled','no_show')),
    payment_status          VARCHAR(20)     NOT NULL DEFAULT 'pending'
                                CHECK (payment_status IN ('pending','partial','paid','refunded','overdue')),
    base_amount             DECIMAL(12,2)   NOT NULL DEFAULT 0,
    driver_charges          DECIMAL(10,2)   NOT NULL DEFAULT 0,
    discount_amount         DECIMAL(10,2)   NOT NULL DEFAULT 0,
    gst_amount              DECIMAL(10,2)   NOT NULL DEFAULT 0,
    security_deposit        DECIMAL(10,2)   NOT NULL DEFAULT 0,
    total_amount            DECIMAL(12,2)   NOT NULL DEFAULT 0,
    amount_paid             DECIMAL(12,2)   NOT NULL DEFAULT 0,
    odometer_at_pickup      INTEGER,
    odometer_at_return      INTEGER,
    total_km_driven         INTEGER,
    fuel_level_at_pickup    SMALLINT        CHECK (fuel_level_at_pickup BETWEEN 0 AND 100),
    fuel_level_at_return    SMALLINT        CHECK (fuel_level_at_return BETWEEN 0 AND 100),
    with_driver             BOOLEAN         NOT NULL DEFAULT FALSE,
    fuel_policy             VARCHAR(20)     NOT NULL DEFAULT 'full_to_full',
    special_requests        TEXT,
    internal_notes          TEXT,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    confirmed_at            TIMESTAMPTZ,
    activated_at            TIMESTAMPTZ,
    completed_at            TIMESTAMPTZ,
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_dates CHECK (return_datetime > pickup_datetime)
);

CREATE INDEX idx_bookings_vehicle_dates  ON bookings(vehicle_id, pickup_datetime, return_datetime);
CREATE INDEX idx_bookings_customer_status ON bookings(customer_id, status);
CREATE INDEX idx_bookings_status_payment  ON bookings(status, payment_status);
CREATE INDEX idx_bookings_pickup_status   ON bookings(pickup_datetime, status);
CREATE INDEX idx_bookings_driver_status   ON bookings(driver_id, status) WHERE driver_id IS NOT NULL;

-- =============================================================
-- 13. PAYMENTS
-- =============================================================
CREATE TABLE payments (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transaction_id          VARCHAR(100)    NOT NULL UNIQUE,
    booking_id              UUID            NOT NULL REFERENCES bookings(id) ON DELETE RESTRICT,
    customer_id             UUID            NOT NULL REFERENCES customer_profiles(id),
    payment_type            VARCHAR(25)     NOT NULL,
    method                  VARCHAR(20)     NOT NULL,
    status                  VARCHAR(15)     NOT NULL DEFAULT 'pending'
                                CHECK (status IN ('pending','processing','success','failed','refunded','cancelled')),
    amount                  DECIMAL(12,2)   NOT NULL,
    currency                CHAR(3)         NOT NULL DEFAULT 'INR',
    gateway_transaction_id  VARCHAR(200),
    gateway_response        JSONB           DEFAULT '{}',
    taxable_amount          DECIMAL(12,2)   NOT NULL DEFAULT 0,
    cgst                    DECIMAL(10,2)   NOT NULL DEFAULT 0,
    sgst                    DECIMAL(10,2)   NOT NULL DEFAULT 0,
    igst                    DECIMAL(10,2)   NOT NULL DEFAULT 0,
    notes                   TEXT,
    processed_by_id         UUID            REFERENCES auth_users(id) ON DELETE SET NULL,
    paid_at                 TIMESTAMPTZ,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_payments_booking_status   ON payments(booking_id, status);
CREATE INDEX idx_payments_customer_status  ON payments(customer_id, status);
CREATE INDEX idx_payments_type_status      ON payments(payment_type, status);
CREATE INDEX idx_payments_paid_at          ON payments(paid_at) WHERE paid_at IS NOT NULL;

-- =============================================================
-- 14. INVOICES
-- =============================================================
CREATE TABLE invoices (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number  VARCHAR(30)     NOT NULL UNIQUE,
    booking_id      UUID            NOT NULL UNIQUE REFERENCES bookings(id),
    customer_id     UUID            NOT NULL REFERENCES customer_profiles(id),
    status          VARCHAR(15)     NOT NULL DEFAULT 'draft',
    subtotal        DECIMAL(12,2)   NOT NULL,
    discount        DECIMAL(10,2)   NOT NULL DEFAULT 0,
    taxable_amount  DECIMAL(12,2)   NOT NULL,
    cgst_rate       DECIMAL(5,2)    NOT NULL DEFAULT 9.00,
    sgst_rate       DECIMAL(5,2)    NOT NULL DEFAULT 9.00,
    cgst_amount     DECIMAL(10,2)   NOT NULL,
    sgst_amount     DECIMAL(10,2)   NOT NULL,
    total_amount    DECIMAL(12,2)   NOT NULL,
    line_items      JSONB           NOT NULL DEFAULT '[]',
    issued_date     DATE            NOT NULL DEFAULT CURRENT_DATE,
    due_date        DATE            NOT NULL,
    paid_date       DATE,
    pdf_url         VARCHAR(500),
    notes           TEXT,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 15. VEHICLE INSPECTIONS
-- =============================================================
CREATE TABLE vehicle_inspections (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id          UUID        NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    inspection_type     VARCHAR(20) NOT NULL CHECK (inspection_type IN ('pre_rental','post_rental')),
    inspected_by_id     UUID        REFERENCES auth_users(id) ON DELETE SET NULL,
    odometer_reading    INTEGER     NOT NULL,
    fuel_level          SMALLINT    NOT NULL CHECK (fuel_level BETWEEN 0 AND 100),
    body_condition      JSONB       DEFAULT '{}',
    interior_condition  JSONB       DEFAULT '{}',
    tyres_condition     JSONB       DEFAULT '{}',
    accessories_checklist JSONB     DEFAULT '{}',
    overall_condition   VARCHAR(20) NOT NULL,
    damage_noted        BOOLEAN     NOT NULL DEFAULT FALSE,
    damage_description  TEXT,
    customer_signature  VARCHAR(500),
    photos              JSONB       DEFAULT '[]',
    notes               TEXT,
    inspected_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(booking_id, inspection_type)
);

-- =============================================================
-- 16. DAMAGE REPORTS
-- =============================================================
CREATE TABLE damage_reports (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_number           VARCHAR(20)     NOT NULL UNIQUE,
    booking_id              UUID            NOT NULL REFERENCES bookings(id),
    vehicle_id              UUID            NOT NULL REFERENCES vehicles(id),
    customer_id             UUID            NOT NULL REFERENCES customer_profiles(id),
    reported_by_id          UUID            REFERENCES auth_users(id) ON DELETE SET NULL,
    severity                VARCHAR(15)     NOT NULL CHECK (severity IN ('minor','moderate','major','total_loss')),
    status                  VARCHAR(15)     NOT NULL DEFAULT 'reported',
    damage_type             VARCHAR(100)    NOT NULL,
    damage_location         VARCHAR(200)    NOT NULL,
    description             TEXT            NOT NULL,
    estimated_repair_cost   DECIMAL(10,2)   NOT NULL DEFAULT 0,
    actual_repair_cost      DECIMAL(10,2),
    customer_liability_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    insurance_claim_amount  DECIMAL(10,2)   NOT NULL DEFAULT 0,
    photos                  JSONB           DEFAULT '[]',
    inspection_id           UUID            REFERENCES vehicle_inspections(id),
    is_insurance_claimed    BOOLEAN         NOT NULL DEFAULT FALSE,
    insurance_claim_id      VARCHAR(100),
    insurance_policy_id     UUID            REFERENCES vehicle_insurance(id),
    repair_start_date       DATE,
    repair_end_date         DATE,
    repair_vendor           VARCHAR(200),
    customer_acknowledged   BOOLEAN         NOT NULL DEFAULT FALSE,
    resolution_notes        TEXT,
    reported_at             TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_damage_booking_status  ON damage_reports(booking_id, status);
CREATE INDEX idx_damage_vehicle_status  ON damage_reports(vehicle_id, status);

-- =============================================================
-- 17. PENALTIES
-- =============================================================
CREATE TABLE penalties (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id      UUID        NOT NULL REFERENCES bookings(id),
    customer_id     UUID        NOT NULL REFERENCES customer_profiles(id),
    penalty_type    VARCHAR(20) NOT NULL,
    status          VARCHAR(15) NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','paid','disputed','waived')),
    amount          DECIMAL(10,2) NOT NULL,
    description     TEXT        NOT NULL,
    waived_reason   TEXT,
    waived_by_id    UUID        REFERENCES auth_users(id) ON DELETE SET NULL,
    payment_id      UUID        REFERENCES payments(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    paid_at         TIMESTAMPTZ
);

-- =============================================================
-- 18. BOOKING CANCELLATIONS
-- =============================================================
CREATE TABLE booking_cancellations (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id          UUID        NOT NULL UNIQUE REFERENCES bookings(id),
    cancelled_by        VARCHAR(20) NOT NULL CHECK (cancelled_by IN ('customer','admin','system')),
    cancelled_by_user_id UUID       REFERENCES auth_users(id),
    reason              TEXT        NOT NULL,
    cancellation_fee    DECIMAL(10,2) NOT NULL DEFAULT 0,
    refund_amount       DECIMAL(10,2) NOT NULL DEFAULT 0,
    refund_status       VARCHAR(10) NOT NULL DEFAULT 'pending',
    cancelled_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 19. BOOKING REVIEWS
-- =============================================================
CREATE TABLE booking_reviews (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id      UUID        NOT NULL UNIQUE REFERENCES bookings(id),
    customer_id     UUID        NOT NULL REFERENCES auth_users(id),
    vehicle_rating  SMALLINT    NOT NULL CHECK (vehicle_rating BETWEEN 1 AND 5),
    driver_rating   SMALLINT    CHECK (driver_rating BETWEEN 1 AND 5),
    service_rating  SMALLINT    NOT NULL CHECK (service_rating BETWEEN 1 AND 5),
    overall_rating  SMALLINT    NOT NULL CHECK (overall_rating BETWEEN 1 AND 5),
    review_text     TEXT,
    is_published    BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 20. DRIVER ATTENDANCE
-- =============================================================
CREATE TABLE driver_attendance (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id   UUID        NOT NULL REFERENCES driver_profiles(id) ON DELETE CASCADE,
    date        DATE        NOT NULL,
    check_in    TIMESTAMPTZ,
    check_out   TIMESTAMPTZ,
    status      VARCHAR(20) NOT NULL DEFAULT 'present'
                    CHECK (status IN ('present','absent','half_day','leave','holiday')),
    notes       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(driver_id, date)
);

-- =============================================================
-- 21. NOTIFICATION LOGS
-- =============================================================
CREATE TABLE notification_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID        NOT NULL REFERENCES auth_users(id) ON DELETE CASCADE,
    channel         VARCHAR(10) NOT NULL CHECK (channel IN ('email','sms','push','in_app')),
    type            VARCHAR(50) NOT NULL,
    subject         VARCHAR(300),
    body            TEXT        NOT NULL,
    status          VARCHAR(10) NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','sent','failed','read')),
    metadata        JSONB       DEFAULT '{}',
    sent_at         TIMESTAMPTZ,
    read_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user_status ON notification_logs(user_id, status, created_at DESC);

-- =============================================================
-- 22. SUBSCRIPTION PLANS (future SaaS)
-- =============================================================
CREATE TABLE subscription_plans (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name                VARCHAR(100)    NOT NULL,
    slug                VARCHAR(50)     NOT NULL UNIQUE,
    description         TEXT,
    price_monthly       DECIMAL(10,2)   NOT NULL,
    price_yearly        DECIMAL(10,2)   NOT NULL,
    max_vehicles        INTEGER         NOT NULL DEFAULT 10,
    max_bookings_month  INTEGER         NOT NULL DEFAULT 100,
    features            JSONB           DEFAULT '[]',
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- =============================================================
-- DATABASE VIEWS
-- =============================================================

-- Active bookings with full details
CREATE OR REPLACE VIEW v_active_bookings AS
SELECT
    b.id,
    b.booking_number,
    b.pickup_datetime,
    b.return_datetime,
    b.status,
    b.payment_status,
    b.total_amount,
    b.amount_paid,
    (b.total_amount - b.amount_paid)                AS balance_due,
    b.with_driver,
    -- Customer
    u.first_name || ' ' || u.last_name              AS customer_name,
    u.email                                         AS customer_email,
    u.phone                                         AS customer_phone,
    -- Vehicle
    v.registration_number,
    v.make || ' ' || v.model                        AS vehicle_name,
    vc.name                                         AS category_name,
    -- Driver
    du.first_name || ' ' || du.last_name            AS driver_name,
    -- Overdue calculation
    CASE WHEN b.status = 'active' AND NOW() > b.return_datetime
         THEN EXTRACT(EPOCH FROM (NOW() - b.return_datetime))/3600
         ELSE 0
    END::INTEGER                                    AS overdue_hours,
    CASE WHEN b.status = 'active' AND NOW() > b.return_datetime
         THEN EXTRACT(EPOCH FROM (NOW() - b.return_datetime))/3600 * 100
         ELSE 0
    END::DECIMAL(10,2)                              AS late_fee_accrued
FROM bookings b
JOIN customer_profiles cp ON b.customer_id = cp.id
JOIN auth_users u ON cp.user_id = u.id
JOIN vehicles v ON b.vehicle_id = v.id
JOIN vehicle_categories vc ON v.category_id = vc.id
LEFT JOIN driver_profiles dp ON b.driver_id = dp.id
LEFT JOIN auth_users du ON dp.user_id = du.id
WHERE b.status IN ('pending', 'confirmed', 'active');

-- Vehicle availability view
CREATE OR REPLACE VIEW v_vehicle_availability AS
SELECT
    v.id,
    v.registration_number,
    v.make || ' ' || v.model       AS vehicle_name,
    vc.name                         AS category,
    vc.type                         AS category_type,
    vb.name                         AS branch_name,
    v.status,
    v.fuel_type,
    v.seating_capacity,
    COALESCE(v.price_per_day, vc.base_price_per_day) AS daily_rate,
    v.average_rating,
    v.total_trips,
    -- Current active booking info
    curr.booking_number             AS current_booking_number,
    curr.return_datetime            AS expected_return
FROM vehicles v
JOIN vehicle_categories vc ON v.category_id = vc.id
JOIN vehicle_branches vb ON v.branch_id = vb.id
LEFT JOIN bookings curr ON curr.vehicle_id = v.id AND curr.status = 'active'
WHERE v.is_active = TRUE;

-- Revenue analytics view
CREATE OR REPLACE VIEW v_monthly_revenue AS
SELECT
    DATE_TRUNC('month', p.paid_at)  AS month,
    COUNT(DISTINCT p.booking_id)    AS total_bookings,
    COUNT(p.id)                     AS total_transactions,
    SUM(p.amount)                   AS gross_revenue,
    SUM(p.cgst + p.sgst + p.igst)  AS total_tax,
    SUM(p.amount - p.cgst - p.sgst - p.igst) AS net_revenue,
    AVG(b.total_amount)             AS avg_booking_value
FROM payments p
JOIN bookings b ON p.booking_id = b.id
WHERE p.status = 'success'
  AND p.payment_type = 'booking_payment'
GROUP BY DATE_TRUNC('month', p.paid_at)
ORDER BY month DESC;

-- Driver performance view
CREATE OR REPLACE VIEW v_driver_performance AS
SELECT
    dp.id,
    u.first_name || ' ' || u.last_name  AS driver_name,
    dp.employee_id,
    dp.availability_status,
    dp.total_trips,
    dp.average_rating,
    dp.total_violations,
    dp.experience_years,
    -- Count active bookings
    COUNT(b.id) FILTER (WHERE b.status = 'active') AS active_bookings,
    -- This month trips
    COUNT(b.id) FILTER (
        WHERE b.status = 'completed'
        AND b.completed_at >= DATE_TRUNC('month', NOW())
    ) AS trips_this_month,
    -- This month earnings (for salary calculation)
    SUM(b.driver_charges) FILTER (
        WHERE b.status = 'completed'
        AND b.completed_at >= DATE_TRUNC('month', NOW())
    ) AS earnings_this_month
FROM driver_profiles dp
JOIN auth_users u ON dp.user_id = u.id
LEFT JOIN bookings b ON b.driver_id = dp.id
GROUP BY dp.id, u.first_name, u.last_name, dp.employee_id,
         dp.availability_status, dp.total_trips, dp.average_rating,
         dp.total_violations, dp.experience_years;

-- =============================================================
-- STORED PROCEDURES
-- =============================================================

-- Calculate late return penalty
CREATE OR REPLACE FUNCTION calculate_late_penalty(
    p_booking_id UUID,
    p_actual_return TIMESTAMPTZ DEFAULT NOW()
)
RETURNS TABLE(
    overdue_hours    INT,
    late_fee         DECIMAL(10,2),
    fuel_adjustment  DECIMAL(10,2),
    total_penalty    DECIMAL(10,2)
) AS $$
DECLARE
    v_booking         bookings%ROWTYPE;
    v_overdue_hours   INT;
    v_late_fee        DECIMAL(10,2);
    v_fuel_fee        DECIMAL(10,2) := 0;
    v_fuel_diff       INT;
BEGIN
    SELECT * INTO v_booking FROM bookings WHERE id = p_booking_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Booking % not found', p_booking_id;
    END IF;

    -- Calculate overdue
    v_overdue_hours := GREATEST(0,
        EXTRACT(EPOCH FROM (p_actual_return - v_booking.return_datetime)) / 3600
    )::INT;

    v_late_fee := v_overdue_hours * 100; -- ₹100 per hour

    -- Fuel adjustment if returned below pickup level
    IF v_booking.fuel_level_at_pickup IS NOT NULL AND v_booking.fuel_level_at_return IS NOT NULL THEN
        v_fuel_diff := v_booking.fuel_level_at_pickup - v_booking.fuel_level_at_return;
        IF v_fuel_diff > 10 THEN -- more than 10% lower
            v_fuel_fee := v_fuel_diff * 50; -- ₹50 per percent
        END IF;
    END IF;

    RETURN QUERY SELECT
        v_overdue_hours,
        v_late_fee,
        v_fuel_fee,
        (v_late_fee + v_fuel_fee);
END;
$$ LANGUAGE plpgsql;

-- Check vehicle availability (returns conflicting bookings)
CREATE OR REPLACE FUNCTION check_vehicle_availability(
    p_vehicle_id    UUID,
    p_pickup        TIMESTAMPTZ,
    p_return        TIMESTAMPTZ,
    p_exclude_id    UUID DEFAULT NULL
)
RETURNS TABLE(
    is_available        BOOLEAN,
    conflicting_count   INT,
    next_available_at   TIMESTAMPTZ
) AS $$
DECLARE
    v_conflicts     INT;
    v_next_avail    TIMESTAMPTZ;
BEGIN
    SELECT COUNT(*) INTO v_conflicts
    FROM bookings
    WHERE vehicle_id = p_vehicle_id
      AND status IN ('confirmed', 'active', 'pending')
      AND pickup_datetime < p_return
      AND return_datetime > p_pickup
      AND (p_exclude_id IS NULL OR id != p_exclude_id);

    -- Find next available slot
    SELECT MIN(return_datetime) INTO v_next_avail
    FROM bookings
    WHERE vehicle_id = p_vehicle_id
      AND status IN ('confirmed', 'active', 'pending')
      AND return_datetime > NOW();

    RETURN QUERY SELECT
        (v_conflicts = 0),
        v_conflicts,
        v_next_avail;
END;
$$ LANGUAGE plpgsql;

-- =============================================================
-- TRIGGERS
-- =============================================================

-- Update vehicle status when booking becomes active
CREATE OR REPLACE FUNCTION trigger_booking_status_change()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'active' AND OLD.status != 'active' THEN
        UPDATE vehicles SET status = 'rented', updated_at = NOW()
        WHERE id = NEW.vehicle_id;

        IF NEW.driver_id IS NOT NULL THEN
            UPDATE driver_profiles SET availability_status = 'on_duty'
            WHERE id = NEW.driver_id;
        END IF;

    ELSIF NEW.status IN ('completed', 'cancelled', 'no_show')
        AND OLD.status = 'active' THEN

        UPDATE vehicles SET status = 'available', updated_at = NOW()
        WHERE id = NEW.vehicle_id;

        IF NEW.driver_id IS NOT NULL THEN
            UPDATE driver_profiles SET availability_status = 'available'
            WHERE id = NEW.driver_id;
        END IF;

        -- Update vehicle total trips on completion
        IF NEW.status = 'completed' THEN
            UPDATE vehicles SET total_trips = total_trips + 1
            WHERE id = NEW.vehicle_id;

            UPDATE driver_profiles SET total_trips = total_trips + 1
            WHERE id = NEW.driver_id;
        END IF;
    END IF;

    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_booking_status_change
    BEFORE UPDATE OF status ON bookings
    FOR EACH ROW EXECUTE FUNCTION trigger_booking_status_change();

-- Update customer stats on booking completion
CREATE OR REPLACE FUNCTION trigger_update_customer_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE customer_profiles
        SET
            total_bookings = total_bookings + 1,
            total_spend    = total_spend + NEW.total_amount,
            loyalty_points = loyalty_points + FLOOR(NEW.total_amount / 100)::INT,
            updated_at     = NOW()
        WHERE id = NEW.customer_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_customer_stats
    AFTER UPDATE OF status ON bookings
    FOR EACH ROW EXECUTE FUNCTION trigger_update_customer_stats();

-- Auto-update vehicle average rating after review
CREATE OR REPLACE FUNCTION trigger_update_vehicle_rating()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE vehicles
    SET average_rating = (
        SELECT AVG(vehicle_rating)::DECIMAL(3,2)
        FROM booking_reviews br
        JOIN bookings b ON br.booking_id = b.id
        WHERE b.vehicle_id = (
            SELECT vehicle_id FROM bookings WHERE id = NEW.booking_id
        )
        AND br.is_published = TRUE
    )
    WHERE id = (SELECT vehicle_id FROM bookings WHERE id = NEW.booking_id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_vehicle_rating
    AFTER INSERT OR UPDATE ON booking_reviews
    FOR EACH ROW EXECUTE FUNCTION trigger_update_vehicle_rating();

-- =============================================================
-- CTE QUERY EXAMPLES (for analytics)
-- =============================================================

-- Monthly revenue with running total (Window Function)
-- SELECT
--     month,
--     gross_revenue,
--     SUM(gross_revenue) OVER (ORDER BY month) AS cumulative_revenue,
--     gross_revenue - LAG(gross_revenue) OVER (ORDER BY month) AS mom_change,
--     ROUND(
--         100.0 * (gross_revenue - LAG(gross_revenue) OVER (ORDER BY month))
--             / NULLIF(LAG(gross_revenue) OVER (ORDER BY month), 0), 2
--     ) AS mom_pct_change
-- FROM v_monthly_revenue;

-- Top vehicles by revenue (CTE)
-- WITH vehicle_revenue AS (
--     SELECT
--         v.id,
--         v.make || ' ' || v.model AS vehicle_name,
--         COUNT(b.id)              AS total_trips,
--         SUM(b.total_amount)      AS total_revenue,
--         AVG(b.total_amount)      AS avg_booking_value,
--         RANK() OVER (PARTITION BY vc.type ORDER BY SUM(b.total_amount) DESC) AS rank_in_category
--     FROM vehicles v
--     JOIN vehicle_categories vc ON v.category_id = vc.id
--     JOIN bookings b ON b.vehicle_id = v.id AND b.status = 'completed'
--     GROUP BY v.id, vehicle_name, vc.type
-- )
-- SELECT * FROM vehicle_revenue WHERE rank_in_category <= 5;

-- =============================================================
-- SEED DATA
-- =============================================================

INSERT INTO vehicle_branches (name, code, address, city, state, pincode, phone)
VALUES
    ('Chennai Central',   'CHN01', '12 Anna Salai, Chennai',     'Chennai',   'Tamil Nadu',   '600002', '04412345678'),
    ('Mumbai Andheri',    'MUM01', '45 Link Road, Andheri West', 'Mumbai',    'Maharashtra',  '400053', '02298765432'),
    ('Bengaluru MG Road', 'BLR01', '78 MG Road, Bengaluru',     'Bengaluru', 'Karnataka',    '560001', '08023456789'),
    ('Delhi Connaught',   'DEL01', '22 Connaught Place, Delhi',  'Delhi',     'Delhi',        '110001', '01145678901');

INSERT INTO vehicle_categories (name, type, base_price_per_day, base_price_per_hour, security_deposit, sort_order)
VALUES
    ('Hatchback',   'car',      1100, 150, 3000, 1),
    ('Sedan',       'car',      1400, 180, 4000, 2),
    ('SUV',         'car',      2200, 280, 6000, 3),
    ('Luxury Car',  'luxury',   8000, 1000, 20000, 4),
    ('Sports Bike', 'bike',     1200, 160, 3000, 5),
    ('Scooter',     'bike',     600,  80,  1500, 6),
    ('Electric SUV','electric', 2500, 320, 7000, 7),
    ('Electric Bike','electric', 800, 110, 2000, 8);

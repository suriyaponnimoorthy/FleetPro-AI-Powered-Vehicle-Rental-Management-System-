> Latest hardening validation: **75 passed, four PostgreSQL-only tests skipped**. Production-settings checks, OpenAPI schema validation, build, local HTTPS and private-path denial passed. See [PRODUCTION_READINESS.md](PRODUCTION_READINESS.md) for exact limits. The record below describes the earlier premium edition.

# Validation record

Date: 31 October 2026. Environment: Python 3.12.14, Django 5.2.18, Node 24.22.1. Local execution used SQLite, in-memory cache and console email.

| Check | Result |
| --- | --- |
| Django system checks | Passed, no system-check issues |
| Initial application migrations and upgraded third-party migrations | Applied successfully to local SQLite |
| Complete backend suite | 49 passed |
| Frontend production build | Passed with Vite 5.4.21 |
| Seed command | Completed; local admin/customer accounts created |
| API smoke tests | Dashboard, bookings, vehicles, customers, drivers, payment summary and revenue routes returned HTTP 200 for an authorized admin |
| Employee desktop browser check | Login, KPI data, current reservations, navigation and logout worked |
| Customer desktop/mobile browser check | Login, recommendation cards, local chat response and responsive layout worked; no horizontal overflow at 390px |
| Customer reservation browser flow | City/seats/dates selection, inventory filtering, estimate review, pending reservation creation and My journeys display worked |
| Employee mobile reservation browser flow | Customer selection, availability search, vehicle selection and pending reservation creation worked; no horizontal overflow at 390px |
| JavaScript runtime errors during browser checks | None observed |
| UI visual review | Inspected desktop customer portal, desktop dashboard and mobile customer/employee layouts; fixed mobile availability form clipping |

Backend coverage includes authentication, registration, vehicle CRUD permissions, booking creation/conflicts, payment/analytics baseline routes, recommendation budget/seats/city/fuel constraints, invalid dates, half-open date boundaries, scheduled maintenance exclusion, own-booking chat scoping, AI consent, fallback, allowlisted model context, invented/duplicate recommendation IDs, input validation/throttling, customer mutation denial, KYC action denial, rental rounding, employee customer selection, booking ownership and fleet status transitions.

The added tests are in `tests/test_intelligence.py` and `tests/test_rental_flow.py`. The original suite remains in `tests/test_suite.py`; its customer fixture now works with automatic profile creation.

The suite used the repository's existing `--nomigrations` pytest option. Application migrations were therefore checked separately using `manage.py migrate`. WhiteNoise emitted warnings because the local test profile does not collect a `staticfiles` directory; these did not fail the tests.

No live AI key was provided. Model success/failure paths were mocked. External email/SMS delivery, payment gateway settlement, S3, real PostgreSQL concurrent transactions, load behavior, full accessibility compliance and Docker/TLS deployment were not verified. Browser checks used local synthetic demo records, not real customer activity.
